<?php $title='Reports'; include("header.php"); ?>

<p><table align="center" width="580"><tr><td valign="top"><font face="Arial,Helvetica,sans-serif"><ul>

<li><p><form action="../">
<label for="form2"><strong>ELIGIBLE HORSES</strong></label>
<select name="form2" onchange="window.location=this.options[this.selectedIndex].value">
<option value="">2-Year-Olds</option>
<option value="eligibility.php?a=2&g=P&s=C">Pacing Colts</option>
<option value="eligibility.php?a=2&g=P&s=F">Pacing Fillies</option>
<option value="eligibility.php?a=2&g=T&s=C">Trotting Colts</option>
<option value="eligibility.php?a=2&g=T&s=F">Trotting Fillies</option>
</select>
<select name="form2" onchange="window.location=this.options[this.selectedIndex].value">
<option value="">3-Year-Olds</option>
<option value="eligibility.php?a=3&g=P&s=C">Pacing Colts</option>
<option value="eligibility.php?a=3&g=P&s=F">Pacing Fillies</option>
<option value="eligibility.php?a=3&g=T&s=C">Trotting Colts</option>
<option value="eligibility.php?a=3&g=T&s=F">Trotting Fillies</option>
</select>
</form></p></li>


<li><p><form action="../">
<label for="form1"><strong>POINTS</strong></label>
<select name="form1" onchange="window.location=this.options[this.selectedIndex].value">
<option value="">SIRE STAKES</option>
<optgroup label="2-Year-Olds">
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Pacing&DivisionSex=Colts&DivisionType=Sire+Stakes">Pacing Colts</option>
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Pacing&DivisionSex=Fillies&DivisionType=Sire+Stakes">Pacing Fillies</option>
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Trotting&DivisionSex=Colts&DivisionType=Sire+Stakes">Trotting Colts</option>
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Trotting&DivisionSex=Fillies&DivisionType=Sire+Stakes">Trotting Fillies</option>
</optgroup>
<optgroup label="3-Year-Olds">
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Pacing&DivisionSex=Colts&DivisionType=Sire+Stakes">Pacing Colts</option>
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Pacing&DivisionSex=Fillies&DivisionType=Sire+Stakes">Pacing Fillies</option>
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Trotting&DivisionSex=Colts&DivisionType=Sire+Stakes">Trotting Colts</option>
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Trotting&DivisionSex=Fillies&DivisionType=Sire+Stakes">Trotting Fillies</option>
</optgroup>
</select>

<select name="form1" onchange="window.location=this.options[this.selectedIndex].value">
<option value="">EXCELSIOR / STATE FAIR</option>
<optgroup label="2-Year-Olds">
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Pacing&DivisionSex=Colts&DivisionType=Excelsior">Pacing Colts</option>
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Pacing&DivisionSex=Fillies&DivisionType=Excelsior">Pacing Fillies</option>
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Trotting&DivisionSex=Colts&DivisionType=Excelsior">Trotting Colts</option>
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Trotting&DivisionSex=Fillies&DivisionType=Excelsior">Trotting Fillies</option>
</optgroup>
<optgroup label="3-Year-Olds">
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Pacing&DivisionSex=Colts&DivisionType=Excelsior">Pacing Colts</option>
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Pacing&DivisionSex=Fillies&DivisionType=Excelsior">Pacing Fillies</option>
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Trotting&DivisionSex=Colts&DivisionType=Excelsior">Trotting Colts</option>
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Trotting&DivisionSex=Fillies&DivisionType=Excelsior">Trotting Fillies</option>
</optgroup>
</select>

<select name="form1" onchange="window.location=this.options[this.selectedIndex].value">
<option value="">COUNTY FAIR</option>
<optgroup label="2-Year-Olds">
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Pacing&DivisionSex=Colts&DivisionType=County+Fair">Pacing Colts</option>
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Pacing&DivisionSex=Fillies&DivisionType=County+Fair">Pacing Fillies</option>
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Trotting&DivisionSex=Colts&DivisionType=County+Fair">Trotting Colts</option>
<option value="PointStatistics.php?DivisionAge=2YO&DivisionGait=Trotting&DivisionSex=Fillies&DivisionType=County+Fair">Trotting Fillies</option>
</optgroup>
<optgroup label="3-Year-Olds">
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Pacing&DivisionSex=Colts&DivisionType=County+Fair">Pacing Colts</option>
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Pacing&DivisionSex=Fillies&DivisionType=County+Fair">Pacing Fillies</option>
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Trotting&DivisionSex=Colts&DivisionType=County+Fair">Trotting Colts</option>
<option value="PointStatistics.php?DivisionAge=3YO&DivisionGait=Trotting&DivisionSex=Fillies&DivisionType=County+Fair">Trotting Fillies</option>
</optgroup>
</select>
</form>
</p></li>

<li><p><strong>STALLION STATISTICS:</strong> <a href="StallionStatistics.php" target=_blank>Total</a> | <a href="StallionStatistics.php?y=2">2-Year-Olds</a> | <a href="StallionStatistics.php?y=3">3-Year-Olds</a></p></li>

<li><p><strong>PEOPLE STATISTICS:</strong> <a href="DriverStatistics.php" target=_blank>Driver</a> | <a href="TrainerStatistics.php" target=_blank>Trainer</a> | <a href="OwnerStatistics.php" target=_blank>Owner</a> | <a href="BreederStatistics.php" target=_blank>Breeder</a></p></li>

</ul></font></td>
</tr></table></p>

<?php include("footer.php"); ?>


