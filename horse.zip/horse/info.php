<?php
print "This is a test";
phpinfo();
?>
