<?
header("Content-Type: text/html; charset=iso-8859-1\n");
$file = './data/default.csv';
$password = 'C@pit0l';
$db = './data/db.cgi';
$uploadroot = './data';
$celluploadroot = './uploads';
$celluploadurl = '//nysspoints.com/backend/Tables/uploads';


$datafile = array();
$extensions = array(
'jpg'=>'/backend/Tables/images/camera.gif',
'png'=>'/backend/Tables/images/camera.gif',
'gif'=>'/backend/Tables/images/camera.gif',
'pdf'=>'/backend/Tables/images/pdf_button.gif',
'link'=>'/backend/Tables/images/link.png',
'youtube'=>'/backend/Tables/images/youtube.png',
'info'=>'/backend/Tables/images/get_info.png'
);

//target options overdiv, new, same
$targets = array(
'jpg'=>'overdiv',
'png'=>'overdiv',
'gif'=>'overdiv',
'pdf'=>'new',
'link'=>'new',
'youtube'=>'overdiv'
);

class JSON_Message{
	public $success;
	public $message;
	public $id;
	}
	
$action = $_REQUEST['action'];
(!$action)&&(DisplayTable());
($action=='view')&&(DisplayTable());
($action=='showlogin')&&(ShowLogin());
($action=='dologin')&&(DoLogin());
sec();
($action=='manage')&&(DisplayTable('edit'));
($action=='savechanges')&&(SaveChanges());
($action=='irb')&&(DisplayTable('edit'));
($action=='ira')&&(DisplayTable('edit'));
($action=='dr')&&(DisplayTable('edit'));
($action=='icb')&&(DisplayTable('edit'));
($action=='ica')&&(DisplayTable('edit'));
($action=='dc')&&(DisplayTable('edit'));
($action=='savechanges')&&(SaveChanges());
($action=='showupload')&&(ShowUpload());
($action=='doupload')&&(!$_REQUEST['cellid'])&&(DoUpload());
($action=='doupload')&&($_REQUEST['cellid'])&&(DoUploadCell());
($action=='showadd')&&(ShowAdd());
($action=='savetable')&&(SaveTable());
($action=='delete')&&(DeleteTable());
($action=='showuploaddata')&&(ShowUploadData());
($action=='showcss')&&(ShowCSS());
($action=='savecss')&&(SaveCSS());

function SaveCSS(){
$id = scrub($_REQUEST['id']);

if($_REQUEST['css']){
	file_put_contents("style-$id.css",stripslashes($_REQUEST['css']));
	}
else{
	@unlink("style-$id.css");
	}

$msg = new JSON_Message();
$msg->success=true;
$msg->message='CSS Saved';
print json_encode($msg);
flush();
exit();
}

function ShowCSS(){

$id = scrub($_REQUEST['id']);
$css='';

if(file_exists("style-$id.css")){
	$css = file_get_contents("style-$id.css");
	}
else{
	$css = file_get_contents("style.css");
	}



include("t_css.html");
exit;
}

function DeleteTable(){
global $uploadroot;
global $db;
$errors = array();

$id = scrub($_REQUEST['tableId']);
if(file_exists($db)){
	$tables = unserialize(file_get_contents($db));
	if(isset($tables[$id])){
		$file = $tables[$id]->id.'.csv';
		
		@unlink("$uploadroot/$file");
		unset($tables[$id]);		
		file_put_contents($db,serialize($tables));
		}
	}
	
$msg = new JSON_Message();

if($errors){
	$msg->success=false;
	$msg->message=join("<br>",$errors);
	}
else{
	$msg->success=true;
	$msg->message='Table Deleted';
	}

print json_encode($msg);
flush();
exit();
}

function SaveTable(){
global $db;
global $file;
global $tables;
global $uploadroot;

$tables = array();

$errors=array();
$tableName = scrub($_POST['tableName']);
$tableId = scrub($_POST['tableId']);

if(file_exists($db)){
	$tables = unserialize(file_get_contents($db));
	}
else{
	$t = new Table();
	$t->name = getTitle($file);
	$t->filename = $file;
	$t->id = uniqid();
	$idx = $t->id;
	$tables[$idx] = $t;
	}
	
if(!$tableId){
	$tableId = uniqid();
	$table = new Table();
	$table->id = $tableId;
	$table->name = $tableName;
	$table->filename=$tableId.'.csv';
	$idx = $table->id;	
	$tables[$idx] = $table;
	
	//create dummy file.
	$tmprow='';
	
	for($y=1;$y<=$_REQUEST['rows'];$y++){
		$tmpcol = array();
		for($x=1;$x<=$_REQUEST['cols'];$x++){
			$tmpcol[]=' ';
			}
		$tmprow .= join(',',	$tmpcol)."\n";
		}
	
	file_put_contents($uploadroot.'/'.$table->filename,$tmprow);
	
	}
else{
	$tables[$tableId]->name = $tableName;
	}

file_put_contents($db,serialize($tables));

$msg = new JSON_Message();

if($errors){
	$msg->success=false;
	$msg->message=join("<br>",$errors);
	}
else{
	$msg->success=true;
	$msg->message=$tableId;
	}

print json_encode($msg);
flush();
exit();
}

function ShowAdd(){
global $db;

$id = scrub($_REQUEST['tableId']);

if($id){
if(file_exists($db)){
	$tables = unserialize(file_get_contents($db));
	if(isset($tables[$id])){
		$tableName = $tables[$id]->name;
		}
	}
}
	
$showadd = "<br>
Rows: <input type=text name=rows id=rows size=5/><br>
Columns: <input type=text name=cols id=cols  size=5/>
";
	
include("t_add.html");
exit();
}

function sec(){
global $password;
session_start();
if((!$_SESSION['pw'])||($_SESSION['pw'] != $password)){
	header("Location: psTables.php");
	exit();
	}
}

function DoLogin(){
	global $password;
	$msg = new JSON_Message();
	
	if(($_POST['password'])&&($_POST['password'] == $password)){
		session_start();
		$_SESSION['pw'] = $_POST['password'];
		$msg->success=true;
		$msg->message="login successful";
		}
	else{
		$msg->success=false;
		$msg->message="Invalid password";
		}
	
	print json_encode($msg);
	flush();
	exit();
	}

function ShowLogin(){
	$tableId = scrub($_REQUEST['tableId']);
	include("t_login.html");
	exit();
	}


function DoUploadCell(){
global $celluploadurl;
global $celluploadroot;
global $db;

$errors = array();

$id = scrub($_REQUEST['tableId']);

$filename='';
$fileurl='';

if(is_uploaded_file($_FILES['upload']['tmp_name'])){
		$filename = $celluploadroot.'/'.$_FILES['upload']['name'];
		$fileurl = $celluploadurl.'/'.$_FILES['upload']['name'];
		move_uploaded_file($_FILES['upload']['tmp_name'],$filename);
		if(!file_exists($filename)){
			$errors[] = "There was an error uploading your file.";
			}
	}


	
$msg = new JSON_Message();
$msg->cellvalue=$fileurl;
$msg->cellid=scrub($_REQUEST['cellid']);

if($errors){
	$msg->success=false;
	$msg->message= join("<br>",$errors);
	}
else{
	$msg->success=true;
	
	if($hasupload){
		$msg->message= sprintf("file %s has been uploaded",$_FILES['upload']['name']);	
		}
	else{		
		$msg->message= "Changes Saved";		
		}
	}
print json_encode($msg);
flush();
exit();
}
	
function DoUpload(){
global $file;
global $uploadroot;
global $db;

$errors = array();

$id = scrub($_REQUEST['tableId']);

if(file_exists($db)){
	$tables = unserialize(file_get_contents($db));
	if(isset($tables[$id])){
		$file = $tables[$id]->id.'.csv';
		}
	}
	
	
if(is_uploaded_file($_FILES['upload']['tmp_name'])){
		$imagepath = "$uploadroot/$file";
		move_uploaded_file($_FILES['upload']['tmp_name'],$imagepath);
		if(!file_exists($imagepath)){
			$errors[] = "There was an error uploading your file.";
			}
	}


	
$msg = new JSON_Message();
if($errors){
	$msg->success=false;
	$msg->message= join("<br>",$errors);
	}
else{
	$msg->success=true;
	
	if($hasupload){
		$msg->message= sprintf("file %s has been uploaded",$_FILES['upload']['name']);	
		}
	else{		
		$msg->message= "Changes Saved";		
		}
	}
print json_encode($msg);
flush();
exit();
}


function ShowUpload(){
	$tableId = scrub($_REQUEST['tableId']);
	include("t_upload.html");
	}

function ShowUploadData(){
	$tableId = scrub($_REQUEST['tableId']);
	$t = scrub($_REQUEST['t']);
	$cellid = scrub($_REQUEST['cellid']);
	include("t_upload.html");
	}
	
function SaveChanges(){
global $file;
global $db;
global $uploadroot;

$buffer='';
$tableId = scrub($_REQUEST['tableId']);

if($_REQUEST['tableTitle']){
	file_put_contents($uploadroot."/title-".$_REQUEST['tableId'].".txt",$_REQUEST['tableTitle']);	
	}
else{
	@unlink($uploadroot."/title-".$_REQUEST['tableId'].".txt");
	}

if(file_exists($db)){
	$tables = unserialize(file_get_contents($db));
	if(isset($tables[$tableId])){
		$file = $uploadroot.'/'.$tables[$tableId]->id.'.csv';
		}
	}
	
$line = array();
$rows = preg_replace("/[^\d]/","",$_REQUEST['rows']);
$columns = preg_replace("/[^\d]/","",$_REQUEST['columns']);

for($row=1;$row<=$rows;$row++){
	$line=array();
	for($col=1;$col<=$columns;$col++){
		$data = stripslashes(utf8_decode($_REQUEST['r_'.$row.'_c_'.$col]));		
		$line[] = '"'.$data.'"';
	}
	$buffer .= join(",",$line)."\n";	
	}

file_put_contents($file,$buffer);

if($_REQUEST['fjson']==1){
$msg = new JSON_Message();
$msg->success=true;
$msg->message= "Changes Saved";		
print json_encode($msg);
flush();
}
else{
print "<script language=javascript>\n";
print "var rndURL = (1000*Math.random());\n";
print "alert(\"Changes Saved\");\n";
print "window.location='psTables.php?action=manage&tableId=$tableId&rnd='+rndURL;\n";
print "</script>\n";
}
exit();
}

function getTitle($file){
	$path_parts = pathinfo($file);
	return $path_parts['filename'];
	}

function DisplayTable($t=''){
global $file;
global $db;
global $uploadroot;

$tableId='';
$tables = array();
$tablesSort = array();
if(file_exists($db)){
	$tables = unserialize(file_get_contents($db));
	foreach($tables as $key => $value){
		$newkey = strtoupper($value->name)."_".$value->id;
		$tablesSort[$newkey] = $value;
		}
	ksort($tablesSort);
	$tableOptions='';
	$tableOpt_nav = array();
	$firsttable='';
	$firsttablenav = array();

	//get the nav dropdown default table
	if((!$_REQUEST['tableId'])&&($_REQUEST['sn'])){
	foreach($tablesSort as $key => $value){
		preg_match("/(\d+)\_(.+)/",$value->name,$match);
		list(,$index,$tname)=$match;
		$navkey = $tname."_".$value->id;
			if($index == $_REQUEST['cat']){
				$firsttablenav[$navkey ] = $value->id;
			}
		}

	krsort($firsttablenav);
	
	foreach($firsttablenav as $key=>$value){
		$_REQUEST['tableId'] = $value;
		break;
		} 	
	}

	


	foreach($tablesSort as $key => $value){
		if(!$firsttable){
			$firsttable = $value->id;
			}
		if((!$_REQUEST['tableId'])&&(!$_REQUEST['sn'])){
			$_REQUEST['tableId'] = $value->id;
			}

		if((!$_REQUEST['tableId'])&&($_REQUEST['sn'])){
			preg_match("/(\d+)\_(.+)/",$value->name,$match);
			list(,$index,$tname)=$match;
			//if($index == 1){
			//	$_REQUEST['tableId'] = $value->id;
			//	}
			if($index == $_REQUEST['cat']){
				//$_REQUEST['tableId'] = $value->id;
				}

			}


		if($value->id == scrub($_REQUEST['tableId'])){
			$file = $value->filename;
			$title = $value->name;
			$sel='selected';
			}
		else{
			$sel='';
			}	
		$tableOptions .= "<option value='".$value->id."' $sel>".$value->name."</option>";	

		preg_match("/(\d+)\_(.+)/",$value->name,$match);
		list(,$index,$tname)=$match;
		if($index == $_REQUEST['cat']){
			//$navkey = $index."_".$value->id;
			$navkey = $tname."_".$value->id;
			//print "<!-- $navkey -->\n";
			$tableOpt_nav[$navkey] = "<option value='".$value->id."' $sel>".$tname."</option>";
			}
		}	

	//set default if nothing else
	if(!$_REQUEST['tableId']){
		$_REQUEST['tableId']=$firsttable;
		}

	$tableMenu = "";
	krsort($tableOpt_nav);
	$tableTitle='';
	if(file_exists($uploadroot."/title-".$_REQUEST['tableId'].".txt")){
		$tableTitle = file_get_contents($uploadroot."/title-".$_REQUEST['tableId'].".txt");	
		}
	
	if($t=='edit'){	
		$tableMenu = "<select name=tableSelect id=tableSelect onchange=\"SwitchTable();\">$tableOptions</select>";	
		$tableMenu .= "<input type=button onclick=\"Delete();\" value=\"Delete\"> ";
		$tableMenu .= "<input type=button onclick=\"Edit();\" value=\"Rename\"> ";		
		$tableMenu .= "Title: <input type=text name=tableTitle id=tableTitle value=\"$tableTitle\" size=30> (optional) ";	
		}
	else{
		if(!$_REQUEST['hm']){	
			$tableMenu = "Select a Table: <select name=tableSelect id=tableSelect onchange=\"SwitchTableView();\">$tableOptions</select>";
			}
		elseif ($_REQUEST['sn']) {
				$tableOptions_nav = '';
				foreach($tableOpt_nav as $k=>$v){
					$tableOptions_nav .= $v;
				}
				$tableMenu = "<p align=center><b>Select Previous Years:</b> <select name=tableSelect id=tableSelect onchange=\"SwitchTableView();\">$tableOptions_nav</select></p>";
			}	
		}	
	$tableId = scrub($_REQUEST['tableId']);
	}
else{
	$tableMenu='';
	$title = getTitle($file);
	}
	


$id = preg_replace("/[^\d]/","",$_REQUEST['id']);
$row='';

$datafile = ReadData($file);

if(($_REQUEST['action']=='ira')||($_REQUEST['action']=='irb')){
	$newrow = array();
	foreach($datafile[0] as $c){
		$newrow[] = '';
		}

if($_REQUEST['action']=='ira'){
	$key = $id;
	}

if($_REQUEST['action']=='irb'){
	$key = $id-1;
	}

array_splice( $datafile, $key, 0, array($newrow) );	
}

if($_REQUEST['action']=='dr'){
	unset($datafile[$id-1]);
	}
	
@reset($datafile);
	
if($datafile=='no data'){
	$datafile = array();
	}


	
foreach($datafile as $rows){
$row_num++;
$col_num=0;
	($row_num %2==0)?($rclass='evenrow'):($rclass='oddrow');	
	($row_num==1)&&($rclass='header');
	if(($_REQUEST['action']=='ica')||($_REQUEST['action']=='icb')){
		if($_REQUEST['action']=='ica'){
			$key = $id;
			}
		if($_REQUEST['action']=='icb'){
			$key = $id-1;
			}
		array_splice( $rows, $key, 0, array('') );	
		}
	
	if($_REQUEST['action']=='dc'){
		unset($rows[$id-1]);
		}
		
	if(($row_num==1) && ($tableTitle)){
	$row .= "<tr class=\"$hclass\"><td class=\"column column_$rclass table_title\" colspan=100>$tableTitle</td></tr>";
	}
		
	
	$row .= "<tr class=\"$hclass\">";
	foreach($rows as $column){
		$col_num++;
		
		if($t=='edit'){
		
		if($row_num==1){
		$hclass='header';
		$mb = " <input type=button value=\"<\" class=\"small_button\" onclick=\"InsertColBefore('$col_num')\"> <input type=button value=\">\" class=\"small_button\" onclick=\"InsertColAfter('$col_num')\"> <input type=button value=\"x\" class=\"small_button\" onclick=\"DeleteCol('$col_num')\">";
		}
	else{
		$hclass='rows';
		$mb='';
		}
		
		
		if($col_num==1){
			$cb = " <input type=button value=\"^\" class=\"small_button\" onclick=\"InsertRowBefore('$row_num')\"><br><input type=button value=\"v\" class=\"small_button\" onclick=\"InsertRowAfter('$row_num')\"><br><input type=button value=\"x\" class=\"small_button\" onclick=\"DeleteRow('$row_num')\">";
			$style1="style=\"background-color: #CCCCCC; text-align:center; border: 1px solid\"";
			}
		else{
			$cb='';
			$style1="";
			}
			($mb)&&($mb .= '<br>');
			$tableId = scrub($_REQUEST['tableId']);
			
			if(preg_match("/^LINK/",$column)){
			list(,$linktext,$linkurl) = preg_split("/\|/",$column);
			}
			$infotext='';
			$linkinfo='';
			if(preg_match("/^INFO/",$column)){
			list(,$infotext,$linkinfo) = preg_split("/\|/",$column);
			}
			if(preg_match("/^YOUTUBE/",$column)){
			list(,$yturl) = preg_split("/\|/",$column);
			}
			if(preg_match("/^HYPO/",$column)){
			list(,$hypo) = preg_split("/\|/",$column);
			}
			if($row_num==1){
			$lopt="";
			}
			else{
			$lopt="<input type=button value=\"U\" class=\"small_button\" onclick=\"ShowUploadData('${tableId}','U','r_${row_num}_c_${col_num}')\">
			<input type=button value=\"L\" class=\"small_button\" onclick=\"ShowLinkData('r_${row_num}_c_${col_num}','".htmlspecialchars($linktext)."','".htmlspecialchars($linkurl)."')\">
			<input type=button value=\"I\" class=\"small_button\" onclick=\"ShowInfoData('r_${row_num}_c_${col_num}','".htmlspecialchars($infotext)."')\">
			<div id=\"info_r_${row_num}_c_${col_num}\" name=\"info_r_${row_num}_c_${col_num}\" style=\"display:none\">$linkinfo</div>
			<input type=button value=\"Y\" class=\"small_button\" onclick=\"ShowYTData('r_${row_num}_c_${col_num}','".htmlspecialchars($yturl)."')\">
			<input type=button value=\"H\" class=\"small_button\" onclick=\"ShowHData('r_${row_num}_c_${col_num}','".htmlspecialchars($hypo)."')\">
			";
			}
			
			$row .= "<td valign=top $style1>$cb</td><td class=\"column column_$rclass column_manage\" valign=top id=\"c_r_${row_num}_c_${col_num}\">
			<table border=0 class=\"cellmanagetable\">
			<tr>
			<td valign=top></td>
			<td valign=top><textarea id=\"r_${row_num}_c_${col_num}\" type=text name=\"r_${row_num}_c_${col_num}\" rows=2 cols=30>$column</textarea></td>
			<td valign=top>
			$mb
			$lopt
			</td>
			</tr>
			</table>
			</td>";
		}
		else{
			global $extensions;
			global $targets;
			
			$path_parts = pathinfo($column);
			$ext = strtolower($path_parts['extension']);
			$linktext='';
			$linkurl='';
			$infotext='';
			$linkinfo='';
			if(preg_match("/^LINK/",$column)){
				list(,$linktext,$linkurl) = preg_split("/\|/",$column);
				(!$linktext)&&($linktext="<img src=\"".$extensions['link']."\">");
				$target='_blank';
				if($targets[$ext]=='same'){
					$target='_self';
					}
				$column = "<a class=\"file_icons\" href=\"$linkurl\" target=$target>$linktext</a>";
			}	
			elseif(preg_match("/^YOUTUBE/",$column)){	
				list(,$linkurl) = preg_split("/\|/",$column);
				preg_match("/\/([^\/]+)$/",$linkurl,$matches);
				list(,$ytid) = $matches;
				$column = "<a class=\"file_icons\" href=\"javascript:ShowOverYT('$ytid')\" target=_self><img src=\"".$extensions['youtube']."\"></a>";
				}	
			elseif(preg_match("/^HYPO/",$column)){	
				list(,$hypo) = preg_split("/\|/",$column);
				$column = "<input id=mare name=\"mare\" /> 
				<input name=\"submit\" type=\"button\" value=\"Submit Query\" onclick=\"window.open('http://www.standardbredcanada.ca/stallions/stallion_pedigree.html?hash=2deffe0ec8310d6583ef294f3ba0d5e3&tat=$hypo&mare='+\$('#mare').val())\" />
				";
				}	
			elseif(preg_match("/^INFO/",$column)){
				list(,$infotext,$linkinfo) = preg_split("/\|/",$column);
				(!$infotext)&&($infotext="<img src=\"".$extensions['info']."\">");
				$column = "<a class=\"file_icons\" href=\"javascript:ShowInfoDiv('r_${row_num}_c_${col_num}')\">$infotext</a>
				<div id=\"info_r_${row_num}_c_${col_num}\" name=\"info_r_${row_num}_c_${col_num}\" style=\"display:none\">$linkinfo</div>
				";
			}	
			else{
			if($extensions[$ext]){
				if($targets[$ext]=='new'){
					$column = "<a class=\"file_icons\" href=\"$column\" target=_blank><img src=\"".$extensions[$ext]."\"></a>";
					}
				if($targets[$ext]=='same'){
					$column = "<a class=\"file_icons\" href=\"$column\" target=_self><img src=\"".$extensions[$ext]."\"></a>";
					}
				if($targets[$ext]=='overdiv'){
					$column = "<a class=\"file_icons\" href=\"javascript:ShowOverDiv('$column')\" target=_self><img src=\"".$extensions[$ext]."\"></a>";
					}	
				}
			}
			
			$row .= "<td class=\"column column_$rclass\" id=\"c_r_${row_num}_c_${col_num}\">$column</td>";
			}
		}
	$row .= "</tr>\n";
	

	
}

if($t=='edit'){
	$buttons = "<input type=button onclick=\"ShowAdd();\" value=\"Add New Table\">";
	$buttons .= "<input type=button onclick=\"SaveChanges('".$tableId."');\" value=\"Save Changes\">";
	$buttons .= "<input type=button onclick=\"ReloadData('".$tableId."');\" value=\"Reload Data\">";
	$buttons .= "<input type=button onclick=\"ShowUpload('".$tableId."');\" value=\"Upload Data File\">";
	$buttons .= "<input type=button onclick=\"LinksWizard('".$tableId."');\" value=\"Link Wizard\">";
	$buttons .= "<input type=button onclick=\"ShowCss('".$tableId."');\" value=\"Style Settings\">";
	$buttons .= "<input type=button onclick=\"LogOut();\" value=\"Log Out\">";
	}
else{
	if(!$_REQUEST['hl']){
		$buttons = "<input type=button onclick=\"ShowLogin();\" value=\"Edit\">";
		}
	}

if($_REQUEST['a']==1){
	print $row;
	}
else{
	include("template.html");
	}
exit();
}


function ReadData($file){
$records = array();
if(isset($_POST['action'])){
	$records = ReadDataPost();
	}
else{
	$records = ReadDataCSV($file);
	}

return $records;
}

function ReadDataPost(){
$rows = array();
$cols = array();

$r = preg_replace("/[^\d]/","",$_POST['rows']);
$c = preg_replace("/[^\d]/","",$_POST['columns']);

for($y=1;$y<=$r;$y++){
	$cols = array();
	for($x=1;$x<=$c;$x++){
		$cols[] = stripslashes($_POST['r_'.$y.'_c_'.$x]);
		}
	$rows[] = $cols;
}

return $rows;
}

function ReadDataCSV($file){
global $uploadroot;
$file = $uploadroot.'/'.$file;

if(!file_exists($file)){
	//print "$file not found";
	//exit();
	$records='no data';
	}
else{
	$records = f_parse_csv($file);
	}
	
return $records;
}


function f_parse_csv($file) {
global $uploadroot;
  $mdarray = array();
  $file    = fopen($file, "r");
  while ($line = fgetcsv($file)) {
    array_push($mdarray, $line);
    }
  fclose($file);
  return $mdarray;
  }

 
function scrub($string){
	return htmlspecialchars(stripslashes($string), ENT_COMPAT, 'ISO-8859-1');
	}
	  
class Table{
	public $id;
	public $name;
	public $filename;
	}  