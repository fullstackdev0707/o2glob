$(document).ready(function(){
 
	$("#submit1").hover(
	function() {
	$(this).animate({"opacity": "0"}, "slow");
	},
	function() {
	$(this).animate({"opacity": "1"}, "slow");
	});
	
	$('#backgroundPopup')
    .hide()  // hide it initially
    .ajaxStart(function() {
		$(this).css({"opacity": "0.3"});
		$(this).fadeIn("fast");
		$("#loader").fadeIn("fast");
    })
    .ajaxStop(function() {
        $(this).fadeOut("fast");
		$("#loader").fadeOut("fast");
    });
	
});


function ShowYTData(cellid,ld){
$('#dialog-page-content').html("YouTube URL: <input name=ytu id=ytu size=40 value=\""+ld+"\">");	
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'YouTube',
      buttons: {
		Save: function() {
		  var newvalue = 'YOUTUBE|'+$("#ytu").val();			  
		  $('#'+cellid).val(newvalue);
		  SaveData();
          $( this ).dialog( "close" );
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
	
}

function ShowHData(cellid,ld){
$('#dialog-page-content').html("Tattoo: <input name=hypo id=hypo size=40 value=\""+ld+"\">");	
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Hypomating',
      buttons: {
		Save: function() {
		  var newvalue = 'HYPO|'+$("#hypo").val();			  
		  $('#'+cellid).val(newvalue);
		  SaveData();
          $( this ).dialog( "close" );
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
	
}

function LinksWizard(id){
var ld = "<!--#include virtual=\"/backend/Tables/psTables.php?tableId="+id+"&hm=1&hl=1\" -->";
$('#dialog-page-content').html("<textarea rows=2 cols=60>"+ld+"</textarea>");	
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 800,
	  title: 'Display Link',
      buttons: {
		Close: function() {
          $( this ).dialog( "close" );
        }
      }
    });
	
}

function ShowLinkData(cellid,lt,ld){
	if((!lt)&&(!ld)){
		lt = $('#'+cellid).val();	
		lt = lt.replace('LINK|','');
		lt = lt.replace('|','');
		}
$('#dialog-page-content').html("Link Text: <input name=lt id=lt size=40 value=\""+lt+"\">  (optional)<br>Link URL: <input name=ld id=ld size=40 value=\""+ld+"\">");	
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Link',
      buttons: {
		Save: function() {
		  var newvalue = 'LINK|'+$("#lt").val() + "|" + $('#ld').val();			  
		  $('#'+cellid).val(newvalue);
		  SaveData();
          $( this ).dialog( "close" );
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
	
}


function ShowCss(id){
var rndURL = (1000*Math.random());
var url = "psTables.php?action=showcss&id="+id+"&rnd="+rndURL;
$('#dialog-page-content').load(url,function(){
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 800,
	  title: 'CSS Settings',
      buttons: {
        Save: function() {
          $( this ).dialog( "close" );
		  DoSaveCSS();
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
});

}

function DoSaveCSS(){
$.ajax({
		type		: "POST",
		cache	: false,
		url		: 'psTables.php',
		data		: $('#cssform').serializeArray(),
		dataType: "json",
		success: function(data) {
			AlertMessage(data.message);
			if(data.success){
				$("#dialog-page").dialog( "close" );
				}
				
		}
	});
}


function ShowInfoData(cellid,lt){
	var ld = $('#info_'+cellid).html();	
	if((!lt)&&(!ld)){
		lt = $('#'+cellid).val();	
		lt = lt.replace('LINK|','');
		lt = lt.replace('|','');
		}
	
$('#dialog-page-content').html("Link Text: <input name=lt id=lt size=40 value=\""+lt+"\"> (optional)<br>Link Info:<br> <textarea name=ld id=ld rows=8 cols=40>"+ld+"</textarea>");	
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Link',
      buttons: {
		Save: function() {
		  var newvalue = 'INFO|'+$("#lt").val() + "|" + $('#ld').val();			  
		  $('#'+cellid).val(newvalue);
		  SaveData();
          $( this ).dialog( "close" );
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
	
}

function ShowOverDiv(src){
$('#dialog-page-content').html("<center><img src=\""+src+"\"></center>");	
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Photo',
      buttons: {
		Close: function() {
          $( this ).dialog( "close" );
        }
      }
    });
	
}

function ShowInfoDiv(column){
$('#dialog-page-content').html($('#info_'+column).html());	
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Info',
      buttons: {
		Close: function() {
		  $('#dialog-page-content').html("");		
          $( this ).dialog( "close" );
        }
      }
    });
	
}


function ShowOverYT(src){
$('#dialog-page-content').html("<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/"+src+"\" frameborder=\"0\" allowfullscreen></iframe>");	
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Video',
      buttons: {
		Close: function() {
		  $('#dialog-page-content').html("");		
          $( this ).dialog( "close" );
        }
      }
    });
	
}

function SaveData(){
$('#action').val('savechanges');	
$.ajax({
		type		: "POST",
		cache	: false,
		url		: 'psTables.php?fjson=1',
		data		: $('#dataform').serializeArray(),
		dataType: "json",
		success: function(data) {
			AlertMessage(data.message);
		//	if(data.success){
		//
		//		}
				
		}
	});	
	
	
}

function Delete(){
$('#message').html('Are you sure you want to delete this table?');
 $( "#dialog-message" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
      buttons: {
        Ok: function() {
          $( this ).dialog( "close" );
		  DoDelete();
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });


}

function DoDelete(id){
var table = $('#tableSelect').val();
$.ajax({
		type		: "POST",
		cache	: false,
		url		: "psTables.php",
		data    : {action: 'delete',tableId: table},
		dataType: "json",
		success: function(data) {
			AlertMessage(data.message);
		}
	});


}

function InsertColBefore(num){
	$('#action').val('icb');
	$('#id').val(num);
	$('#dataform').submit();
	}
	
function InsertColAfter(num){
	$('#action').val('ica');
	$('#id').val(num);
	$('#dataform').submit();
	}	
	
function InsertRowBefore(num){
	$('#action').val('irb');
	$('#id').val(num);
	$('#dataform').submit();
	}
	
function InsertRowAfter(num){
	$('#action').val('ira');
	$('#id').val(num);
	$('#dataform').submit();
	}	
	
function DeleteCol(num){
$('#message').html('Are you sure you want to delete this column?');
 $( "#dialog-message" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
      buttons: {
        Ok: function() {
			$( this ).dialog( "close" );
			$('#action').val('dc');
			$('#id').val(num);
			$('#dataform').submit();
        },
		Cancel: function() {
			  $( this ).dialog( "close" );
        }
      }
    });


}	

function DeleteRow(num){
$('#message').html('Are you sure you want to delete this row?');
 $( "#dialog-message" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
      buttons: {
        Ok: function() {
			$( this ).dialog( "close" );
			$('#action').val('dr');
			$('#id').val(num);
			$('#dataform').submit();
        },
		Cancel: function() {
			  $( this ).dialog( "close" );
        }
      }
    });


}	


function SaveChanges(){
$('#message').html('Are you sure you want to save the changes?');
 $( "#dialog-message" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
      buttons: {
        Ok: function() {
			$( this ).dialog( "close" );
			$('#action').val('savechanges');
			$('#dataform').submit();
        },
		Cancel: function() {
			  $( this ).dialog( "close" );
        }
      }
    });


}

function SwitchTableView(){
	var table = $('#tableSelect').val();
	var rndURL = (1000*Math.random());
	//window.location="psTables.php?action=view&tableId="+escape(table)+"&rnd="+rndURL;
	var url = "/backend/Tables/psTables.php?action=view&a=1&tableId="+escape(table)+"&rnd="+rndURL;
	$('#datatable').load(url);
	}



	
function SwitchTable(){
	var table = $('#tableSelect').val();
	var rndURL = (1000*Math.random());
	window.location="psTables.php?action=manage&tableId="+escape(table)+"&rnd="+rndURL;
	}

function ReloadData(){
$('#message').html('Are you sure you want to reload the data?');
 $( "#dialog-message" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
      buttons: {
        Ok: function() {
			var rndURL = (1000*Math.random());
			window.location="psTables.php?action=manage&tableId="+$('#tableId').val()+"&rnd="+rndURL;
        },
		Cancel: function() {
			  $( this ).dialog( "close" );
        }
      }
    });


}	

function ShowUploadData(id,t,cellid){
var rndURL = (1000*Math.random());
var url = "psTables.php?action=showuploaddata&tableId="+id+"&t="+t+"&cellid="+cellid+"&rnd="+rndURL;
$('#dialog-page-content').load(url,function(){
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Upload Document',
      buttons: {
		Save: function() {
		  DoUploadData();
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
});
}

function ShowUpload(id){
var rndURL = (1000*Math.random());
var url = "psTables.php?action=showupload&tableId="+id+"&rnd="+rndURL;
$('#dialog-page-content').load(url,function(){
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Upload Document',
      buttons: {
		Save: function() {
		  DoUpload();
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
});
}

function DoAdd(){
$.ajax({
		type		: "POST",
		cache	: false,
		url		: "psTables.php",
		data		: $('#addform').serializeArray(),
		dataType: "json",
		success: function(data) {
			if(data.success==false){
				$('#message').html(data.message);
				 $( "#dialog-message" ).dialog({
					  modal: true,
					  resizable: false,
					  width: 600,
					  buttons: {
						Ok: function() {
						  $( this ).dialog( "close" );
						}
					  }
					});
				}
			else{
				$("#dialog-page").dialog( "close" );
				var rndURL = (1000*Math.random());
				window.location="psTables.php?action=manage&tableId="+escape(data.message)+"&rnd="+rndURL;
				}
		}
	});	
	
}

function Edit(){
var rndURL = (1000*Math.random());
var url = "psTables.php?action=showadd&tableId="+$('#tableId').val()+"&rnd="+rndURL;
$('#dialog-page-content').load(url,function(){
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Rename Table',
      buttons: {
		'Save': function() {
		  DoAdd();
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
});
}

function ShowAdd(){
var rndURL = (1000*Math.random());
var url = "psTables.php?action=showadd&rnd="+rndURL;
$('#dialog-page-content').load(url,function(){
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Add Table',
      buttons: {
		'Add': function() {
		  DoAdd();
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
});
}

function ShowLogin(){
var rndURL = (1000*Math.random());
var url = "psTables.php?action=showlogin&tableId="+$('#tableId').val()+"&rnd="+rndURL;
$('#dialog-page-content').load(url,function(){
$( "#dialog-page" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
	  title: 'Edit Table',
      buttons: {
		'Log In': function() {
		  DoLogin();
        },
		Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
});
}

function DoUploadData(){
var rndURL = (1000*Math.random());
var file = $('#upload')[0].files[0];
if(file){
	name = file.name;
	size = file.size;
	type = file.type;
	}

if(!file){
	AlertMessage("Please select a file.");
	return;
	}

var formData = new FormData($('#uploadform')[0]);

$('#pbar').show();
$('#fup2').show();
$('#fupl').hide();


$.ajax({
		type		: "POST",
		xhr: function() {  // Custom XMLHttpRequest
            var myXhr = $.ajaxSettings.xhr();
            if(myXhr.upload){ // Check if upload property exists
                myXhr.upload.addEventListener('progress',progressHandlingFunction, false); // For handling the progress of the upload
            }
            return myXhr;
        },
		enctype: 'multipart/form-data',
		url		: 'psTables.php',
		data		: formData,
		dataType: "json",
		success: function(data) {
			//AlertMessage(data.message);
			if(data.success){
				$('#pbar').hide();
				$('#fupl').show();
				$('#fup2').hide();
				//AlertMessage(data.message,1);
				$('#upload').val("");
				$('#'+data.cellid).val(data.cellvalue);
				$("#dialog-page").dialog( "close" );
				SaveData();
				//$('#action').val('savechanges');
				//$('#dataform').submit();
				}
			else{
				$('#pbar').hide();
				$('#fupl').show();
				$('#fup2').hide();
				AlertMessage(data.message,1);
				}
				
		},
		error: function (xhr, ajaxOptions, thrownError) {
			$('#pbar').hide();
			$('#fupl').show();
			$('#fup2').hide();
        	AlertMessage('There was an error with your upload');
      	},
		cache: false,
        contentType: false,
        processData: false
	});

}

function DoUpload(){
var rndURL = (1000*Math.random());
var file = $('#upload')[0].files[0];
if(file){
	name = file.name;
	size = file.size;
	type = file.type;
	}

if(!file){
	AlertMessage("Please select a file.");
	return;
	}

var re = /(\.csv)$/i;
if(!re.exec(name)){
AlertMessage("Data files must be in csv format.");
return;
}

var formData = new FormData($('#uploadform')[0]);

$('#pbar').show();
$('#fup2').show();
$('#fupl').hide();


$.ajax({
		type		: "POST",
		xhr: function() {  // Custom XMLHttpRequest
            var myXhr = $.ajaxSettings.xhr();
            if(myXhr.upload){ // Check if upload property exists
                myXhr.upload.addEventListener('progress',progressHandlingFunction, false); // For handling the progress of the upload
            }
            return myXhr;
        },
		enctype: 'multipart/form-data',
		url		: 'psTables.php',
		data		: formData,
		dataType: "json",
		success: function(data) {
			AlertMessage(data.message);
			if(data.success){
				$('#pbar').hide();
				$('#fupl').show();
				$('#fup2').hide();
				AlertMessage(data.message);
				$('#upload').val("");
				$("#dialog-page").dialog( "close" );
				}
			else{
				$('#pbar').hide();
				$('#fupl').show();
				$('#fup2').hide();
				AlertMessage(data.message);
				}
				
		},
		error: function (xhr, ajaxOptions, thrownError) {
			$('#pbar').hide();
			$('#fupl').show();
			$('#fup2').hide();
        	AlertMessage('There was an error with your upload');
      	},
		cache: false,
        contentType: false,
        processData: false
	});

}

function progressHandlingFunction(e){
    if(e.lengthComputable){
        $('progress').attr({value:e.loaded,max:e.total});
    }
}

function AlertMessage(message,nr){
$('#message').html(message);

 $( "#dialog-message" ).dialog({
      modal: true,
	  resizable: false,
	  width: 600,
      buttons: {
        Ok: function() {
          $( this ).dialog( "close" );
		  var rndURL = (1000*Math.random());
		  	if(!nr){
				window.location="psTables.php?action=manage&tableId="+$('#tableId').val()+"&rnd="+rndURL;
				}
        }
      }
    });
}

function LogOut(){
	var rndURL = (1000*Math.random());
	window.location="psTables.php?action=view&rnd="+rndURL;
}

function DoLogin(){
$.ajax({
		type		: "POST",
		cache	: false,
		url		: "psTables.php",
		data		: $('#loginform').serializeArray(),
		dataType: "json",
		success: function(data) {
			if(data.success==false){
				$('#message').html(data.message);
				 $( "#dialog-message" ).dialog({
					  modal: true,
					  resizable: false,
					  width: 600,
					  buttons: {
						Ok: function() {
						  $( this ).dialog( "close" );
						}
					  }
					});
				}
			else{
				$("#dialog-page").dialog( "close" );
				var rndURL = (1000*Math.random());
				window.location="psTables.php?action=manage&tableId="+$('#tableId').val()+"&rnd="+rndURL;
				}
		}
	});

}