<title>Top 20 Report</title>
<html>
<style>
.subtitler {
font-family: Arial, Helvetica, sans-serif;
font-size: 11px;
font-weight: bold;
color: B60009;
}
.redBG {
 background-color:#990000;
 width:2px;
 }

body,tr,td,p{
font-family: Arial, Helvetica, sans-serif;
font-size: 12px;
}
</style>
<body>
<form>
<input type=button value="Print this Page" onClick="window.print();">
<h2>Top 20 Sire Stakes & State Fair</h2>
<h3>3-YEAR-OLD TROTTING COLTS</h3>
<?php include("http://hhbnys.org/points/PointStatistics.php?DivisionAge=3YO&DivisionGait=Trotting&DivisionSex=Colts&DivisionType=Sire+Stakes&tt=1"); ?>
<h3>3-YEAR-OLD TROTTING FILLIES</h3>
<?php @include("http://hhbnys.org/points/PointStatistics.php?DivisionAge=3YO&DivisionGait=Trotting&DivisionSex=Fillies&DivisionType=Sire+Stakes&tt=1"); ?>
<h3>3-YEAR-OLD PACING COLTS</h3>
<?php @include("http://hhbnys.org/points/PointStatistics.php?DivisionAge=3YO&DivisionGait=Pacing&DivisionSex=Colts&DivisionType=Sire+Stakes&tt=1"); ?>
<h3>3-YEAR-OLD PACING FILLIES</h3>
<?php @include("http://hhbnys.org/points/PointStatistics.php?DivisionAge=3YO&DivisionGait=Pacing&DivisionSex=Fillies&DivisionType=Sire+Stakes&tt=1"); ?>
<h3>2-YEAR-OLD TROTTING COLTS</h3>
<?php @include("http://hhbnys.org/points/PointStatistics.php?DivisionAge=2YO&DivisionGait=Trotting&DivisionSex=Colts&DivisionType=Sire+Stakes&tt=1"); ?>
<h3>2-YEAR-OLD TROTTING FILLIES</h3>
<?php @include("http://hhbnys.org/points/PointStatistics.php?DivisionAge=2YO&DivisionGait=Trotting&DivisionSex=Fillies&DivisionType=Sire+Stakes&tt=1"); ?>
<h3>2-YEAR-OLD PACING COLTS</h3>
<?php @include("http://hhbnys.org/points/PointStatistics.php?DivisionAge=2YO&DivisionGait=Pacing&DivisionSex=Colts&DivisionType=Sire+Stakes&tt=1"); ?>
<h3>2-YEAR-OLD PACING FILLIES</h3>
<?php @include("http://hhbnys.org/points/PointStatistics.php?DivisionAge=2YO&DivisionGait=Pacing&DivisionSex=Fillies&DivisionType=Sire+Stakes&tt=1"); ?>


</form>
</body>