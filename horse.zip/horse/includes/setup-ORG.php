<?
$username='agrifund';
$password='C@pit0l';
$admin_email = 'test@technomosaic.com';

$database='hhbnys_points';
$user='hhbnys_points';
$pass='}r02SsAvfcL$';
$host='localhost';
?>