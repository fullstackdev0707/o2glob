<?

#Created: Monday 1st of July 2013 02:09:44 PM
class raceresults
{
	public $id;
	public $RaceID;
	public $HorseID;
	public $Position;
	public $Points;
	public $Earnings;
	public $DeadHeat;
	public $DriverID;
	public $TrainerID;
	public $Notes;
	public $ts;
}


class raceresultsQueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class raceresults_manager
{
static public function Add($raceresults){
$sql_statement = sprintf("insert into raceresults(RaceID
,HorseID
,Position
,Points
,Earnings
,DeadHeat
,DriverID
,TrainerID
,Notes
,ts
)
values('%d'
,'%d'
,'%d'
,'%s'
,'%.2f'
,'%d'
,'%d'
,'%d'
,'%s'
,'%s'
)",
Utilities::mscrub($raceresults->RaceID)
,Utilities::mscrub($raceresults->HorseID)
,Utilities::mscrub($raceresults->Position)
,Utilities::mscrub($raceresults->Points)
,Utilities::mscrub($raceresults->Earnings)
,Utilities::mscrub($raceresults->DeadHeat)
,Utilities::mscrub($raceresults->DriverID)
,Utilities::mscrub($raceresults->TrainerID)
,Utilities::mscrub($raceresults->Notes)
,Utilities::mscrub($raceresults->ts)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from raceresults where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($raceresults){
$sql_statement = sprintf("update raceresults set
RaceID='%d'
,HorseID='%d'
,Position='%d'
,Points='%s'
,Earnings='%.2f'
,DeadHeat='%d'
,DriverID='%d'
,TrainerID='%d'
,Notes='%s'
,ts='%s'
 where id='%d';
",
Utilities::mscrub($raceresults->RaceID)
,Utilities::mscrub($raceresults->HorseID)
,Utilities::mscrub($raceresults->Position)
,Utilities::mscrub($raceresults->Points)
,Utilities::mscrub($raceresults->Earnings)
,Utilities::mscrub($raceresults->DeadHeat)
,Utilities::mscrub($raceresults->DriverID)
,Utilities::mscrub($raceresults->TrainerID)
,Utilities::mscrub($raceresults->Notes)
,Utilities::mscrub($raceresults->ts)
,Utilities::mscrub($raceresults->id)
);
DoSQL($sql_statement);
}


static public function Getraceresults($id){
$raceresults = new raceresults();
$sql_statement = sprintf("select * from raceresults where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$raceresults->id= $f["id"];
$raceresults->RaceID= $f["RaceID"];
$raceresults->HorseID= $f["HorseID"];
$raceresults->Position= $f["Position"];
$raceresults->Points= $f["Points"];
$raceresults->Earnings= $f["Earnings"];
$raceresults->DeadHeat= $f["DeadHeat"];
$raceresults->DriverID= $f["DriverID"];
$raceresults->TrainerID= $f["TrainerID"];
$raceresults->Notes= $f["Notes"];
$raceresults->ts= $f["ts"];
return $raceresults;
}


static public function GetBy_RaceID_raceresults($RaceID,$orderby = ''){
$q = new raceresultsQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from raceresults where  RaceID = '%s'  %s ",Utilities::mscrub($RaceID)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$raceresults = new raceresults();
$raceresults->id= $f["id"];
$raceresults->RaceID= $f["RaceID"];
$raceresults->HorseID= $f["HorseID"];
$raceresults->Position= $f["Position"];
$raceresults->Points= $f["Points"];
$raceresults->Earnings= $f["Earnings"];
$raceresults->DeadHeat= $f["DeadHeat"];
$raceresults->DriverID= $f["DriverID"];
$raceresults->TrainerID= $f["TrainerID"];
$raceresults->Notes= $f["Notes"];
$raceresults->ts= $f["ts"];
array_push($q->Records,$raceresults);
}
return $q;
}


static public function GetBy_HorseID_raceresults($HorseID,$orderby = ''){
$q = new raceresultsQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from raceresults where  HorseID = '%s'  %s ",Utilities::mscrub($HorseID)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$raceresults = new raceresults();
$raceresults->id= $f["id"];
$raceresults->RaceID= $f["RaceID"];
$raceresults->HorseID= $f["HorseID"];
$raceresults->Position= $f["Position"];
$raceresults->Points= $f["Points"];
$raceresults->Earnings= $f["Earnings"];
$raceresults->DeadHeat= $f["DeadHeat"];
$raceresults->DriverID= $f["DriverID"];
$raceresults->TrainerID= $f["TrainerID"];
$raceresults->Notes= $f["Notes"];
$raceresults->ts= $f["ts"];
array_push($q->Records,$raceresults);
}
return $q;
}


static public function GetBy_DriverID_raceresults($DriverID,$orderby = ''){
$q = new raceresultsQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from raceresults where  DriverID = '%s'  %s ",Utilities::mscrub($DriverID)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$raceresults = new raceresults();
$raceresults->id= $f["id"];
$raceresults->RaceID= $f["RaceID"];
$raceresults->HorseID= $f["HorseID"];
$raceresults->Position= $f["Position"];
$raceresults->Points= $f["Points"];
$raceresults->Earnings= $f["Earnings"];
$raceresults->DeadHeat= $f["DeadHeat"];
$raceresults->DriverID= $f["DriverID"];
$raceresults->TrainerID= $f["TrainerID"];
$raceresults->Notes= $f["Notes"];
$raceresults->ts= $f["ts"];
array_push($q->Records,$raceresults);
}
return $q;
}


static public function GetBy_TrainerID_raceresults($TrainerID,$orderby = ''){
$q = new raceresultsQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from raceresults where  TrainerID = '%s'  %s ",Utilities::mscrub($TrainerID)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$raceresults = new raceresults();
$raceresults->id= $f["id"];
$raceresults->RaceID= $f["RaceID"];
$raceresults->HorseID= $f["HorseID"];
$raceresults->Position= $f["Position"];
$raceresults->Points= $f["Points"];
$raceresults->Earnings= $f["Earnings"];
$raceresults->DeadHeat= $f["DeadHeat"];
$raceresults->DriverID= $f["DriverID"];
$raceresults->TrainerID= $f["TrainerID"];
$raceresults->Notes= $f["Notes"];
$raceresults->ts= $f["ts"];
array_push($q->Records,$raceresults);
}
return $q;
}


static public function DeleteBy_RaceID_raceresults($RaceID){
$sql_statement = sprintf("delete from raceresults where  RaceID = '%s'  ",Utilities::mscrub($RaceID)
);
DoSQL($sql_statement);
}


static public function DeleteBy_HorseID_raceresults($HorseID){
$sql_statement = sprintf("delete from raceresults where  HorseID = '%s'  ",Utilities::mscrub($HorseID)
);
DoSQL($sql_statement);
}


static public function DeleteBy_DriverID_raceresults($DriverID){
$sql_statement = sprintf("delete from raceresults where  DriverID = '%s'  ",Utilities::mscrub($DriverID)
);
DoSQL($sql_statement);
}


static public function DeleteBy_TrainerID_raceresults($TrainerID){
$sql_statement = sprintf("delete from raceresults where  TrainerID = '%s'  ",Utilities::mscrub($TrainerID)
);
DoSQL($sql_statement);
}


static public function SaveBy_RaceID_raceresults($RaceID){
$sql_statement = sprintf("update raceresults set
RaceID='%d'
,HorseID='%d'
,Position='%d'
,Points='%s'
,Earnings='%.2f'
,DeadHeat='%d'
,DriverID='%d'
,TrainerID='%d'
,Notes='%s'
,ts='%s'
 where  RaceID = '%s' ",
Utilities::mscrub($raceresults->RaceID)
,Utilities::mscrub($raceresults->HorseID)
,Utilities::mscrub($raceresults->Position)
,Utilities::mscrub($raceresults->Points)
,Utilities::mscrub($raceresults->Earnings)
,Utilities::mscrub($raceresults->DeadHeat)
,Utilities::mscrub($raceresults->DriverID)
,Utilities::mscrub($raceresults->TrainerID)
,Utilities::mscrub($raceresults->Notes)
,Utilities::mscrub($raceresults->ts)
,Utilities::mscrub($RaceID)
);
DoSQL($sql_statement);
}


static public function SaveBy_HorseID_raceresults($HorseID){
$sql_statement = sprintf("update raceresults set
RaceID='%d'
,HorseID='%d'
,Position='%d'
,Points='%s'
,Earnings='%.2f'
,DeadHeat='%d'
,DriverID='%d'
,TrainerID='%d'
,Notes='%s'
,ts='%s'
 where  HorseID = '%s' ",
Utilities::mscrub($raceresults->RaceID)
,Utilities::mscrub($raceresults->HorseID)
,Utilities::mscrub($raceresults->Position)
,Utilities::mscrub($raceresults->Points)
,Utilities::mscrub($raceresults->Earnings)
,Utilities::mscrub($raceresults->DeadHeat)
,Utilities::mscrub($raceresults->DriverID)
,Utilities::mscrub($raceresults->TrainerID)
,Utilities::mscrub($raceresults->Notes)
,Utilities::mscrub($raceresults->ts)
,Utilities::mscrub($HorseID)
);
DoSQL($sql_statement);
}


static public function SaveBy_DriverID_raceresults($DriverID){
$sql_statement = sprintf("update raceresults set
RaceID='%d'
,HorseID='%d'
,Position='%d'
,Points='%s'
,Earnings='%.2f'
,DeadHeat='%d'
,DriverID='%d'
,TrainerID='%d'
,Notes='%s'
,ts='%s'
 where  DriverID = '%s' ",
Utilities::mscrub($raceresults->RaceID)
,Utilities::mscrub($raceresults->HorseID)
,Utilities::mscrub($raceresults->Position)
,Utilities::mscrub($raceresults->Points)
,Utilities::mscrub($raceresults->Earnings)
,Utilities::mscrub($raceresults->DeadHeat)
,Utilities::mscrub($raceresults->DriverID)
,Utilities::mscrub($raceresults->TrainerID)
,Utilities::mscrub($raceresults->Notes)
,Utilities::mscrub($raceresults->ts)
,Utilities::mscrub($DriverID)
);
DoSQL($sql_statement);
}


static public function SaveBy_TrainerID_raceresults($TrainerID){
$sql_statement = sprintf("update raceresults set
RaceID='%d'
,HorseID='%d'
,Position='%d'
,Points='%s'
,Earnings='%.2f'
,DeadHeat='%d'
,DriverID='%d'
,TrainerID='%d'
,Notes='%s'
,ts='%s'
 where  TrainerID = '%s' ",
Utilities::mscrub($raceresults->RaceID)
,Utilities::mscrub($raceresults->HorseID)
,Utilities::mscrub($raceresults->Position)
,Utilities::mscrub($raceresults->Points)
,Utilities::mscrub($raceresults->Earnings)
,Utilities::mscrub($raceresults->DeadHeat)
,Utilities::mscrub($raceresults->DriverID)
,Utilities::mscrub($raceresults->TrainerID)
,Utilities::mscrub($raceresults->Notes)
,Utilities::mscrub($raceresults->ts)
,Utilities::mscrub($TrainerID)
);
DoSQL($sql_statement);
}


static public function Search($order,$limit,$offset,$query)
{
($query->id)&&($q[] = sprintf("raceresults.id='%d'",Utilities::mscrub($query->id)));
($query->RaceID)&&($q[] = sprintf("raceresults.RaceID='%d'",Utilities::mscrub($query->RaceID)));
($query->HorseID)&&($q[] = sprintf("raceresults.HorseID='%d'",Utilities::mscrub($query->HorseID)));
($query->Position)&&($q[] = sprintf("raceresults.Position='%d'",Utilities::mscrub($query->Position)));
($query->Points)&&($q[] = sprintf("raceresults.Points='%s'",Utilities::mscrub($query->Points)));
($query->Earnings)&&($q[] = sprintf("raceresults.Earnings='%.2f'",Utilities::mscrub($query->Earnings)));
($query->DeadHeat)&&($q[] = sprintf("raceresults.DeadHeat='%d'",Utilities::mscrub($query->DeadHeat)));
($query->DriverID)&&($q[] = sprintf("raceresults.DriverID='%d'",Utilities::mscrub($query->DriverID)));
($query->TrainerID)&&($q[] = sprintf("raceresults.TrainerID='%d'",Utilities::mscrub($query->TrainerID)));
($query->Notes)&&($q[] = sprintf("raceresults.Notes='%s'",Utilities::mscrub($query->Notes)));
($query->ts)&&($q[] = sprintf("raceresults.ts='%s'",Utilities::mscrub($query->ts)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new raceresultsQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from raceresults %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from raceresults %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$raceresults = new raceresults();
$raceresults->id= $f["id"];
$raceresults->RaceID= $f["RaceID"];
$raceresults->HorseID= $f["HorseID"];
$raceresults->Position= $f["Position"];
$raceresults->Points= $f["Points"];
$raceresults->Earnings= $f["Earnings"];
$raceresults->DeadHeat= $f["DeadHeat"];
$raceresults->DriverID= $f["DriverID"];
$raceresults->TrainerID= $f["TrainerID"];
$raceresults->Notes= $f["Notes"];
$raceresults->ts= $f["ts"];
array_push($q->Records,$raceresults);
}


return $q;
}


static public function GetFormraceresults(){
$raceresults = new raceresults();
$raceresults->id= $_REQUEST["id"];
$raceresults->RaceID= $_REQUEST["RaceID"];
$raceresults->HorseID= $_REQUEST["HorseID"];
$raceresults->Position= $_REQUEST["Position"];
$raceresults->Points= $_REQUEST["Points"];
$raceresults->Earnings= $_REQUEST["Earnings"];
$raceresults->DeadHeat= $_REQUEST["DeadHeat"];
$raceresults->DriverID= $_REQUEST["DriverID"];
$raceresults->TrainerID= $_REQUEST["TrainerID"];
$raceresults->Notes= $_REQUEST["Notes"];
$raceresults->ts= $_REQUEST["ts"];
return $raceresults;
}


}



?>