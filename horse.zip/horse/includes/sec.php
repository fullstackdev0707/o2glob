<?
global $loggedinuser;
global $username;
global $password;
global $admin_email;

session_start();
header("Cache-control: private");
$UserName = $_SESSION['UserName'];
$PassWord = $_SESSION['PassWord'];


if((!$UserName)||(!$PassWord)){
	header("Location: index.php");
	exit();
	}

if(($UserName==$username)&&($PassWord==$password)){	
	//valid login
	$loggedinuser=$username;
	}
else{
	header("Location: index.php?m=Invalid+Username+or+Password");
	exit();
	}


?>