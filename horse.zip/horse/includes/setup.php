<?
$username='agrifund';
$password='Chms$ires';
$admin_email = 'marruda@equusmedia.com';

$database='nysspoin_points';
$user='root';//'nysspoin_points';
$pass= '';//'H@rness518';
$host='localhost';
?>