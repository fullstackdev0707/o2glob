<?
class Utilities
{

static public function mswordfix($src){

$src = str_replace("�", "'", $src);
$src = str_replace("�", "'", $src);
$src = str_replace("�", '"', $src);
$src = str_replace("�", '"', $src);
$src = str_replace("�", "-", $src);
$src = str_replace("�", "...", $src);

return $src;
}

static public function fixObject (&$object)
{
  if (!is_object ($object) && gettype ($object) == 'object')
    return ($object = unserialize (serialize ($object)));
  return $object;
}

static public function mfile_put_contents($filename,$contents){
if($fd = fopen($filename,"w")){
	fwrite($fd,stripslashes($contents));
	fclose($fd);
	}
}

static public function multi_attach_mail($to, $files, $sendermail){
     // email fields: to, from, subject, and so on
     $from = "FTW Journal Backup <".$sendermail.">";
    $subject = date("d.M H:i")." Backup";
    $message = date("Y.m.d H:i:s")."\n".count($files)." attachments";
     $headers = "From: $from";

     // boundary
    $semi_rand = md5(time());
    $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";

     // headers for attachment
    $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\"";

     // multipart boundary
    $message = "--{$mime_boundary}\n" . "Content-Type: text/plain; charset=\"iso-8859-1\"\n" .
     "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n";

     // preparing attachments
     for($i=0;$i<count($files);$i++){
         if(is_file($files[$i])){
             $message .= "--{$mime_boundary}\n";
             $fp =    @fopen($files[$i],"rb");
         $data =    @fread($fp,filesize($files[$i]));
                     @fclose($fp);
             $data = chunk_split(base64_encode($data));
             $message .= "Content-Type: application/octet-stream; name=\"".basename($files[$i])."\"\n" .
            "Content-Description: ".basename($files[$i])."\n" .
             "Content-Disposition: attachment;\n" . " filename=\"".basename($files[$i])."\"; size=".filesize($files[$i]).";\n" .
            "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
             }
         }
     $message .= "--{$mime_boundary}--";
     $returnpath = "-f" . $sendermail;
     $ok = mail($to, $subject, $message, $headers, $returnpath);
    if($ok){ return $i; } else { return 0; }
     }

static public function reverseHTML($text){
	#$text = preg_replace("/&#(\d+);/",pack("c",intval("$1")),$text);
	$text =html_entity_decode($text);
	$text = urldecode($text);
	$text = preg_replace("/\&lt;/","<",$text);
	$text = preg_replace("/\&gt;/",">",$text);
	$text = preg_replace("/\&amp;/","&",$text);
	$text = preg_replace("/\&quot;/",'"',$text);
	return $text;
	}

static public function delete_directory($dirname) {
   if (is_dir($dirname))
      $dir_handle = opendir($dirname);
   if (!$dir_handle)
      return false;
   while($file = readdir($dir_handle)) {
      if ($file != "." && $file != "..") {
         if (!is_dir($dirname."/".$file))
            unlink($dirname."/".$file);
         else
            self::delete_directory($dirname.'/'.$file);
      }
   }
   closedir($dir_handle);
   rmdir($dirname);
   return true;
}



static public function copy_directory( $source, $destination ) {
	if ( is_dir( $source ) ) {
		@mkdir( $destination );
		$directory = dir( $source );
		while ( FALSE !== ( $readdirectory = $directory->read() ) ) {
			if ( $readdirectory == '.' || $readdirectory == '..' ) {
				continue;
			}
			$PathDir = $source . '/' . $readdirectory;
			if ( is_dir( $PathDir ) ) {
				self::copy_directory( $PathDir, $destination . '/' . $readdirectory );
				continue;
			}
			copy( $PathDir, $destination . '/' . $readdirectory );
		}

		$directory->close();
	}else {
		copy( $source, $destination );
	}
}

static public function crypt($text)
{
	return crypt($text,SALT);
}

static public function encrypt($text)
{
	return trim(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, SALT, $text, MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND))));
}

static public function decrypt($text)
{
	return trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, SALT, base64_decode($text), MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)));
}


static public function generatePassword($length=9, $strength=0) {
	$vowels = 'aeuy';
	$consonants = 'bdghjmnpqrstvz';
	if ($strength & 1) {
		$consonants .= 'BDGHJLMNPQRSTVWXZ';
	}
	if ($strength & 2) {
		$vowels .= "AEUY";
	}
	if ($strength & 4) {
		$consonants .= '23456789';
	}
	if ($strength & 8) {
		$consonants .= '@#$%';
	}

	$password = '';
	$alt = time() % 2;
	for ($i = 0; $i < $length; $i++) {
		if ($alt == 1) {
			$password .= $consonants[(rand() % strlen($consonants))];
			$alt = 0;
		} else {
			$password .= $vowels[(rand() % strlen($vowels))];
			$alt = 1;
		}
	}
	return $password;
}

static public function CheckExt($rn,$array){
preg_match("/\.(.+)$/",$rn,$match);
list(,$ext) = $match;

if(in_array(strtolower($ext),$array)){
	return true;
	}
else{
	return false;
	}

}

static public function Redirect($url,$alert=''){
    print("<script language=javascript>\n");
    if($alert){
    	print("alert(\"$alert\");\n");
    	}
    print("var rndURL = '&'+(1000*Math.random());\n");
    print("window.location = \"$url\"+rndURL;\n");
    print("</script>\n");
}

static public function PageOut($page){
include($page);
}


static public function PageOutJS($page,$in){


if(!$fd = fopen($page,"r")){
			print "Error opening page<br>";
			exit();
			}
while(!feof($fd)){
	$o = fgets($fd);
	$o = preg_replace("/in\((\w+)\)/",'$in[$1]',$o);
	$o = preg_replace("/\"/",'\"',$o);#'
	$o = preg_replace("/\\n/","\\\\n",$o);
	$o = preg_replace("/(scr)(ipt)/si",'$1"+"$2',$o);

$mylines = preg_split("/\r*\n/",$o);
    foreach ($mylines as $q){
      print "document.write(\"$q\\n\");\n";
      }


	}
fclose($fd);

}



static public function PError($msg){
print "<script language=javascript>
alert(\"$msg\");
history.back();
</script>";
exit();
}

static public function DoSQL($sql){
global $debug;
if($debug){
	print "S: $sql<br>";
	}
$result = mysql_query($sql);
if($err = mysql_error()){
	print "3: $err<br>";
	exit;
	}
return $result;
}


static public function mscrub($string){
	return(mysql_real_escape_string(stripslashes($string)));
	}

static public function scrub($string){
	return(htmlspecialchars(stripslashes($string)));
	}

static public function miniscrub($string){
	$string = stripslashes($string);
	$string = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', "", $string);
	return $string;
	}

static public function scrubjson($str){
	$str = preg_replace("/[^A-Za-z0-9\.\-\/ :\@<>\']/","",$str);
	$str = preg_replace("/'/","\\'",$str);
	return $str;
	}

static public function Sanitize($text)
{
$message="";
$words = array('casino','h1',':','poker','ringtone','@','piss','sex','www','http','gay',
'cock','sucks','dick','pussy','penis','fuck','shit','homo','crap','porn','teensex','teen',
'download','rape','crawl','hooker','href','scam','balls','nuts','pam');

foreach ($words as $word){
	if(preg_match("/$word/",$text)){
		$message = "Permission denied - no profanity, abuse or spam tolerated!";
		}
	}

return $message;
}


static public function valid_email($email){
if((preg_match("/(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)/",$email))||(!preg_match("/^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/",$email))) {
	return false;
	}
else{
	return true;
	}
}

}
?>