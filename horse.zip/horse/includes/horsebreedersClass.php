<?

#Created: Monday 1st of July 2013 02:09:44 PM
class horsebreeders
{
	public $id;
	public $hid;
	public $bid;
	public $isprimary;
}


class horsebreedersQueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class horsebreeders_manager
{
static public function Add($horsebreeders){
$sql_statement = sprintf("insert into horsebreeders(hid
,bid
,isprimary
)
values('%d'
,'%d'
,'%d'
)",
Utilities::mscrub($horsebreeders->hid)
,Utilities::mscrub($horsebreeders->bid)
,Utilities::mscrub($horsebreeders->isprimary)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from horsebreeders where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($horsebreeders){
$sql_statement = sprintf("update horsebreeders set
hid='%d'
,bid='%d'
,isprimary='%d'
 where id='%d';
",
Utilities::mscrub($horsebreeders->hid)
,Utilities::mscrub($horsebreeders->bid)
,Utilities::mscrub($horsebreeders->isprimary)
,Utilities::mscrub($horsebreeders->id)
);
DoSQL($sql_statement);
}


static public function Gethorsebreeders($id){
$horsebreeders = new horsebreeders();
$sql_statement = sprintf("select * from horsebreeders where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$horsebreeders->id= $f["id"];
$horsebreeders->hid= $f["hid"];
$horsebreeders->bid= $f["bid"];
$horsebreeders->isprimary= $f["isprimary"];
return $horsebreeders;
}


static public function GetBy_hid_horsebreeders($hid,$orderby = ''){
$q = new horsebreedersQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from horsebreeders where  hid = '%s'  %s ",Utilities::mscrub($hid)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horsebreeders = new horsebreeders();
$horsebreeders->id= $f["id"];
$horsebreeders->hid= $f["hid"];
$horsebreeders->bid= $f["bid"];
$horsebreeders->isprimary= $f["isprimary"];
array_push($q->Records,$horsebreeders);
}
return $q;
}


static public function GetBy_bid_horsebreeders($bid,$orderby = ''){
$q = new horsebreedersQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from horsebreeders where  bid = '%s'  %s ",Utilities::mscrub($bid)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horsebreeders = new horsebreeders();
$horsebreeders->id= $f["id"];
$horsebreeders->hid= $f["hid"];
$horsebreeders->bid= $f["bid"];
$horsebreeders->isprimary= $f["isprimary"];
array_push($q->Records,$horsebreeders);
}
return $q;
}


static public function DeleteBy_hid_horsebreeders($hid){
$sql_statement = sprintf("delete from horsebreeders where  hid = '%s'  ",Utilities::mscrub($hid)
);
DoSQL($sql_statement);
}


static public function DeleteBy_bid_horsebreeders($bid){
$sql_statement = sprintf("delete from horsebreeders where  bid = '%s'  ",Utilities::mscrub($bid)
);
DoSQL($sql_statement);
}


static public function SaveBy_hid_horsebreeders($hid){
$sql_statement = sprintf("update horsebreeders set
hid='%d'
,bid='%d'
,isprimary='%d'
 where  hid = '%s' ",
Utilities::mscrub($horsebreeders->hid)
,Utilities::mscrub($horsebreeders->bid)
,Utilities::mscrub($horsebreeders->isprimary)
,Utilities::mscrub($hid)
);
DoSQL($sql_statement);
}


static public function SaveBy_bid_horsebreeders($bid){
$sql_statement = sprintf("update horsebreeders set
hid='%d'
,bid='%d'
,isprimary='%d'
 where  bid = '%s' ",
Utilities::mscrub($horsebreeders->hid)
,Utilities::mscrub($horsebreeders->bid)
,Utilities::mscrub($horsebreeders->isprimary)
,Utilities::mscrub($bid)
);
DoSQL($sql_statement);
}


static public function Search($order,$limit,$offset,$query)
{
($query->id)&&($q[] = sprintf("horsebreeders.id='%d'",Utilities::mscrub($query->id)));
($query->hid)&&($q[] = sprintf("horsebreeders.hid='%d'",Utilities::mscrub($query->hid)));
($query->bid)&&($q[] = sprintf("horsebreeders.bid='%d'",Utilities::mscrub($query->bid)));
($query->isprimary)&&($q[] = sprintf("horsebreeders.isprimary='%d'",Utilities::mscrub($query->isprimary)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new horsebreedersQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from horsebreeders %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from horsebreeders %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horsebreeders = new horsebreeders();
$horsebreeders->id= $f["id"];
$horsebreeders->hid= $f["hid"];
$horsebreeders->bid= $f["bid"];
$horsebreeders->isprimary= $f["isprimary"];
array_push($q->Records,$horsebreeders);
}


return $q;
}


static public function GetFormhorsebreeders(){
$horsebreeders = new horsebreeders();
$horsebreeders->id= $_REQUEST["id"];
$horsebreeders->hid= $_REQUEST["hid"];
$horsebreeders->bid= $_REQUEST["bid"];
$horsebreeders->isprimary= $_REQUEST["isprimary"];
return $horsebreeders;
}


}



?>