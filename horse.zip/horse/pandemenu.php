<style>
* {
font-family: arial;
}
</style>