<title>Driver Statistics</title>
<style>
.subtitler {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	font-weight: bold;
	color: B60009;
}
</style>
<h3>Driver Statistics - Sire Stakes and State Fairs</h3>
<?php include("pandemenu.php"); ?>
<table border="1" align=center width=100% title="Driver Statistics">
	<th class="subtitler">Driver</th> <th class="subtitler">Earnings</th> <th class="subtitler">Starters</th> <th class="subtitler">Total Starts</th>
	<th class="subtitler">1st</th> <th class="subtitler">2nd</th> <th class="subtitler">3rd</th> <th class="subtitler">4th</th> <th class="subtitler">5th</th>


<?php
include_once("includes/setup.php");
include_once("includes/db.php");
SelectDB();

$sql_statement = "SELECT Sum(raceresults.Earnings) AS SumOfEarnings, raceresults.DriverID,Drivers.FirstName, Drivers.LastName
FROM raceresults
INNER JOIN races ON raceresults.RaceID = races.id
INNER JOIN people as Drivers ON  Drivers.id=raceresults.DriverID

WHERE
year(races.racedate)= year(DATE_ADD( now( ) , INTERVAL -2 MONTH )) and

(DivisionType like '%Sire Stakes%' or DivisionType like '%State Fair%')
GROUP BY raceresults.DriverID, Drivers.FirstName, Drivers.LastName
ORDER BY Sum(raceresults.Earnings) DESC
";

$result = DoSQL($sql_statement);
while ($f = mysql_fetch_array($result)) {

$DriverID = $f['DriverID'];
$Earnings = number_format($f['SumOfEarnings'],2, '.', ',');
#print "F: $Earnings<br>";
$LastName = $f['LastName'];
$FirstName = $f['FirstName'];

   $position1=0;
   $position2=0;
   $position3=0;
   $position4=0;
   $position5=0;
   $starts=0;
   $starters=0;
   $TEarnings=0;
   $XEarnings=0;

   $have = array();

   if($DriverID > 0){
   		$sql_statement = "select raceresults.HorseID,raceresults.Position, raceresults.Points, raceresults.Earnings from raceresults
inner join horses on horses.id=raceresults.HorseID
inner join races on races.id = raceresults.RaceID
where raceresults.DriverID=$DriverID and year(races.racedate)= year(DATE_ADD( now( ) , INTERVAL -2 MONTH ))
and (DivisionType like '%Sire Stakes%' or DivisionType like '%State Fair%')";

   		$result2 = DoSQL($sql_statement);
	   while ($rows2 = mysql_fetch_array($result2)) {
		   $position = $rows2['Position'];
		   $TEarnings = $rows2['Earnings'];
		   $HorseID = $rows2['HorseID'];
#		   print "H: $HorseID - TE: $TEarnings - P: $position<br>";
		   ($position == 1)&&($position1++);
		   ($position == 2)&&($position2++);
		   ($position == 3)&&($position3++);
		   ($position == 4)&&($position4++);
		   ($position == 5)&&($position5++);
		   $starts++;
		   $XEarnings += $TEarnings;
		   if(!$have{$HorseID}){
			   	$starters++;
			   	}
		   $have{$HorseID}=1;
		   }



   }

   $TEarnings = number_format($TEarnings,2, '.', ',');

   print "<tr>
	<Td width=25% align=\"center\">$LastName, $FirstName</Td>
	<td align=\"center\">\$$Earnings</td>
	<td align=\"center\">$starters &nbsp;</td>
	<td align=\"center\">$starts &nbsp;</td>
	<td align=\"center\">$position1 &nbsp;</td>
	<td align=\"center\">$position2 &nbsp;</td>
	<td align=\"center\">$position3 &nbsp;</td>
	<td align=\"center\">$position4 &nbsp;</td>
	<td align=\"center\">$position5 &nbsp;</td>
	</tr>";


   #print '$'.$Earnings."-".$FirstName.' '.$LastName.'-'.$DriverID.'-'.$XEarnings.'-'.$starters.'-'.$starts.'-'.$position1.'-'.$position2.'-'.$position3.'-'.$position4.'-'.$position5.'<br>';
   }



?>


	</tbody>

</table>

<h3>Driver Statistics - Excelsior</h3>

<table border="1" align=center width=100% title="Driver Statistics">
	<th class="subtitler">Driver</th> <th class="subtitler">Earnings</th> <th class="subtitler">Starters</th> <th class="subtitler">Total Starts</th>
	<th class="subtitler">1st</th> <th class="subtitler">2nd</th> <th class="subtitler">3rd</th> <th class="subtitler">4th</th> <th class="subtitler">5th</th>


<?php

$sql_statement = "SELECT Sum(raceresults.Earnings) AS SumOfEarnings, raceresults.DriverID,Drivers.FirstName, Drivers.LastName
FROM raceresults
INNER JOIN races ON raceresults.RaceID = races.id
INNER JOIN people as Drivers ON  Drivers.id=raceresults.DriverID

WHERE
year(races.racedate)= year(DATE_ADD( now( ) , INTERVAL -2 MONTH )) and

(DivisionType like '%Excelsior%' or DivisionType like '%Late Closers%')
GROUP BY raceresults.DriverID, Drivers.FirstName, Drivers.LastName
ORDER BY Sum(raceresults.Earnings) DESC
";


$result = DoSQL($sql_statement);
while ($f = mysql_fetch_array($result)) {

$DriverID = $f['DriverID'];
$Earnings = number_format($f['SumOfEarnings'],2, '.', ',');
#print "F: $Earnings<br>";
$LastName = $f['LastName'];
$FirstName = $f['FirstName'];

   $position1=0;
   $position2=0;
   $position3=0;
   $position4=0;
   $position5=0;
   $starts=0;
   $starters=0;
   $TEarnings=0;
   $XEarnings=0;

   $have = array();

   if($DriverID > 0){
   		$sql_statement = "select raceresults.HorseID,raceresults.Position, raceresults.Points, raceresults.Earnings from raceresults
		inner join horses on horses.id=raceresults.HorseID
		inner join races on races.id = raceresults.RaceID
		where raceresults.DriverID=$DriverID and year(races.racedate)= year(DATE_ADD( now( ) , INTERVAL -2 MONTH ))
and (DivisionType like '%Excelsior%' or DivisionType like '%Late Closers%')";

   		$result2 = DoSQL($sql_statement);
			   while ($rows2 = mysql_fetch_array($result2)) {
				   $position = $rows2['Position'];
				   $TEarnings = $rows2['Earnings'];
				   $HorseID = $rows2['HorseID'];
		#		   print "H: $HorseID - TE: $TEarnings - P: $position<br>";
				   ($position == 1)&&($position1++);
				   ($position == 2)&&($position2++);
				   ($position == 3)&&($position3++);
				   ($position == 4)&&($position4++);
				   ($position == 5)&&($position5++);
				   $starts++;
				   $XEarnings += $TEarnings;
				   if(!$have{$HorseID}){
					   	$starters++;
					   	}
				   $have{$HorseID}=1;
		   }



   }

   $TEarnings = number_format($TEarnings,2, '.', ',');

   print "<tr>
	<Td width=25% align=\"center\">$LastName, $FirstName</Td>
	<td align=\"center\">\$$Earnings</td>
	<td align=\"center\">$starters &nbsp;</td>
	<td align=\"center\">$starts &nbsp;</td>
	<td align=\"center\">$position1 &nbsp;</td>
	<td align=\"center\">$position2 &nbsp;</td>
	<td align=\"center\">$position3 &nbsp;</td>
	<td align=\"center\">$position4 &nbsp;</td>
	<td align=\"center\">$position5 &nbsp;</td>
	</tr>";


   #print '$'.$Earnings."-".$FirstName.' '.$LastName.'-'.$DriverID.'-'.$XEarnings.'-'.$starters.'-'.$starts.'-'.$position1.'-'.$position2.'-'.$position3.'-'.$position4.'-'.$position5.'<br>';
   }


?>


	</tbody>

</table>


<h3>Driver Statistics - County Fairs</h3>

<table border="1" align=center width=100% title="Driver Statistics">
	<th class="subtitler">Driver</th> <th class="subtitler">Earnings</th> <th class="subtitler">Starters</th> <th class="subtitler">Total Starts</th>
	<th class="subtitler">1st</th> <th class="subtitler">2nd</th> <th class="subtitler">3rd</th> <th class="subtitler">4th</th> <th class="subtitler">5th</th>


<?php



$sql_statement = "SELECT Sum(raceresults.Earnings) AS SumOfEarnings, raceresults.DriverID,Drivers.FirstName, Drivers.LastName
FROM raceresults
INNER JOIN races ON raceresults.RaceID = races.id
INNER JOIN people as Drivers ON  Drivers.id=raceresults.DriverID
WHERE
year(races.racedate)= year(DATE_ADD( now( ) , INTERVAL -2 MONTH )) and
DivisionType like '%County Fair%'
GROUP BY raceresults.DriverID, Drivers.FirstName, Drivers.LastName
ORDER BY Sum(raceresults.Earnings) DESC
";




$result = DoSQL($sql_statement);
while ($f = mysql_fetch_array($result)) {

$DriverID = $f['DriverID'];
$Earnings = number_format($f['SumOfEarnings'],2, '.', ',');
#print "F: $Earnings<br>";
$LastName = $f['LastName'];
$FirstName = $f['FirstName'];

   $position1=0;
   $position2=0;
   $position3=0;
   $position4=0;
   $position5=0;
   $starts=0;
   $starters=0;
   $TEarnings=0;
   $XEarnings=0;

   $have = array();

   if($DriverID > 0){
   		$sql_statement = "select raceresults.HorseID,raceresults.Position, raceresults.Points, raceresults.Earnings from raceresults
				inner join horses on horses.id=raceresults.HorseID
				inner join races on races.id = raceresults.RaceID
				where raceresults.DriverID=$DriverID and year(races.racedate)= year(DATE_ADD( now( ) , INTERVAL -2 MONTH ))
		and (DivisionType like '%County Fair%')";

		   		$result2 = DoSQL($sql_statement);
					   while ($rows2 = mysql_fetch_array($result2)) {
						   $position = $rows2['Position'];
						   $TEarnings = $rows2['Earnings'];
						   $HorseID = $rows2['HorseID'];
				#		   print "H: $HorseID - TE: $TEarnings - P: $position<br>";
						   ($position == 1)&&($position1++);
						   ($position == 2)&&($position2++);
						   ($position == 3)&&($position3++);
						   ($position == 4)&&($position4++);
						   ($position == 5)&&($position5++);
						   $starts++;
						   $XEarnings += $TEarnings;
						   if(!$have{$HorseID}){
							   	$starters++;
							   	}
						   $have{$HorseID}=1;
		   }



   }

   $TEarnings = number_format($TEarnings,2, '.', ',');

   print "<tr>
	<Td width=25% align=\"center\">$LastName, $FirstName</Td>
	<td align=\"center\">\$$Earnings</td>
	<td align=\"center\">$starters &nbsp;</td>
	<td align=\"center\">$starts &nbsp;</td>
	<td align=\"center\">$position1 &nbsp;</td>
	<td align=\"center\">$position2 &nbsp;</td>
	<td align=\"center\">$position3 &nbsp;</td>
	<td align=\"center\">$position4 &nbsp;</td>
	<td align=\"center\">$position5 &nbsp;</td>
	</tr>";


   #print '$'.$Earnings."-".$FirstName.' '.$LastName.'-'.$DriverID.'-'.$XEarnings.'-'.$starters.'-'.$starts.'-'.$position1.'-'.$position2.'-'.$position3.'-'.$position4.'-'.$position5.'<br>';
   }


?>


	</tbody>

</table>

