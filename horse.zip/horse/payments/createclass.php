<?
//include("setup.php");

$database='hhbnys_points';
$user='hhbnys_points';
$pass='}r02SsAvfcL$';
$host='localhost';

$debug=1;

SelectDB();

print "<pre>Started:".date('l jS \of F Y h:i:s A')."\n";

$tables = array();

$sql_statement = "show tables";
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
array_push($tables,$f[0]);
}


foreach($tables as $table){
print "Reading: $table\n";
ReadTable($table);
}


function ReadTable($table){


$fields = array();
$indexes = array();

$sql_statement = sprintf("show columns from %s",mscrub($table));
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$field = new TableDef();
$field->Field = $f["Field"];
$field->Type = $f["Type"];
$field->Null = $f["Null"];
$field->Key = $f["Key"];
$field->Default = $f["Default"];
$field->Extra = $f["Extra"];
array_push($fields,$field);
}

$idx = array();

#SHOW INDEXES FROM advertisers
$sql_statement = sprintf("show indexes from %s",mscrub($table));
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){

if($indexes[$f["Key_name"]]){
	$index->Column_name[] = $f["Column_name"];
	}
else{
	$index = new IndexDef();
	$index->Column_name = array();
	$index->Table = $f["Table"];
	$index->Non_unique = $f["Non_unique"];
	$index->Key_name = $f["Key_name"];
	$index->Seq_in_index = $f["Seq_in_index"];
	$index->Column_name[] = $f["Column_name"];
	$index->Collation = $f["Collation"];
	$index->Cardinality = $f["Cardinality"];
	$index->Sub_part = $f["Sub_part"];
	$index->Packed = $f["Packed"];
	$index->Null = $f["Null"];
	$index->Index_type = $f["Index_type"];
	$index->Comment = $f["Comment"];
	$indexes[$f["Key_name"]] = $index;
	}

}


CreateClass($fields,$table);
CreateClassManager($fields,$table,$indexes);
#exit();
}


function CreateClass($fields,$table){

$buffer='#Created: '.date('l jS \of F Y h:i:s A')."\n";

print "#---- class $table start -- \n";
$buffer .= "class $table\n";
$buffer .= "{\n";

foreach ($fields as $field){
$buffer .= "\tpublic \$".$field->Field.";\n";
}

$buffer .= "}\n\n\n";


$buffer .= "class ${table}QueryResults\n";
$buffer .= "{\n";
$buffer .= "	public \$TotalRecs=0;\n";
$buffer .= "	public \$Records;\n";
$buffer .= "}\n\n\n";


print "#---- class $table end -- \n";

$fp = fopen("tmp/${table}Class.php", w);
fwrite($fp, "<?\n\n".$buffer);
fclose($fp);

}


function CreateClassManager($fields,$table,$indexes){

$buffer='';

print "#---- class ${table}_manager start -- \n";
$buffer .=  "class ${table}_manager\n";
$buffer .=  "{\n";

#print_r($fields);

$tmp = array();
foreach ($fields as $field){
if($field->Key == 'PRI'){
	continue;
	}
array_push($tmp,$field->Field."\n");
}
$collist = join(",",$tmp);

#print "C: $collist\n";


$tmp = array();
foreach ($fields as $field){
if($field->Key == 'PRI'){
	continue;
	}
if(preg_match("/int/",$field->Type)){
	array_push($tmp,$field->Field."='%d'\n");
	}
elseif(preg_match("/decimal/",$field->Type)){
	array_push($tmp,$field->Field."='%.2f'\n");
	}
elseif(preg_match("/date/",$field->Type)){
	array_push($tmp,$field->Field."=%s\n");
	}	
else{
	array_push($tmp,$field->Field."='%s'\n");
	}
}
$savelist = join(",",$tmp);


$tmp = array();
foreach ($fields as $field){
if($field->Key == 'PRI'){
	continue;
	}
if(preg_match("/int/",$field->Type)){
	array_push($tmp,"'%d'\n");
	}
elseif(preg_match("/decimal/",$field->Type)){
	array_push($tmp,"'%.2f'\n");
	}
elseif(preg_match("/date/",$field->Type)){
	array_push($tmp,"%s\n");
	}	
else{
	array_push($tmp,"'%s'\n");
	}
}
$spflist = join(",",$tmp);

#print "S: $spflist\n";

$tmp = array();
foreach ($fields as $field){
if($field->Key == 'PRI'){
	continue;
	}
if(preg_match("/date/",$field->Type)){	
	array_push($tmp,"(\$".$table."->".$field->Field.")?\"'\".Utilities::mscrub(\$".$table."->".$field->Field.").\"'\":'null'\n");
	}
else{		
	array_push($tmp,"Utilities::mscrub(\$".$table."->".$field->Field.")\n");
	}
}

$fieldlist = join(",",$tmp);

#print "F: $fieldlist\n";

#Add
$buffer .=  "static public function Add(\$$table){\n";
$buffer .=  "\$sql_statement = sprintf(\"insert into $table($collist)\n";
$buffer .=  "values($spflist)\",\n";
$buffer .=  $fieldlist;
$buffer .=  ");\n";
$buffer .=  "DoSQL(\$sql_statement);\n";
$buffer .=  "return mysql_insert_id();\n";
$buffer .=  "}\n";
$buffer .=  "\n\n";

#delete
$buffer .=  "static public function Delete(\$id){\n";
$buffer .=  "\$sql_statement = sprintf(\"delete from $table where id='%d'\",Utilities::mscrub(\$id));\n";
$buffer .=  "DoSQL(\$sql_statement);\n";
$buffer .=  "}\n";
$buffer .=  "\n\n";


#save
$buffer .=  "static public function Save(\$$table){\n";
$buffer .=  "\$sql_statement = sprintf(\"update $table set\n";
$buffer .=  $savelist;
$buffer .= " where id='%d';\n";
$buffer .=  "\",\n";
$buffer .=  $fieldlist;
$buffer .=  ",Utilities::mscrub(\$".$table."->id)\n";
$buffer .=  ");\n";
$buffer .=  "DoSQL(\$sql_statement);\n";
$buffer .=  "}\n";
$buffer .=  "\n\n";

#get
$buffer .=  "static public function Get{$table}(\$id){\n";
$buffer .=  "\$$table = new ${table}();\n";
$buffer .=  "\$sql_statement = sprintf(\"select * from $table where id='%d'\",Utilities::mscrub(\$id));\n";
$buffer .=  "\$result = DoSQL(\$sql_statement);\n";
$buffer .=  "\$f = mysql_fetch_array(\$result);\n";

foreach($fields as $field){
	$buffer .=  "\$${table}->".$field->Field."= \$f[\"".$field->Field."\"];\n";
	}
$buffer .=  "return \$${table};\n";

$buffer .=  "}\n";
$buffer .=  "\n\n";


#getby

foreach($indexes as $key => $index){

if($index->Key_name == 'PRIMARY'){
	continue;
	}


$tmp = array();
foreach($index->Column_name as $field){
	array_push($tmp,'$'.$field);
	}
array_push($tmp,"\$orderby = ''");
$sf = join(",",$tmp);

##getby
$buffer .=  "static public function GetBy_".$index->Key_name."_{$table}($sf){\n";


$buffer .=  "\$q = new ${table}QueryResults();\n";
$buffer .=  "\$q->Records = array();\n";

$buffer .="if(\$orderby){\n";
$buffer .="\$orderby = ' order by ' . \$orderby;\n";
$buffer .="}\n";

$buffer .=  "\$sql_statement = sprintf(\"select * from $table where ";

$tmp = array();
foreach($index->Column_name as $field){
	array_push($tmp," $field = '%s' ");
	}
$buffer .= join(" and ",$tmp);


$buffer .=  " %s \"";


foreach($index->Column_name as $field){
	$buffer .=  ",Utilities::mscrub(\$$field)\n";
	}

$buffer .=  ",Utilities::mscrub(\$orderby)\n";

$buffer .=  ");\n";

$buffer .=  "\$result = DoSQL(\$sql_statement);\n";
$buffer .=  "while(\$f = mysql_fetch_array(\$result)){\n";
$buffer .=  "\$$table = new ${table}();\n";

foreach($fields as $field){
	$buffer .=  "\$${table}->".$field->Field."= \$f[\"".$field->Field."\"];\n";
	}
$buffer .=  "array_push(\$q->Records,\$${table});\n";
$buffer .=  "}\n";
$buffer .=  "return \$q;\n";
$buffer .=  "}\n";
$buffer .=  "\n\n";

}


#deleteby
foreach($indexes as $key => $index){
if($index->Key_name == 'PRIMARY'){
	continue;
	}
$tmp = array();
foreach($index->Column_name as $field){
	array_push($tmp,'$'.$field);
	}
$sf = join(",",$tmp);

##deleteby
$buffer .=  "static public function DeleteBy_".$index->Key_name."_{$table}($sf){\n";
$buffer .=  "\$sql_statement = sprintf(\"delete from $table where ";
$tmp = array();
foreach($index->Column_name as $field){
	array_push($tmp," $field = '%s' ");
	}
$buffer .= join(" and ",$tmp);
$buffer .=  " \"";
foreach($index->Column_name as $field){
	$buffer .=  ",Utilities::mscrub(\$$field)\n";
	}
$buffer .=  ");\n";
$buffer .=  "DoSQL(\$sql_statement);\n";
$buffer .=  "}\n";
$buffer .=  "\n\n";
}



#saveby
foreach($indexes as $key => $index){
if($index->Key_name == 'PRIMARY'){
	continue;
	}

$tmp = array();
foreach($index->Column_name as $field){
	array_push($tmp,'$'.$field);
	}
$sf = join(",",$tmp);

$buffer .=  "static public function SaveBy_".$index->Key_name."_{$table}($sf){\n";
$buffer .=  "\$sql_statement = sprintf(\"update $table set\n";
$buffer .=  $savelist;
$buffer .= " where ";

$tmp = array();
foreach($index->Column_name as $field){
	array_push($tmp," $field = '%s' ");
	}
$buffer .= join(" and ",$tmp);
$buffer .=  "\",\n";
$buffer .=  $fieldlist;

foreach($index->Column_name as $field){
	$buffer .=  ",Utilities::mscrub(\$$field)\n";
	}

$buffer .=  ");\n";
$buffer .=  "DoSQL(\$sql_statement);\n";
$buffer .=  "}\n";
$buffer .=  "\n\n";
}




#search
$buffer .=  "static public function Search(\$order,\$limit,\$offset,\$query,\$addfilter='')\n";
$buffer .=  "{\n";


foreach($fields as $field){
$s='';
if(preg_match("/int/",$field->Type)){
	$s='%d';
	}
elseif(preg_match("/decimal/",$field->Type)){
	$s='%.2f';
	}
else{
	$s='%s';
	}

$buffer .=  "(\$query->".$field->Field.")&&(\$q[] = sprintf(\"${table}.".$field->Field."='$s'\",Utilities::mscrub(\$query->".$field->Field.")));\n";

}


$buffer .=  "if(sizeof(\$q) > 0){\n";
$buffer .=  "\$query = ' where '.join(\" and \",\$q);\n";
$buffer .=  "}\n";
$buffer .=  "else{\n";
$buffer .=  "\$query='';\n";
$buffer .=  "}\n";
$buffer .=  "\n";
$buffer .=  "\$q = new ${table}QueryResults();\n";
$buffer .=  "\$q->Records = array();\n";
$buffer .=  "\n";
$buffer .=  "if(\$limit > 0){\n";
$buffer .=  "	\$limit = \"LIMIT \$limit\";\n";
$buffer .=  "	}\n";
$buffer .=  "else{\n";
$buffer .=  "\$limit='';\n";
$buffer .=  "}\n";
$buffer .=  "\n";
$buffer .=  "if(\$offset > 0){\n";
$buffer .=  "	\$offset = \"OFFSET \$offset\";\n";
$buffer .=  "	}\n";
$buffer .=  "else{\n";
$buffer .=  "\$offset='';\n";
$buffer .=  "}\n";

$buffer .=  "if(\$addfilter){\n";
$buffer .=  "	if(!\$query){\n";
$buffer .=  "		\$query = ' where ' . \$addfilter;\n";
$buffer .=  "	}\n";
$buffer .=  "	else{\n";
$buffer .=  "		\$query = ' and ' . \$addfilter;\n";
$buffer .=  "	}\n";
$buffer .=  "}\n";

$buffer .=  "\$sql_statement = sprintf(\"select count(*) as cnt from ${table} %s\",\$query);\n";
$buffer .=  "\$result = DoSQL(\$sql_statement);\n";
$buffer .=  "\$f = mysql_fetch_array(\$result);\n";
$buffer .=  "\$q->TotalRecs =  \$f[\"cnt\"];\n";

$buffer .=  "\$sql_statement = sprintf(\"select * from ${table} %s order by %s %s %s\",\$query,\$order,\$limit,\$offset);\n";
$buffer .=  "\$result = DoSQL(\$sql_statement);\n";
$buffer .=  "while(\$f = mysql_fetch_array(\$result)){\n";
$buffer .=  "\$$table = new ${table}();\n";
foreach($fields as $field){
	$buffer .=  "\$${table}->".$field->Field."= \$f[\"".$field->Field."\"];\n";
	}

$buffer .=  "array_push(\$q->Records,\$${table});\n";
$buffer .=  "}\n";
$buffer .=  "\n";
$buffer .=  "\n";
$buffer .=  "return \$q;\n";
$buffer .=  "}\n\n\n";


#get form vars

#get
$buffer .=  "static public function GetForm{$table}(){\n";
$buffer .=  "\$$table = new ${table}();\n";

foreach($fields as $field){
	$buffer .=  "\$${table}->".$field->Field."= \$_REQUEST[\"".$field->Field."\"];\n";
	}
$buffer .=  "return \$${table};\n";

$buffer .=  "}\n";
$buffer .=  "\n\n";


$buffer .=  "}\n\n";

$fp = fopen("tmp/${table}Class.php", a);
fwrite($fp, $buffer."\n\n?>");
fclose($fp);


print "#---- class ${table}_manager end -- \n";
}



function mscrub($string){
	return(mysql_real_escape_string(stripslashes($string)));
	}

function PError($msg){
?>
<script language=javascript>
alert("<? print("$msg"); ?>");
history.back();
</script>
<?
exit();
}

function DoSQL($sql){
global $debug;
if($debug){
	print "S: $sql<br>";
	}
$result = mysql_query($sql);
if($err = mysql_error()){
	print "3: $err<br>";
	exit;
	}
return $result;
}

function dbexit(){
mysql_close();
exit();
}


function SelectDB(){
global $debug;
global $database;
global $user;
global $pass;
global $host;

if($debug){
	print("mysql_connect($host,$user,$pass)<br>");
	}
if(!mysql_connect($host,$user,$pass)){
	print ("1".mysql_error());
	dbexit();
	}
if($debug){
	print("mysql_select_db($database)<br>");
	}
if(!mysql_select_db($database)){
	$error = mysql_error();
	print ("2: ".$error);
	dbexit();
	}
}

class TableDef{
public $Field;
public $Type;
public $Null;
public $Key;
public $Default;
public $Extra;
}

class IndexDef{
public $Table;
public $Non_unique;
public $Key_name;
public $Seq_in_index;
public $Column_name;
public $Collation;
public $Cardinality;
public $Sub_part;
public $Packed;
public $Null;
public $Index_type;
public $Comment;
}

?>