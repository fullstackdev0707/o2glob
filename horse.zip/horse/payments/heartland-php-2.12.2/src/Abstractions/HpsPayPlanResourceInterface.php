<?php

/**
 * Interface HpsPayPlanResourceInterface
 */
interface HpsPayPlanResourceInterface
{
    public static function getEditableFields();
    public static function getSearchableFields();
}
