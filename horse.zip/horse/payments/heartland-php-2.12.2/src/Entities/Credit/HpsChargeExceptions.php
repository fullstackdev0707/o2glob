<?php

/**
 * Class HpsChargeExceptions
 */
class HpsChargeExceptions
{
    public $cardException = null;
    public $hpsException  = null;
}
