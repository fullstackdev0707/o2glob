<?php

/**
 * Class HpsCharge
 */
class HpsCharge extends HpsAuthorization
{
}
