<?php

/**
 * Class HpsSecureEcommerce
 */
class HpsSecureEcommerce
{
    public $dataSource = null;
    public $type       = null;
    public $data       = null;
    public $eciFlag    = null;
    public $xid        = null;
}
