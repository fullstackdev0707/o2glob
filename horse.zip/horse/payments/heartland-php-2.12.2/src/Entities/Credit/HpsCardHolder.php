<?php

/**
 * Class HpsCardHolder
 */
class HpsCardHolder extends HpsConsumer
{
}
