<?php

/**
 * Class HpsAccountVerify
 */
class HpsAccountVerify extends HpsAuthorization
{
}
