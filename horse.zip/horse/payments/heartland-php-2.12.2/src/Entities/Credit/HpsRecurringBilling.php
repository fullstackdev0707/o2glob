<?php

/**
 * Class HpsRecurringBilling
 */
class HpsRecurringBilling extends HpsAuthorization
{
}
