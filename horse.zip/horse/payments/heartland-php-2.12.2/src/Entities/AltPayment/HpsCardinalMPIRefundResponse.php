<?php

/**
 * Class HpsCardinalMPIRefundResponse
 */
class HpsCardinalMPIRefundResponse extends HpsCardinalMPIResponse
{
    /**
     * @param        $data
     * @param string $returnType
     *
     * @return mixed
     */
    public static function fromObject($data, $returnType = 'HpsCardinalMPIRefundResponse')
    {
        return parent::fromObject($data, $returnType);
    }
}