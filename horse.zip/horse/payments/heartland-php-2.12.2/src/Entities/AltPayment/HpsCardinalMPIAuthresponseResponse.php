<?php

/**
 * Class HpsCardinalMPIAuthresponseResponse
 */
class HpsCardinalMPIAuthresponseResponse extends HpsCardinalMPIResponse
{
    /**
     * @param        $data
     * @param string $returnType
     *
     * @return mixed
     */
    public static function fromObject($data, $returnType = 'HpsCardinalMPIAuthresponseResponse')
    {
        return parent::fromObject($data, $returnType);
    }
}