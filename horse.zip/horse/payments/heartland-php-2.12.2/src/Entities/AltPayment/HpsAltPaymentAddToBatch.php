<?php

/**
 * Class HpsAltPaymentAddToBatch
 */
class HpsAltPaymentAddToBatch extends HpsAuthorization
{
}
