<?php

/**
 * Class HpsCardinalMPICaptureResponse
 */
class HpsCardinalMPICaptureResponse extends HpsCardinalMPIResponse
{
    /**
     * @param        $data
     * @param string $returnType
     *
     * @return mixed
     */
    public static function fromObject($data, $returnType = 'HpsCardinalMPICaptureResponse')
    {
        return parent::fromObject($data, $returnType);
    }
}