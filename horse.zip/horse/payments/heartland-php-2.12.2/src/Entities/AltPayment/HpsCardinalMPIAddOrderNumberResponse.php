<?php

/**
 * Class HpsCardinalMPIAddOrderNumberResponse
 */
class HpsCardinalMPIAddOrderNumberResponse extends HpsCardinalMPIResponse
{
    /**
     * @param        $data
     * @param string $returnType
     *
     * @return mixed|void
     */
    public static function fromObject($data, $returnType = 'HpsCardinalMPIAddOrderNumberResponse')
    {
        parent::fromObject($data, $returnType);
    }
}