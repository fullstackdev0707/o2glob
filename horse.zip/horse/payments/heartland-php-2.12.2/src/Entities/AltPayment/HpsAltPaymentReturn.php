<?php

/**
 * Class HpsAltPaymentReturn
 */
class HpsAltPaymentReturn extends HpsAltPaymentResponse
{
}
