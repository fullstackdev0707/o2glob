<?php

/**
 * Class HpsGiftCardBalance
 */
class HpsGiftCardBalance extends HpsGiftCardActivate
{
}
