<?php

/**
 * Class HpsGiftCardAddValue
 */
class HpsGiftCardAddValue extends HpsGiftCardActivate
{
}
