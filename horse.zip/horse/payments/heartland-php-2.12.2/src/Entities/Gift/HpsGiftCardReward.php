<?php

/**
 * Class HpsGiftCardReward
 */
class HpsGiftCardReward extends HpsGiftCardActivate
{
}
