<?php

/**
 * Class HpsConsumer
 */
class HpsConsumer
{
    public $firstName = null;
    public $lastName  = null;
    public $phone     = null;
    public $email     = null;
    public $address   = null;
}
