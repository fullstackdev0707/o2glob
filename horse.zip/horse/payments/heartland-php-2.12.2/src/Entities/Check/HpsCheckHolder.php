<?php

/**
 * Class HpsCheckHolder
 */
class HpsCheckHolder extends HpsConsumer
{
    public $checkName    = null;
    public $dlState      = null;
    public $dlNumber     = null;
    public $ssl4         = null;
    public $dobYear      = null;
    public $courtesyCard = null;
}
