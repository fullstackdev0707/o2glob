<?php

/**
 * Class HpsCheckResponseDetails
 */
class HpsCheckResponseDetails
{
    public $messageType = null;
    public $code        = null;
    public $message     = null;
    public $fieldNumber = null;
    public $fieldName   = null;
}
