<?php

/**
 * Class HpsSECCode
 */
abstract class HpsSECCode
{
    const PPD     = 'PPD';
    const CCD     = 'CCD';
    const POP     = 'POP';
    const WEB     = 'WEB';
    const TEL     = 'TEL';
    const EBRONZE = 'eBronze';
}
