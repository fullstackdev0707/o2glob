<?php

/**
 * Class HpsCentinelCheckoutType
 */
class HpsCentinelCheckoutType
{
    const LIGHTBOX         = 'lightbox';
    const CONNECT          = 'connect';
    const PAIRING          = 'pairing';
    const PAIRING_CHECKOUT = 'pairingcheckout';
}
