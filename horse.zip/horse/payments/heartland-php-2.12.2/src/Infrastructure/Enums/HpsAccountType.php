<?php

/**
 * Class HpsAccountType
 */
abstract class HpsAccountType
{
    const CHECKING = 'Checking';
    const SAVINGS  = 'Savings';
}
