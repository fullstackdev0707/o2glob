<?php

/**
 * Class HpsTaxType
 */
abstract class HpsTaxType
{
    const NOT_USED   = 'NOTUSED';
    const SALES_TAX  = 'SALESTAX';
    const TAX_EXEMPT = 'TAXEXEMPT';
}
