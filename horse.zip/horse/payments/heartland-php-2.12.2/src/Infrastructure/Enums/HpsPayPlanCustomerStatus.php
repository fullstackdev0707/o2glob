<?php

/**
 * Class HpsPayPlanCustomerStatus
 */
abstract class HpsPayPlanCustomerStatus
{
    const ACTIVE   = 'Active';
    const INACTIVE = 'Inactive';
}
