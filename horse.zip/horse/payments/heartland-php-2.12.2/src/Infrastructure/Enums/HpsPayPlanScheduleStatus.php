<?php

/**
 * Class HpsPayPlanScheduleStatus
 */
abstract class HpsPayPlanScheduleStatus extends HpsPayPlanCustomerStatus
{
    const FAILED = 'FAILED';
}
