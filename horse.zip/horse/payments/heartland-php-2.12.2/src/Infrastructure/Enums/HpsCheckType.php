<?php

/**
 * Class HpsCheckType
 */
abstract class HpsCheckType
{
    const PERSONAL = 'PERSONAL';
    const BUSINESS = 'BUSINESS';
}
