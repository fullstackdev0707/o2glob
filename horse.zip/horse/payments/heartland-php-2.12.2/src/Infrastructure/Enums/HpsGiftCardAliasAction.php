<?php

/**
 * Class HpsGiftCardAliasAction
 */
abstract class HpsGiftCardAliasAction
{
    const DELETE = 'DELETE';
    const ADD    = 'ADD';
    const CREATE = 'CREATE';
}
