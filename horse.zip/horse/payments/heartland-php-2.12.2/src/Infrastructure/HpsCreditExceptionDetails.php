<?php

/**
 * Class HpsCreditExceptionDetails
 */
class HpsCreditExceptionDetails
{
    public $issuerResponseCode = null;
    public $issuerResponseText = null;
}
