<?php

/**
 * Class HpsGatewayExceptionDetails
 */
class HpsGatewayExceptionDetails
{
    public $gatewayResponseCode    = null;
    public $gatewayResponseMessage = null;
}
