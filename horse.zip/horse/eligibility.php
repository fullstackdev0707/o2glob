<?php
include_once("includes/setup.php");
include_once("includes/db.php");
include_once("includes/Utilities.php");

class eligdata{
	public $id;
	public $ss;
	public $ex;
	public $cf;
	}

SelectDB();

$m = date('m');
$d = date('d');

$Age=Utilities::mscrub($_REQUEST['a']);
$Gait=Utilities::mscrub($_REQUEST['g']);
$Sex=Utilities::mscrub($_REQUEST['s']);


//ELIGIBLE 2-YEAR-OLD PACING COLTS
//ELIGIBLE 2-YEAR-OLD PACING FILLIES
//ELIGIBLE 2-YEAR-OLD TROTTING COLTS
//ELIGIBLE 2-YEAR-OLD TROTTING FILLIES

//ELIGIBLE 3-YEAR-OLD PACING COLTS
//ELIGIBLE 3-YEAR-OLD PACING FILLIES
//ELIGIBLE 3-YEAR-OLD TROTTING COLTS
//ELIGIBLE 3-YEAR-OLD TROTTING FILLIES)

if($Age == '1'){
			$q[] = "year(now()) - horses.YOF = 1";
			}
if($Age == '2'){
			$q[] = "year(now()) - horses.YOF = 2";
			}
if($Age == '3'){
			$q[] = "year(now()) - horses.YOF = 3";
			}

if($Sex == 'C'){
			$q[] = "horses.Sex = 'C'";
			$titleSex='COLTS';
			}

if($Sex == 'F'){
			$q[] = "horses.Sex = 'F'";
			$titleSex='FILLIES';
			}

if($Gait == 'T'){
			$q[] = "horses.Gait = 'T'";
			$titleGait='TROTTING';
			}

if($Gait == 'P'){
			$q[] = "horses.Gait = 'P'";
			$titleGait='PACING';
			}

if(sizeof($q) > 0){
	$query = 'and (' . join(" and ",$q).') ';
	}
else{
	$query='';
	}

if($_REQUEST['o']=='HorseID'){
	$orderby = 'horses.HorseID';
	}

if($_REQUEST['o']=='Horse'){
	$orderby = 'horses.Horse';
	}

if($_REQUEST['o']=='Sire'){
	$orderby = 'Sire.Horse';
	}

if($_REQUEST['o']=='Dam'){
	$orderby = 'Dam.Horse';
	}



if($_REQUEST['d']=='desc'){
	$orderby .= ' desc';
	}


if($Age > 0){
if($_REQUEST['o']=='SS'){
	if($_REQUEST['d']=='desc'){
		$orderby = "concat(horses._${Age}YOfeb_SS,horses._${Age}YOapr_SS) desc,trim(horses.Horse)";
		}
	else{
		$orderby = "concat(horses._${Age}YOfeb_SS,horses._${Age}YOapr_SS),trim(horses.Horse)";
		}
	}


if($_REQUEST['o']=='EX'){
	if($_REQUEST['d']=='desc'){
		$orderby = "concat(horses._${Age}YOfeb_EX,horses._${Age}YOapr_EX) desc,trim(horses.Horse)";
		}
	else{
		$orderby = "concat(horses._${Age}YOfeb_EX,horses._${Age}YOapr_EX),trim(horses.Horse)";
		}
	}

if($_REQUEST['o']=='CF'){
	if($_REQUEST['d']=='desc'){
		$orderby = "concat(horses._${Age}YOfeb_CF,horses._${Age}YOapr_CF) desc,trim(horses.Horse)";
		}
	else{
		$orderby = "concat(horses._${Age}YOfeb_CF,horses._${Age}YOapr_CF),trim(horses.Horse)";
		}
	}
}



if(!$orderby){
	$orderby = 'horses.Horse';
	}


//provisional elig
$cy = date('Y');
$isprov=0;
if((time() >= strtotime('01/01/'.$cy))&&(time() < strtotime('01/21/'.$cy))){
$isprov=1;

$attention = "<font color=red><b><center>ATTENTION</center>

The payment information below reflects all payments made in the previous year.<br>
<br>
These payments will appear until January 21 of each year.<br>
<br>
This is to facilitate eligibility status for the sales and for the upcoming payments due in the current year.<br>
<br>
After January 21st of each year these lists will change to show only the payments made in the current year.<br>
</b></font><br><br>
";
}
//print "<!-- isprov: $isprov -->";

$isprov1=0;
$isprov2=0;
$isprov3=0;

if((time() >= strtotime('01/01/'.$cy))&&(time() < strtotime('02/17/'.$cy))){
	$isprov1=1;
	}

if((time() >= strtotime('02/18/'.$cy))&&(time() < strtotime('12/31/'.$cy))){
	$isprov2=1;
	}

if((time() >= strtotime('04/18/'.$cy))&&(time() < strtotime('12/31/'.$cy))){
	$isprov3=1;
	}

$alleligdata=array();

$sql_statement = sprintf("select horses.*,Sire.Horse as SireName,Dam.Horse as DamName from horses
left join horses as Sire on Sire.id = horses.Sire
left join horses as Dam on Dam.id = horses.Dam
where 1 %s order by $orderby",$query);
$result = DoSQL($sql_statement);
//print "<!-- $sql_statement -->";

while($f = mysql_fetch_array($result)){


$imgSS1="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";
$imgSS2="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";
$imgEX1="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";
$imgEX2="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";
$imgCF1="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";
$imgCF2="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";

$elig1=0;
$elig2=0;

##added 1/27/2015
($f['sup1'] == 500)&&($f['_1YO'] = 'Y');

if(($Age == '2')||($isprov)){

//if( $f['Horse'] == 'Believe In Him'){
//print "<!--\n";
//print_r($f);
//print "-->\n";
//}

($f['_2YOfeb_SS'] == 'Y')&&($elig1=1)&&($imgSS1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_2YOfeb_EX'] == 'Y')&&($elig1=1)&&($imgEX1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_2YOfeb_CF'] == 'Y')&&($elig1=1)&&($imgCF1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_2YOapr_SS'] == 'Y')&&($elig2=1)&&($imgSS2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_2YOapr_EX'] == 'Y')&&($elig2=1)&&($imgEX2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_2YOapr_CF'] == 'Y')&&($elig2=1)&&($imgCF2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");


//No 2YO feb/apr payments = maybe/maybe
if(($f['_1YO'] == 'Y')&&($f['_2YOfeb_SS'] != 'Y')&&($f['_2YOapr_SS'] != 'Y')){
	$imgSS1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$imgSS2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$elig1=1;
	$elig2=1;
	}
if(($f['_1YO'] == 'Y')&&($f['_2YOfeb_EX'] != 'Y')&&($f['_2YOapr_EX'] != 'Y')){
	$imgEX1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$imgEX2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$elig1=1;
	$elig2=1;
	}
if(($f['_1YO'] == 'Y')&&($f['_2YOfeb_CF'] != 'Y')&&($f['_2YOapr_CF'] != 'Y')){
	$imgCF1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$imgCF2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$elig1=1;
	$elig2=1;
	}

//2YO feb payment but no apr payment = yes/maybe
if(($f['_1YO'] == 'Y')&&($f['_2YOfeb_SS'] == 'Y')&&($f['_2YOapr_SS'] != 'Y')){
	$imgSS1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$imgSS2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$elig1=1;
	$elig2=1;
	}
if(($f['_1YO'] == 'Y')&&($f['_2YOfeb_EX'] == 'Y')&&($f['_2YOapr_EX'] != 'Y')){
	$imgEX1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$imgEX2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$elig1=1;
	$elig2=1;
	}
if(($f['_1YO'] == 'Y')&&($f['_2YOfeb_CF'] == 'Y')&&($f['_2YOapr_CF'] != 'Y')){
	$imgCF1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$imgCF2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$elig1=1;
	$elig2=1;
	}


//No Yearling payment but Sup1 made
//Applicable to: EX/CF
//No 2YO feb/apr payments = maybe/maybe
if(($f['_1YO'] != 'Y')&&($f['sup1'] == 500)&&($f['_2YOfeb_EX'] != 'Y')&&($f['_2YOapr_EX'] != 'Y')){
	$imgEX1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$imgEX2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$elig1=1;
	$elig2=1;
	}
if(($f['_1YO'] != 'Y')&&($f['sup1'] == 500)&&($f['_2YOfeb_CF'] != 'Y')&&($f['_2YOapr_CF'] != 'Y')){
	$imgCF1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$imgCF2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$elig1=1;
	$elig2=1;
	}


//2YO feb payment but no apr payment = yes/maybe
if(($f['_1YO'] != 'Y')&&($f['sup1'] == 500)&&($f['_2YOfeb_EX'] == 'Y')&&($f['_2YOapr_EX'] != 'Y')){
	$imgEX1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$imgEX2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$elig1=1;
	$elig2=1;
	}
if(($f['_1YO'] != 'Y')&&($f['sup1'] == 500)&&($f['_2YOfeb_CF'] == 'Y')&&($f['_2YOapr_CF'] != 'Y')){
	$imgCF1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$imgCF2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
	$elig1=1;
	$elig2=1;
	}

}

if($Age == '1'){
($f['_1YO'] == 'Y')&&($elig1=1)&&($imgSS1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_1YO'] == 'Y')&&($elig1=1)&&($imgEX1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_1YO'] == 'Y')&&($elig1=1)&&($imgCF1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_1YO'] == 'Y')&&($elig2=1)&&($imgSS2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_1YO'] == 'Y')&&($elig2=1)&&($imgEX2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_1YO'] == 'Y')&&($elig2=1)&&($imgCF2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");

($f['sup1'] == '500')&&($elig1=1)&&($imgSS1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['sup1'] == '500')&&($elig1=1)&&($imgEX1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['sup1'] == '500')&&($elig1=1)&&($imgCF1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['sup1'] == '500')&&($elig2=1)&&($imgSS2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['sup1'] == '500')&&($elig2=1)&&($imgEX2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['sup1'] == '500')&&($elig2=1)&&($imgCF2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");

($f['sup1'] == '50')&&($elig1=1)&&($imgSS1="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['sup1'] == '50')&&($elig1=1)&&($imgEX1="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['sup1'] == '50')&&($elig1=1)&&($imgCF1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['sup1'] == '50')&&($elig2=1)&&($imgSS2="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['sup1'] == '50')&&($elig2=1)&&($imgEX2="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['sup1'] == '50')&&($elig2=1)&&($imgCF2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
}

//new calculations
//JAN 1 through FEB 17
//1) On Jan 1 all 2yo of last year become 3yo.
//2) Look at the horse payments to see if that particular horse paid as a 1yo.  If it did place orange marks for EX and for CF.
//3) Look to see if that particular horse made the SS feb 15 payment as a 2yo.  If it did place orange marks for SS as well.  If it did NOT make the SS feb 15 payment as a 2yo SS should display 2 red marks (EX and //CF still
//orange)

if(($Age == '3')&&($isprov1)&&($f['_1YO'] == 'Y')){
	if($f['_3YOfeb_EX'] != 'Y'){
		$imgEX1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}
	if($f['_3YOfeb_CF'] != 'Y'){
		$imgCF1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}

	if($f['_3YOapr_EX'] != 'Y'){
		$imgEX2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}

	if($f['_3YOapr_CF'] != 'Y'){
		$imgCF2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}
		
	if($f['_2YOfeb_SS'] == 'Y'){
		$imgSS1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		$imgSS2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}
	else{
		$imgSS1="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";
		$imgSS2="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}

	if($f['_3YOfeb_SS'] == 'Y'){
		$imgSS1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}
	if($f['_3YOapr_SS'] == 'Y'){
		$imgSS2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}

	}


//added 1/25/2016
if(($Age == '3')&&($isprov1)){

//if($f['Horse'] == "Shelburne Prince"){
//print_r($f);
//}
	if($f['_2YOapr_CF'] == 'Y'){
		$imgCF1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		$imgCF2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}
}
		
//commented out 1/27/2016		
//if(($Age == '2')&&($isprov1)){
//	($f['sup1'] == '500')&&($elig1=1)&&($imgSS1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">");
//	($f['sup1'] == '500')&&($elig1=1)&&($imgEX1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">");
//	($f['sup1'] == '500')&&($elig1=1)&&($imgCF1="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">");
//	($f['sup1'] == '500')&&($elig2=1)&&($imgSS2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">");
//	($f['sup1'] == '500')&&($elig2=1)&&($imgEX2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">");
//	($f['sup1'] == '500')&&($elig2=1)&&($imgCF2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">");
//	}		

//on FEB 18
//1) If the horse missed the feb15 payments the orange marks will turn into red marks.
//2) If the horse made the feb 15 payments the first mark will turn into green and the second will remain orange.
//added.. if april 2yo payment made.. yes on second check.

if(($Age == '3')&&($isprov2)){

	if(($f['_3YOfeb_EX'] == 'Y')&&($f['_3YOapr_EX'] != 'Y')){
		$imgEX2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}

	if(($f['_3YOfeb_CF'] == 'Y')&&($f['_3YOapr_CF'] != 'Y')){
		$imgCF2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}


	if(($f['_3YOfeb_SS'] == 'Y')&&($f['_3YOapr_SS'] != 'Y')){
		$imgSS2="<img src=\"admin/maybe.gif\" width=\"15\" height=\"13\" border=\"0\">";
		}
	}

//on APRIL 18
//1) If the horse missed the apr15 payments the second orange mark will turn into red marks
//2) If the horse made the apr 15 payments the second orange mark will turn into green.
if($isprov3){
if(preg_match("/maybe\.gif/",$imgSS1)){$elig1=0;$imgSS1="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";}
if(preg_match("/maybe\.gif/",$imgEX1)){$elig1=0;$imgEX1="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";}
if(preg_match("/maybe\.gif/",$imgCF1)){$elig1=0;$imgCF1="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";}
if(preg_match("/maybe\.gif/",$imgSS2)){$elig2=0;$imgSS2="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";}
if(preg_match("/maybe\.gif/",$imgEX2)){$elig2=0;$imgEX2="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";}
if(preg_match("/maybe\.gif/",$imgCF2)){$elig2=0;$imgCF2="<img src=\"admin/no.gif\" width=\"15\" height=\"13\" border=\"0\">";}
}


##moved 1/26/2016 .. if they made the payment, they are eligible!
if($Age == '3'){
($f['_3YOfeb_SS'] == 'Y')&&($elig1=1)&&($imgSS1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_3YOfeb_EX'] == 'Y')&&($elig1=1)&&($imgEX1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_3YOfeb_CF'] == 'Y')&&($elig1=1)&&($imgCF1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_3YOapr_SS'] == 'Y')&&($elig2=1)&&($imgSS2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_3YOapr_EX'] == 'Y')&&($elig2=1)&&($imgEX2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['_3YOapr_CF'] == 'Y')&&($elig2=1)&&($imgCF2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
}

//elig override
($f['EligOverrideSS'])&&($elig1=1)&&($imgSS1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['EligOverrideEX'])&&($elig1=1)&&($imgEX1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['EligOverrideCF'])&&($elig1=1)&&($imgCF1="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['EligOverrideSS'])&&($elig2=1)&&($imgSS2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['EligOverrideEX'])&&($elig2=1)&&($imgEX2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");
($f['EligOverrideCF'])&&($elig2=1)&&($imgCF2="<img src=\"admin/yes.gif\" width=\"15\" height=\"13\" border=\"0\">");

//if($f['HorseID']=='9J004'){
//print "E1: $elig1 - E2: $elig2<br>M: $m - D: $d<br>";
//}

//recalc!!!
$elig1a=1;
$elig1b=1;
$elig1c=1;
$elig2a=1;
$elig2b=1;
$elig2c=1;
if(preg_match("/no\.gif/",$imgSS1)){
	$elig1a=0;
	}
if(preg_match("/no\.gif/",$imgEX1)){
	$elig1b=0;
	}
if(preg_match("/no\.gif/",$imgCF1)){
	$elig1c=0;
	}
if(($elig1a)||($elig1b)||($elig1c)){
	$elig1=1;
	}
if(preg_match("/no\.gif/",$imgSS2)){
	$elig2a=0;
	}
if(preg_match("/no\.gif/",$imgEX2)){
	$elig2b=0;
	}
if(preg_match("/no\.gif/",$imgCF2)){
	$elig2c=0;
	}
if(($elig2a)||($elig2b)||($elig2c)){
	$elig2=1;
	}

if($_REQUEST['eligdata'] != 1){
	if((!$elig1)&&(!$elig2)){
		continue;
		}


	$today = $m.$d;
	if(($today >= '0415')&&($m <= '1231')){
			if(!$elig2){
				//print "SKIP: ".$f['HorseID']."<br>";
				continue;
				}
	}
}


$scnt++;
($scnt %2==0)?($rclass='evenrow'):($rclass='oddrow');

$row .= "
<tr class=\"$rclass\">
<td>".$f['HorseID']."</td>
<td>".$f['Horse']."</td>
<td>".$f['SireName']."</td>
<td>".$f['DamName']."</td>
<td>$imgSS1 / $imgSS2</td>
<td>$imgEX1 / $imgEX2</td>
<td>$imgCF1 / $imgCF2</td>
</tr>
";

$eligdata = new eligdata();

$eligdata->id = $f['id'];

if($isprov3){

if(preg_match("/no\.gif/",$imgSS2)){
	$eligdata->ss=0;
	}
else{
	$eligdata->ss=1;
	}

if(preg_match("/no\.gif/",$imgEX2)){
	$eligdata->ex=0;
	}
else{
	$eligdata->ex=1;
	}

if(preg_match("/no\.gif/",$imgCF2)){
	$eligdata->cf=0;
	}
else{
	$eligdata->cf=1;
	}

}
else{

if(preg_match("/no\.gif/",$imgSS1)){
	$eligdata->ss=0;
	}
else{
	$eligdata->ss=1;
	}

if(preg_match("/no\.gif/",$imgEX1)){
	$eligdata->ex=0;
	}
else{
	$eligdata->ex=1;
	}

if(preg_match("/no\.gif/",$imgCF1)){
	$eligdata->cf=0;
	}
else{
	$eligdata->cf=1;
	}

}

if((preg_match("/maybe\.gif/",$imgSS1))||(preg_match("/maybe\.gif/",$imgSS2))){
	$eligdata->ss=2;
	}

if((preg_match("/maybe\.gif/",$imgEX1))||(preg_match("/maybe\.gif/",$imgEX2))){
	$eligdata->ex=2;
	}

if((preg_match("/maybe\.gif/",$imgCF1))||(preg_match("/maybe\.gif/",$imgCF2))){
	$eligdata->cf=2;
	}

array_push($alleligdata,$eligdata);

}

if($_REQUEST['eligdata']==1){
	ob_clean();
	print serialize($alleligdata);
	exit();
	}

if($Age == 1){
	$title = "ELIGIBLE YEARLING $titleGait $titleSex";
	}
else{
	$title = "ELIGIBLE $Age-YEAR-OLD $titleGait $titleSex";
	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=$title?></title>
<style>
.oddrow{
	background-color: #FFFFFF;
	//background-color: white;
	}
.evenrow{
	background-color: #EEEEEE;
	//background-color: white;
	}

.evenrow td, .oddrow td{
	text-align: center;
	font-size: 10pt;
	}

.columnlinks{
color: black;
}
</style>
<script>
function Sort(c){
var a="<? echo Utilities::scrub($_REQUEST['a'])?>";
var g="<? echo Utilities::scrub($_REQUEST['g'])?>";
var s="<? echo Utilities::scrub($_REQUEST['s'])?>";
var o="<? echo Utilities::scrub($_REQUEST['o'])?>";
var d="<? echo Utilities::scrub($_REQUEST['d'])?>";
if(!d){
	d='desc';
	}
else{
	d='';
	}

var URL = "eligibility.php?a="+a+"&g="+g+"&s="+s+"&o="+c+"&d="+d;
window.location=URL;
}

</script>
</head>
<body>

<table align="center" width="900" border="1" cellpadding="1" cellspacing="1" bordercolor="#666666">
<tr><td colspan=7 align=left style="padding: 5px"><?=$attention?>
<img src="admin/no.gif" width="15" height="13" border="0"> - indicates no payments received into NYSS program and not eligible to race in these events.<br />
<br />
<img src="admin/maybe.gif" width="15" height="13" border="0"> - indicates no payments received at this time but eligible to pay in.<br />
<br />
<img src="admin/yes.gif" width="15" height="13" border="0"> <img src="admin/yes.gif" width="15" height="13" border="0"> - (2 checks) indicate that payments have been received and the horse is eligible to race in the current year.<br />
<br />
<img src="admin/yes.gif" width="15" height="13" border="0"> - (1 check) indicates that a February payment was received and the horse is eligible to race in the following year if all payments are made at that time.
<br /><br />
If you do not understand this information please call the New York Sire Stakes at 518-694-5002 and we will get back to you quickly.
</td></tr>
<tr><td colspan=7 align=left><? include("pandemenu.php");?></td></tr>
<tr>
<td align="center" bgcolor="#666666" colspan="7"><font color="#FFFFFF" size="+1"><strong><?=$title?></strong></font></td>
</tr>
<tr bgcolor="#CCCCCC">
<td align="center"><font size="-1"><strong><a class=columnlinks href="javascript:Sort('HorseID');">TATTOO #</a></strong></font></td>
<td align="center"><font size="-1"><strong><a class=columnlinks href="javascript:Sort('Horse');">HORSE</a></strong></font></td>
<td align="center"><font size="-1"><strong><a class=columnlinks href="javascript:Sort('Sire');">SIRE</a></strong></font></td>
<td align="center"><font size="-1"><strong><a class=columnlinks href="javascript:Sort('Dam');">DAM</a></strong></font></td>
<td align="center"><font size="-1"><strong><a class=columnlinks href="javascript:Sort('SS');">NYSS</a></strong></font></td>
<td align="center"><font size="-1"><strong><a class=columnlinks href="javascript:Sort('EX');">EX/SF</a></strong></font></td>
<td align="center"><font size="-1"><strong><a class=columnlinks href="javascript:Sort('CF');">CF</a></strong></font></td>
</tr>
<?=$row?>
</table>

</body>
</html>
