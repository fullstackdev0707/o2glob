<title>Breeder Statistics</title>
<style>
.subtitler {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	font-weight: bold;
	color: B60009;
}
</style>
<?php include("pandemenu.php"); ?>
<h3>Breeder Statistics - Sire Stakes and State Fairs</h3>
<table border="1" align=center width=100% title="Breeder Statistics">
	<th class="subtitler">Breeder</th> <th class="subtitler">Earnings</th> <th class="subtitler">Starters</th> <th class="subtitler">Total Starts</th>
	<th class="subtitler">1st</th> <th class="subtitler">2nd</th> <th class="subtitler">3rd</th> <th class="subtitler">4th</th> <th class="subtitler">5th</th>


<?php
include_once("includes/setup.php");
include_once("includes/db.php");
SelectDB();

$sql_statement = "SELECT
count(distinct HorseID) as Starters,
sum(Earnings) as SumOfEarnings,
sum(Points) as SumOfPoints,
count(*) as Starts,
sum(Pos1) as Pos1,
sum(Pos2) as Pos2,
sum(Pos3) as Pos3,
sum(Pos4) as Pos4,
sum(Pos5) as Pos5,
Breeders
 FROM `BreederStatistics3`
where DivisionType like 'Sire Stakes'
group by Breeders
order by sum(Earnings) desc
";

$result = DoSQL($sql_statement);
while ($f = mysql_fetch_array($result)) {


   print "<tr>
	<Td width=25% align=\"center\">".$f['Breeders']."</Td>
	<td align=\"center\">\$".number_format($f['SumOfEarnings'],2, '.', ',')."</td>
	<td align=\"center\">".$f['Starters']." &nbsp;</td>
	<td align=\"center\">".$f['Starts']." &nbsp;</td>
	<td align=\"center\">".$f['Pos1']." &nbsp;</td>
	<td align=\"center\">".$f['Pos2']." &nbsp;</td>
	<td align=\"center\">".$f['Pos3']." &nbsp;</td>
	<td align=\"center\">".$f['Pos4']." &nbsp;</td>
	<td align=\"center\">".$f['Pos5']." &nbsp;</td>
	</tr>";


   #print '$'.$Earnings."-".$FirstName.' '.$LastName.'-'.$OwnerID.'-'.$XEarnings.'-'.$starters.'-'.$starts.'-'.$position1.'-'.$position2.'-'.$position3.'-'.$position4.'-'.$position5.'<br>';
   }



?>


	</tbody>

</table>



<h3>Breeder Statistics - Excelsior</h3>
<table border="1" align=center width=100% title="Breeder Statistics">
	<th class="subtitler">Breeder</th> <th class="subtitler">Earnings</th> <th class="subtitler">Starters</th> <th class="subtitler">Total Starts</th>
	<th class="subtitler">1st</th> <th class="subtitler">2nd</th> <th class="subtitler">3rd</th> <th class="subtitler">4th</th> <th class="subtitler">5th</th>


<?php

$sql_statement = "SELECT
count(distinct HorseID) as Starters,
sum(Earnings) as SumOfEarnings,
sum(Points) as SumOfPoints,
count(*) as Starts,
sum(Pos1) as Pos1,
sum(Pos2) as Pos2,
sum(Pos3) as Pos3,
sum(Pos4) as Pos4,
sum(Pos5) as Pos5,
Breeders
 FROM `BreederStatistics3`
where DivisionType like 'Excelsior'
group by Breeders
order by sum(Earnings) desc
";

$result = DoSQL($sql_statement);
while ($f = mysql_fetch_array($result)) {


   print "<tr>
	<Td width=25% align=\"center\">".$f['Breeders']."</Td>
	<td align=\"center\">\$".number_format($f['SumOfEarnings'],2, '.', ',')."</td>
	<td align=\"center\">".$f['Starters']." &nbsp;</td>
	<td align=\"center\">".$f['Starts']." &nbsp;</td>
	<td align=\"center\">".$f['Pos1']." &nbsp;</td>
	<td align=\"center\">".$f['Pos2']." &nbsp;</td>
	<td align=\"center\">".$f['Pos3']." &nbsp;</td>
	<td align=\"center\">".$f['Pos4']." &nbsp;</td>
	<td align=\"center\">".$f['Pos5']." &nbsp;</td>
	</tr>";


   #print '$'.$Earnings."-".$FirstName.' '.$LastName.'-'.$OwnerID.'-'.$XEarnings.'-'.$starters.'-'.$starts.'-'.$position1.'-'.$position2.'-'.$position3.'-'.$position4.'-'.$position5.'<br>';
   }



?>


	</tbody>

</table>


<h3>Breeder Statistics - County Fairs</h3>
<table border="1" align=center width=100% title="Breeder Statistics">
	<th class="subtitler">Breeder</th> <th class="subtitler">Earnings</th> <th class="subtitler">Starters</th> <th class="subtitler">Total Starts</th>
	<th class="subtitler">1st</th> <th class="subtitler">2nd</th> <th class="subtitler">3rd</th> <th class="subtitler">4th</th> <th class="subtitler">5th</th>


<?php

$sql_statement = "SELECT
count(distinct HorseID) as Starters,
sum(Earnings) as SumOfEarnings,
sum(Points) as SumOfPoints,
count(*) as Starts,
sum(Pos1) as Pos1,
sum(Pos2) as Pos2,
sum(Pos3) as Pos3,
sum(Pos4) as Pos4,
sum(Pos5) as Pos5,
Breeders
 FROM `BreederStatistics3`
where DivisionType like 'County Fair'
group by Breeders
order by sum(Earnings) desc
";

$result = DoSQL($sql_statement);
while ($f = mysql_fetch_array($result)) {


   print "<tr>
	<Td width=25% align=\"center\">".$f['Breeders']."</Td>
	<td align=\"center\">\$".number_format($f['SumOfEarnings'],2, '.', ',')."</td>
	<td align=\"center\">".$f['Starters']." &nbsp;</td>
	<td align=\"center\">".$f['Starts']." &nbsp;</td>
	<td align=\"center\">".$f['Pos1']." &nbsp;</td>
	<td align=\"center\">".$f['Pos2']." &nbsp;</td>
	<td align=\"center\">".$f['Pos3']." &nbsp;</td>
	<td align=\"center\">".$f['Pos4']." &nbsp;</td>
	<td align=\"center\">".$f['Pos5']." &nbsp;</td>
	</tr>";


   #print '$'.$Earnings."-".$FirstName.' '.$LastName.'-'.$OwnerID.'-'.$XEarnings.'-'.$starters.'-'.$starts.'-'.$position1.'-'.$position2.'-'.$position3.'-'.$position4.'-'.$position5.'<br>';
   }



?>


	</tbody>

</table>