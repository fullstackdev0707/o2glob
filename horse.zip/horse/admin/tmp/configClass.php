<?

#Created: Monday 19th of May 2014 11:58:22 AM
class config
{
	public $id;
	public $mkey;
	public $mvalue;
}


class configQueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class config_manager
{
static public function Add($config){
$sql_statement = sprintf("insert into config(mkey
,mvalue
)
values('%s'
,'%s'
)",
Utilities::mscrub($config->mkey)
,Utilities::mscrub($config->mvalue)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from config where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($config){
$sql_statement = sprintf("update config set
mkey='%s'
,mvalue='%s'
 where id='%d';
",
Utilities::mscrub($config->mkey)
,Utilities::mscrub($config->mvalue)
,Utilities::mscrub($config->id)
);
DoSQL($sql_statement);
}


static public function Getconfig($id){
$config = new config();
$sql_statement = sprintf("select * from config where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$config->id= $f["id"];
$config->mkey= $f["mkey"];
$config->mvalue= $f["mvalue"];
return $config;
}


static public function GetBy_mkey_config($mkey,$orderby = ''){
$q = new configQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from config where  mkey = '%s'  %s ",Utilities::mscrub($mkey)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$config = new config();
$config->id= $f["id"];
$config->mkey= $f["mkey"];
$config->mvalue= $f["mvalue"];
array_push($q->Records,$config);
}
return $q;
}


static public function DeleteBy_mkey_config($mkey){
$sql_statement = sprintf("delete from config where  mkey = '%s'  ",Utilities::mscrub($mkey)
);
DoSQL($sql_statement);
}


static public function SaveBy_mkey_config($mkey){
$sql_statement = sprintf("update config set
mkey='%s'
,mvalue='%s'
 where  mkey = '%s' ",
Utilities::mscrub($config->mkey)
,Utilities::mscrub($config->mvalue)
,Utilities::mscrub($mkey)
);
DoSQL($sql_statement);
}


static public function Search($order,$limit,$offset,$query)
{
($query->id)&&($q[] = sprintf("config.id='%d'",Utilities::mscrub($query->id)));
($query->mkey)&&($q[] = sprintf("config.mkey='%s'",Utilities::mscrub($query->mkey)));
($query->mvalue)&&($q[] = sprintf("config.mvalue='%s'",Utilities::mscrub($query->mvalue)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new configQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from config %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from config %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$config = new config();
$config->id= $f["id"];
$config->mkey= $f["mkey"];
$config->mvalue= $f["mvalue"];
array_push($q->Records,$config);
}


return $q;
}


static public function GetFormconfig(){
$config = new config();
$config->id= $_REQUEST["id"];
$config->mkey= $_REQUEST["mkey"];
$config->mvalue= $_REQUEST["mvalue"];
return $config;
}


}



?>