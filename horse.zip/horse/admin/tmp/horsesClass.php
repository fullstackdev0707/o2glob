<?

#Created: Monday 19th of May 2014 11:58:22 AM
class horses
{
	public $id;
	public $HorseID;
	public $Horse;
	public $Sire;
	public $Dam;
	public $ResidentialFoal;
	public $YOF;
	public $Gait;
	public $Sex;
	public $_1YO;
	public $sup1;
	public $_2YOfeb_SS;
	public $_2YOfeb_EX;
	public $_2YOfeb_CF;
	public $sup2;
	public $_2YOapr_SS;
	public $_2YOapr_EX;
	public $_2YOapr_CF;
	public $sup3;
	public $_3YOfeb_SS;
	public $_3YOfeb_EX;
	public $_3YOfeb_CF;
	public $_3YOapr_SS;
	public $_3YOapr_EX;
	public $_3YOapr_CF;
	public $FarmAddress;
	public $FarmPhone;
	public $BredFirst;
	public $BredLast;
	public $ShipSemenFirst;
	public $ShipSemenLast;
	public $ResidencyArrival;
	public $ResidencyDeparture;
	public $InspectionDate;
	public $ts;
	public $BredTo;
	public $EligOverrideSS;
	public $EligOverrideEX;
	public $EligOverrideCF;
	public $StkServ;
	public $IsEligSS;
	public $IsEligEX;
	public $IsEligCF;
}


class horsesQueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class horses_manager
{
static public function Add($horses){
$sql_statement = sprintf("insert into horses(HorseID
,Horse
,Sire
,Dam
,ResidentialFoal
,YOF
,Gait
,Sex
,_1YO
,sup1
,_2YOfeb_SS
,_2YOfeb_EX
,_2YOfeb_CF
,sup2
,_2YOapr_SS
,_2YOapr_EX
,_2YOapr_CF
,sup3
,_3YOfeb_SS
,_3YOfeb_EX
,_3YOfeb_CF
,_3YOapr_SS
,_3YOapr_EX
,_3YOapr_CF
,FarmAddress
,FarmPhone
,BredFirst
,BredLast
,ShipSemenFirst
,ShipSemenLast
,ResidencyArrival
,ResidencyDeparture
,InspectionDate
,ts
,BredTo
,EligOverrideSS
,EligOverrideEX
,EligOverrideCF
,StkServ
,IsEligSS
,IsEligEX
,IsEligCF
)
values('%s'
,'%s'
,'%d'
,'%d'
,'%s'
,'%d'
,'%s'
,'%s'
,'%s'
,'%.2f'
,'%s'
,'%s'
,'%s'
,'%.2f'
,'%s'
,'%s'
,'%s'
,'%.2f'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
)",
Utilities::mscrub($horses->HorseID)
,Utilities::mscrub($horses->Horse)
,Utilities::mscrub($horses->Sire)
,Utilities::mscrub($horses->Dam)
,Utilities::mscrub($horses->ResidentialFoal)
,Utilities::mscrub($horses->YOF)
,Utilities::mscrub($horses->Gait)
,Utilities::mscrub($horses->Sex)
,Utilities::mscrub($horses->_1YO)
,Utilities::mscrub($horses->sup1)
,Utilities::mscrub($horses->_2YOfeb_SS)
,Utilities::mscrub($horses->_2YOfeb_EX)
,Utilities::mscrub($horses->_2YOfeb_CF)
,Utilities::mscrub($horses->sup2)
,Utilities::mscrub($horses->_2YOapr_SS)
,Utilities::mscrub($horses->_2YOapr_EX)
,Utilities::mscrub($horses->_2YOapr_CF)
,Utilities::mscrub($horses->sup3)
,Utilities::mscrub($horses->_3YOfeb_SS)
,Utilities::mscrub($horses->_3YOfeb_EX)
,Utilities::mscrub($horses->_3YOfeb_CF)
,Utilities::mscrub($horses->_3YOapr_SS)
,Utilities::mscrub($horses->_3YOapr_EX)
,Utilities::mscrub($horses->_3YOapr_CF)
,Utilities::mscrub($horses->FarmAddress)
,Utilities::mscrub($horses->FarmPhone)
,Utilities::mscrub($horses->BredFirst)
,Utilities::mscrub($horses->BredLast)
,Utilities::mscrub($horses->ShipSemenFirst)
,Utilities::mscrub($horses->ShipSemenLast)
,Utilities::mscrub($horses->ResidencyArrival)
,Utilities::mscrub($horses->ResidencyDeparture)
,Utilities::mscrub($horses->InspectionDate)
,Utilities::mscrub($horses->ts)
,Utilities::mscrub($horses->BredTo)
,Utilities::mscrub($horses->EligOverrideSS)
,Utilities::mscrub($horses->EligOverrideEX)
,Utilities::mscrub($horses->EligOverrideCF)
,Utilities::mscrub($horses->StkServ)
,Utilities::mscrub($horses->IsEligSS)
,Utilities::mscrub($horses->IsEligEX)
,Utilities::mscrub($horses->IsEligCF)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from horses where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($horses){
$sql_statement = sprintf("update horses set
HorseID='%s'
,Horse='%s'
,Sire='%d'
,Dam='%d'
,ResidentialFoal='%s'
,YOF='%d'
,Gait='%s'
,Sex='%s'
,_1YO='%s'
,sup1='%.2f'
,_2YOfeb_SS='%s'
,_2YOfeb_EX='%s'
,_2YOfeb_CF='%s'
,sup2='%.2f'
,_2YOapr_SS='%s'
,_2YOapr_EX='%s'
,_2YOapr_CF='%s'
,sup3='%.2f'
,_3YOfeb_SS='%s'
,_3YOfeb_EX='%s'
,_3YOfeb_CF='%s'
,_3YOapr_SS='%s'
,_3YOapr_EX='%s'
,_3YOapr_CF='%s'
,FarmAddress='%s'
,FarmPhone='%s'
,BredFirst='%s'
,BredLast='%s'
,ShipSemenFirst='%s'
,ShipSemenLast='%s'
,ResidencyArrival='%s'
,ResidencyDeparture='%s'
,InspectionDate='%s'
,ts='%s'
,BredTo='%d'
,EligOverrideSS='%d'
,EligOverrideEX='%d'
,EligOverrideCF='%d'
,StkServ='%d'
,IsEligSS='%d'
,IsEligEX='%d'
,IsEligCF='%d'
 where id='%d';
",
Utilities::mscrub($horses->HorseID)
,Utilities::mscrub($horses->Horse)
,Utilities::mscrub($horses->Sire)
,Utilities::mscrub($horses->Dam)
,Utilities::mscrub($horses->ResidentialFoal)
,Utilities::mscrub($horses->YOF)
,Utilities::mscrub($horses->Gait)
,Utilities::mscrub($horses->Sex)
,Utilities::mscrub($horses->_1YO)
,Utilities::mscrub($horses->sup1)
,Utilities::mscrub($horses->_2YOfeb_SS)
,Utilities::mscrub($horses->_2YOfeb_EX)
,Utilities::mscrub($horses->_2YOfeb_CF)
,Utilities::mscrub($horses->sup2)
,Utilities::mscrub($horses->_2YOapr_SS)
,Utilities::mscrub($horses->_2YOapr_EX)
,Utilities::mscrub($horses->_2YOapr_CF)
,Utilities::mscrub($horses->sup3)
,Utilities::mscrub($horses->_3YOfeb_SS)
,Utilities::mscrub($horses->_3YOfeb_EX)
,Utilities::mscrub($horses->_3YOfeb_CF)
,Utilities::mscrub($horses->_3YOapr_SS)
,Utilities::mscrub($horses->_3YOapr_EX)
,Utilities::mscrub($horses->_3YOapr_CF)
,Utilities::mscrub($horses->FarmAddress)
,Utilities::mscrub($horses->FarmPhone)
,Utilities::mscrub($horses->BredFirst)
,Utilities::mscrub($horses->BredLast)
,Utilities::mscrub($horses->ShipSemenFirst)
,Utilities::mscrub($horses->ShipSemenLast)
,Utilities::mscrub($horses->ResidencyArrival)
,Utilities::mscrub($horses->ResidencyDeparture)
,Utilities::mscrub($horses->InspectionDate)
,Utilities::mscrub($horses->ts)
,Utilities::mscrub($horses->BredTo)
,Utilities::mscrub($horses->EligOverrideSS)
,Utilities::mscrub($horses->EligOverrideEX)
,Utilities::mscrub($horses->EligOverrideCF)
,Utilities::mscrub($horses->StkServ)
,Utilities::mscrub($horses->IsEligSS)
,Utilities::mscrub($horses->IsEligEX)
,Utilities::mscrub($horses->IsEligCF)
,Utilities::mscrub($horses->id)
);
DoSQL($sql_statement);
}


static public function Gethorses($id){
$horses = new horses();
$sql_statement = sprintf("select * from horses where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$horses->id= $f["id"];
$horses->HorseID= $f["HorseID"];
$horses->Horse= $f["Horse"];
$horses->Sire= $f["Sire"];
$horses->Dam= $f["Dam"];
$horses->ResidentialFoal= $f["ResidentialFoal"];
$horses->YOF= $f["YOF"];
$horses->Gait= $f["Gait"];
$horses->Sex= $f["Sex"];
$horses->_1YO= $f["_1YO"];
$horses->sup1= $f["sup1"];
$horses->_2YOfeb_SS= $f["_2YOfeb_SS"];
$horses->_2YOfeb_EX= $f["_2YOfeb_EX"];
$horses->_2YOfeb_CF= $f["_2YOfeb_CF"];
$horses->sup2= $f["sup2"];
$horses->_2YOapr_SS= $f["_2YOapr_SS"];
$horses->_2YOapr_EX= $f["_2YOapr_EX"];
$horses->_2YOapr_CF= $f["_2YOapr_CF"];
$horses->sup3= $f["sup3"];
$horses->_3YOfeb_SS= $f["_3YOfeb_SS"];
$horses->_3YOfeb_EX= $f["_3YOfeb_EX"];
$horses->_3YOfeb_CF= $f["_3YOfeb_CF"];
$horses->_3YOapr_SS= $f["_3YOapr_SS"];
$horses->_3YOapr_EX= $f["_3YOapr_EX"];
$horses->_3YOapr_CF= $f["_3YOapr_CF"];
$horses->FarmAddress= $f["FarmAddress"];
$horses->FarmPhone= $f["FarmPhone"];
$horses->BredFirst= $f["BredFirst"];
$horses->BredLast= $f["BredLast"];
$horses->ShipSemenFirst= $f["ShipSemenFirst"];
$horses->ShipSemenLast= $f["ShipSemenLast"];
$horses->ResidencyArrival= $f["ResidencyArrival"];
$horses->ResidencyDeparture= $f["ResidencyDeparture"];
$horses->InspectionDate= $f["InspectionDate"];
$horses->ts= $f["ts"];
$horses->BredTo= $f["BredTo"];
$horses->EligOverrideSS= $f["EligOverrideSS"];
$horses->EligOverrideEX= $f["EligOverrideEX"];
$horses->EligOverrideCF= $f["EligOverrideCF"];
$horses->StkServ= $f["StkServ"];
$horses->IsEligSS= $f["IsEligSS"];
$horses->IsEligEX= $f["IsEligEX"];
$horses->IsEligCF= $f["IsEligCF"];
return $horses;
}


static public function GetBy_Sire_horses($Sire,$orderby = ''){
$q = new horsesQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from horses where  Sire = '%s'  %s ",Utilities::mscrub($Sire)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horses = new horses();
$horses->id= $f["id"];
$horses->HorseID= $f["HorseID"];
$horses->Horse= $f["Horse"];
$horses->Sire= $f["Sire"];
$horses->Dam= $f["Dam"];
$horses->ResidentialFoal= $f["ResidentialFoal"];
$horses->YOF= $f["YOF"];
$horses->Gait= $f["Gait"];
$horses->Sex= $f["Sex"];
$horses->_1YO= $f["_1YO"];
$horses->sup1= $f["sup1"];
$horses->_2YOfeb_SS= $f["_2YOfeb_SS"];
$horses->_2YOfeb_EX= $f["_2YOfeb_EX"];
$horses->_2YOfeb_CF= $f["_2YOfeb_CF"];
$horses->sup2= $f["sup2"];
$horses->_2YOapr_SS= $f["_2YOapr_SS"];
$horses->_2YOapr_EX= $f["_2YOapr_EX"];
$horses->_2YOapr_CF= $f["_2YOapr_CF"];
$horses->sup3= $f["sup3"];
$horses->_3YOfeb_SS= $f["_3YOfeb_SS"];
$horses->_3YOfeb_EX= $f["_3YOfeb_EX"];
$horses->_3YOfeb_CF= $f["_3YOfeb_CF"];
$horses->_3YOapr_SS= $f["_3YOapr_SS"];
$horses->_3YOapr_EX= $f["_3YOapr_EX"];
$horses->_3YOapr_CF= $f["_3YOapr_CF"];
$horses->FarmAddress= $f["FarmAddress"];
$horses->FarmPhone= $f["FarmPhone"];
$horses->BredFirst= $f["BredFirst"];
$horses->BredLast= $f["BredLast"];
$horses->ShipSemenFirst= $f["ShipSemenFirst"];
$horses->ShipSemenLast= $f["ShipSemenLast"];
$horses->ResidencyArrival= $f["ResidencyArrival"];
$horses->ResidencyDeparture= $f["ResidencyDeparture"];
$horses->InspectionDate= $f["InspectionDate"];
$horses->ts= $f["ts"];
$horses->BredTo= $f["BredTo"];
$horses->EligOverrideSS= $f["EligOverrideSS"];
$horses->EligOverrideEX= $f["EligOverrideEX"];
$horses->EligOverrideCF= $f["EligOverrideCF"];
$horses->StkServ= $f["StkServ"];
$horses->IsEligSS= $f["IsEligSS"];
$horses->IsEligEX= $f["IsEligEX"];
$horses->IsEligCF= $f["IsEligCF"];
array_push($q->Records,$horses);
}
return $q;
}


static public function GetBy_Dam_horses($Dam,$orderby = ''){
$q = new horsesQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from horses where  Dam = '%s'  %s ",Utilities::mscrub($Dam)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horses = new horses();
$horses->id= $f["id"];
$horses->HorseID= $f["HorseID"];
$horses->Horse= $f["Horse"];
$horses->Sire= $f["Sire"];
$horses->Dam= $f["Dam"];
$horses->ResidentialFoal= $f["ResidentialFoal"];
$horses->YOF= $f["YOF"];
$horses->Gait= $f["Gait"];
$horses->Sex= $f["Sex"];
$horses->_1YO= $f["_1YO"];
$horses->sup1= $f["sup1"];
$horses->_2YOfeb_SS= $f["_2YOfeb_SS"];
$horses->_2YOfeb_EX= $f["_2YOfeb_EX"];
$horses->_2YOfeb_CF= $f["_2YOfeb_CF"];
$horses->sup2= $f["sup2"];
$horses->_2YOapr_SS= $f["_2YOapr_SS"];
$horses->_2YOapr_EX= $f["_2YOapr_EX"];
$horses->_2YOapr_CF= $f["_2YOapr_CF"];
$horses->sup3= $f["sup3"];
$horses->_3YOfeb_SS= $f["_3YOfeb_SS"];
$horses->_3YOfeb_EX= $f["_3YOfeb_EX"];
$horses->_3YOfeb_CF= $f["_3YOfeb_CF"];
$horses->_3YOapr_SS= $f["_3YOapr_SS"];
$horses->_3YOapr_EX= $f["_3YOapr_EX"];
$horses->_3YOapr_CF= $f["_3YOapr_CF"];
$horses->FarmAddress= $f["FarmAddress"];
$horses->FarmPhone= $f["FarmPhone"];
$horses->BredFirst= $f["BredFirst"];
$horses->BredLast= $f["BredLast"];
$horses->ShipSemenFirst= $f["ShipSemenFirst"];
$horses->ShipSemenLast= $f["ShipSemenLast"];
$horses->ResidencyArrival= $f["ResidencyArrival"];
$horses->ResidencyDeparture= $f["ResidencyDeparture"];
$horses->InspectionDate= $f["InspectionDate"];
$horses->ts= $f["ts"];
$horses->BredTo= $f["BredTo"];
$horses->EligOverrideSS= $f["EligOverrideSS"];
$horses->EligOverrideEX= $f["EligOverrideEX"];
$horses->EligOverrideCF= $f["EligOverrideCF"];
$horses->StkServ= $f["StkServ"];
$horses->IsEligSS= $f["IsEligSS"];
$horses->IsEligEX= $f["IsEligEX"];
$horses->IsEligCF= $f["IsEligCF"];
array_push($q->Records,$horses);
}
return $q;
}


static public function DeleteBy_Sire_horses($Sire){
$sql_statement = sprintf("delete from horses where  Sire = '%s'  ",Utilities::mscrub($Sire)
);
DoSQL($sql_statement);
}


static public function DeleteBy_Dam_horses($Dam){
$sql_statement = sprintf("delete from horses where  Dam = '%s'  ",Utilities::mscrub($Dam)
);
DoSQL($sql_statement);
}


static public function SaveBy_Sire_horses($Sire){
$sql_statement = sprintf("update horses set
HorseID='%s'
,Horse='%s'
,Sire='%d'
,Dam='%d'
,ResidentialFoal='%s'
,YOF='%d'
,Gait='%s'
,Sex='%s'
,_1YO='%s'
,sup1='%.2f'
,_2YOfeb_SS='%s'
,_2YOfeb_EX='%s'
,_2YOfeb_CF='%s'
,sup2='%.2f'
,_2YOapr_SS='%s'
,_2YOapr_EX='%s'
,_2YOapr_CF='%s'
,sup3='%.2f'
,_3YOfeb_SS='%s'
,_3YOfeb_EX='%s'
,_3YOfeb_CF='%s'
,_3YOapr_SS='%s'
,_3YOapr_EX='%s'
,_3YOapr_CF='%s'
,FarmAddress='%s'
,FarmPhone='%s'
,BredFirst='%s'
,BredLast='%s'
,ShipSemenFirst='%s'
,ShipSemenLast='%s'
,ResidencyArrival='%s'
,ResidencyDeparture='%s'
,InspectionDate='%s'
,ts='%s'
,BredTo='%d'
,EligOverrideSS='%d'
,EligOverrideEX='%d'
,EligOverrideCF='%d'
,StkServ='%d'
,IsEligSS='%d'
,IsEligEX='%d'
,IsEligCF='%d'
 where  Sire = '%s' ",
Utilities::mscrub($horses->HorseID)
,Utilities::mscrub($horses->Horse)
,Utilities::mscrub($horses->Sire)
,Utilities::mscrub($horses->Dam)
,Utilities::mscrub($horses->ResidentialFoal)
,Utilities::mscrub($horses->YOF)
,Utilities::mscrub($horses->Gait)
,Utilities::mscrub($horses->Sex)
,Utilities::mscrub($horses->_1YO)
,Utilities::mscrub($horses->sup1)
,Utilities::mscrub($horses->_2YOfeb_SS)
,Utilities::mscrub($horses->_2YOfeb_EX)
,Utilities::mscrub($horses->_2YOfeb_CF)
,Utilities::mscrub($horses->sup2)
,Utilities::mscrub($horses->_2YOapr_SS)
,Utilities::mscrub($horses->_2YOapr_EX)
,Utilities::mscrub($horses->_2YOapr_CF)
,Utilities::mscrub($horses->sup3)
,Utilities::mscrub($horses->_3YOfeb_SS)
,Utilities::mscrub($horses->_3YOfeb_EX)
,Utilities::mscrub($horses->_3YOfeb_CF)
,Utilities::mscrub($horses->_3YOapr_SS)
,Utilities::mscrub($horses->_3YOapr_EX)
,Utilities::mscrub($horses->_3YOapr_CF)
,Utilities::mscrub($horses->FarmAddress)
,Utilities::mscrub($horses->FarmPhone)
,Utilities::mscrub($horses->BredFirst)
,Utilities::mscrub($horses->BredLast)
,Utilities::mscrub($horses->ShipSemenFirst)
,Utilities::mscrub($horses->ShipSemenLast)
,Utilities::mscrub($horses->ResidencyArrival)
,Utilities::mscrub($horses->ResidencyDeparture)
,Utilities::mscrub($horses->InspectionDate)
,Utilities::mscrub($horses->ts)
,Utilities::mscrub($horses->BredTo)
,Utilities::mscrub($horses->EligOverrideSS)
,Utilities::mscrub($horses->EligOverrideEX)
,Utilities::mscrub($horses->EligOverrideCF)
,Utilities::mscrub($horses->StkServ)
,Utilities::mscrub($horses->IsEligSS)
,Utilities::mscrub($horses->IsEligEX)
,Utilities::mscrub($horses->IsEligCF)
,Utilities::mscrub($Sire)
);
DoSQL($sql_statement);
}


static public function SaveBy_Dam_horses($Dam){
$sql_statement = sprintf("update horses set
HorseID='%s'
,Horse='%s'
,Sire='%d'
,Dam='%d'
,ResidentialFoal='%s'
,YOF='%d'
,Gait='%s'
,Sex='%s'
,_1YO='%s'
,sup1='%.2f'
,_2YOfeb_SS='%s'
,_2YOfeb_EX='%s'
,_2YOfeb_CF='%s'
,sup2='%.2f'
,_2YOapr_SS='%s'
,_2YOapr_EX='%s'
,_2YOapr_CF='%s'
,sup3='%.2f'
,_3YOfeb_SS='%s'
,_3YOfeb_EX='%s'
,_3YOfeb_CF='%s'
,_3YOapr_SS='%s'
,_3YOapr_EX='%s'
,_3YOapr_CF='%s'
,FarmAddress='%s'
,FarmPhone='%s'
,BredFirst='%s'
,BredLast='%s'
,ShipSemenFirst='%s'
,ShipSemenLast='%s'
,ResidencyArrival='%s'
,ResidencyDeparture='%s'
,InspectionDate='%s'
,ts='%s'
,BredTo='%d'
,EligOverrideSS='%d'
,EligOverrideEX='%d'
,EligOverrideCF='%d'
,StkServ='%d'
,IsEligSS='%d'
,IsEligEX='%d'
,IsEligCF='%d'
 where  Dam = '%s' ",
Utilities::mscrub($horses->HorseID)
,Utilities::mscrub($horses->Horse)
,Utilities::mscrub($horses->Sire)
,Utilities::mscrub($horses->Dam)
,Utilities::mscrub($horses->ResidentialFoal)
,Utilities::mscrub($horses->YOF)
,Utilities::mscrub($horses->Gait)
,Utilities::mscrub($horses->Sex)
,Utilities::mscrub($horses->_1YO)
,Utilities::mscrub($horses->sup1)
,Utilities::mscrub($horses->_2YOfeb_SS)
,Utilities::mscrub($horses->_2YOfeb_EX)
,Utilities::mscrub($horses->_2YOfeb_CF)
,Utilities::mscrub($horses->sup2)
,Utilities::mscrub($horses->_2YOapr_SS)
,Utilities::mscrub($horses->_2YOapr_EX)
,Utilities::mscrub($horses->_2YOapr_CF)
,Utilities::mscrub($horses->sup3)
,Utilities::mscrub($horses->_3YOfeb_SS)
,Utilities::mscrub($horses->_3YOfeb_EX)
,Utilities::mscrub($horses->_3YOfeb_CF)
,Utilities::mscrub($horses->_3YOapr_SS)
,Utilities::mscrub($horses->_3YOapr_EX)
,Utilities::mscrub($horses->_3YOapr_CF)
,Utilities::mscrub($horses->FarmAddress)
,Utilities::mscrub($horses->FarmPhone)
,Utilities::mscrub($horses->BredFirst)
,Utilities::mscrub($horses->BredLast)
,Utilities::mscrub($horses->ShipSemenFirst)
,Utilities::mscrub($horses->ShipSemenLast)
,Utilities::mscrub($horses->ResidencyArrival)
,Utilities::mscrub($horses->ResidencyDeparture)
,Utilities::mscrub($horses->InspectionDate)
,Utilities::mscrub($horses->ts)
,Utilities::mscrub($horses->BredTo)
,Utilities::mscrub($horses->EligOverrideSS)
,Utilities::mscrub($horses->EligOverrideEX)
,Utilities::mscrub($horses->EligOverrideCF)
,Utilities::mscrub($horses->StkServ)
,Utilities::mscrub($horses->IsEligSS)
,Utilities::mscrub($horses->IsEligEX)
,Utilities::mscrub($horses->IsEligCF)
,Utilities::mscrub($Dam)
);
DoSQL($sql_statement);
}


static public function Search($order,$limit,$offset,$query)
{
($query->id)&&($q[] = sprintf("horses.id='%d'",Utilities::mscrub($query->id)));
($query->HorseID)&&($q[] = sprintf("horses.HorseID='%s'",Utilities::mscrub($query->HorseID)));
($query->Horse)&&($q[] = sprintf("horses.Horse='%s'",Utilities::mscrub($query->Horse)));
($query->Sire)&&($q[] = sprintf("horses.Sire='%d'",Utilities::mscrub($query->Sire)));
($query->Dam)&&($q[] = sprintf("horses.Dam='%d'",Utilities::mscrub($query->Dam)));
($query->ResidentialFoal)&&($q[] = sprintf("horses.ResidentialFoal='%s'",Utilities::mscrub($query->ResidentialFoal)));
($query->YOF)&&($q[] = sprintf("horses.YOF='%d'",Utilities::mscrub($query->YOF)));
($query->Gait)&&($q[] = sprintf("horses.Gait='%s'",Utilities::mscrub($query->Gait)));
($query->Sex)&&($q[] = sprintf("horses.Sex='%s'",Utilities::mscrub($query->Sex)));
($query->_1YO)&&($q[] = sprintf("horses._1YO='%s'",Utilities::mscrub($query->_1YO)));
($query->sup1)&&($q[] = sprintf("horses.sup1='%.2f'",Utilities::mscrub($query->sup1)));
($query->_2YOfeb_SS)&&($q[] = sprintf("horses._2YOfeb_SS='%s'",Utilities::mscrub($query->_2YOfeb_SS)));
($query->_2YOfeb_EX)&&($q[] = sprintf("horses._2YOfeb_EX='%s'",Utilities::mscrub($query->_2YOfeb_EX)));
($query->_2YOfeb_CF)&&($q[] = sprintf("horses._2YOfeb_CF='%s'",Utilities::mscrub($query->_2YOfeb_CF)));
($query->sup2)&&($q[] = sprintf("horses.sup2='%.2f'",Utilities::mscrub($query->sup2)));
($query->_2YOapr_SS)&&($q[] = sprintf("horses._2YOapr_SS='%s'",Utilities::mscrub($query->_2YOapr_SS)));
($query->_2YOapr_EX)&&($q[] = sprintf("horses._2YOapr_EX='%s'",Utilities::mscrub($query->_2YOapr_EX)));
($query->_2YOapr_CF)&&($q[] = sprintf("horses._2YOapr_CF='%s'",Utilities::mscrub($query->_2YOapr_CF)));
($query->sup3)&&($q[] = sprintf("horses.sup3='%.2f'",Utilities::mscrub($query->sup3)));
($query->_3YOfeb_SS)&&($q[] = sprintf("horses._3YOfeb_SS='%s'",Utilities::mscrub($query->_3YOfeb_SS)));
($query->_3YOfeb_EX)&&($q[] = sprintf("horses._3YOfeb_EX='%s'",Utilities::mscrub($query->_3YOfeb_EX)));
($query->_3YOfeb_CF)&&($q[] = sprintf("horses._3YOfeb_CF='%s'",Utilities::mscrub($query->_3YOfeb_CF)));
($query->_3YOapr_SS)&&($q[] = sprintf("horses._3YOapr_SS='%s'",Utilities::mscrub($query->_3YOapr_SS)));
($query->_3YOapr_EX)&&($q[] = sprintf("horses._3YOapr_EX='%s'",Utilities::mscrub($query->_3YOapr_EX)));
($query->_3YOapr_CF)&&($q[] = sprintf("horses._3YOapr_CF='%s'",Utilities::mscrub($query->_3YOapr_CF)));
($query->FarmAddress)&&($q[] = sprintf("horses.FarmAddress='%s'",Utilities::mscrub($query->FarmAddress)));
($query->FarmPhone)&&($q[] = sprintf("horses.FarmPhone='%s'",Utilities::mscrub($query->FarmPhone)));
($query->BredFirst)&&($q[] = sprintf("horses.BredFirst='%s'",Utilities::mscrub($query->BredFirst)));
($query->BredLast)&&($q[] = sprintf("horses.BredLast='%s'",Utilities::mscrub($query->BredLast)));
($query->ShipSemenFirst)&&($q[] = sprintf("horses.ShipSemenFirst='%s'",Utilities::mscrub($query->ShipSemenFirst)));
($query->ShipSemenLast)&&($q[] = sprintf("horses.ShipSemenLast='%s'",Utilities::mscrub($query->ShipSemenLast)));
($query->ResidencyArrival)&&($q[] = sprintf("horses.ResidencyArrival='%s'",Utilities::mscrub($query->ResidencyArrival)));
($query->ResidencyDeparture)&&($q[] = sprintf("horses.ResidencyDeparture='%s'",Utilities::mscrub($query->ResidencyDeparture)));
($query->InspectionDate)&&($q[] = sprintf("horses.InspectionDate='%s'",Utilities::mscrub($query->InspectionDate)));
($query->ts)&&($q[] = sprintf("horses.ts='%s'",Utilities::mscrub($query->ts)));
($query->BredTo)&&($q[] = sprintf("horses.BredTo='%d'",Utilities::mscrub($query->BredTo)));
($query->EligOverrideSS)&&($q[] = sprintf("horses.EligOverrideSS='%d'",Utilities::mscrub($query->EligOverrideSS)));
($query->EligOverrideEX)&&($q[] = sprintf("horses.EligOverrideEX='%d'",Utilities::mscrub($query->EligOverrideEX)));
($query->EligOverrideCF)&&($q[] = sprintf("horses.EligOverrideCF='%d'",Utilities::mscrub($query->EligOverrideCF)));
($query->StkServ)&&($q[] = sprintf("horses.StkServ='%d'",Utilities::mscrub($query->StkServ)));
($query->IsEligSS)&&($q[] = sprintf("horses.IsEligSS='%d'",Utilities::mscrub($query->IsEligSS)));
($query->IsEligEX)&&($q[] = sprintf("horses.IsEligEX='%d'",Utilities::mscrub($query->IsEligEX)));
($query->IsEligCF)&&($q[] = sprintf("horses.IsEligCF='%d'",Utilities::mscrub($query->IsEligCF)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new horsesQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from horses %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from horses %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horses = new horses();
$horses->id= $f["id"];
$horses->HorseID= $f["HorseID"];
$horses->Horse= $f["Horse"];
$horses->Sire= $f["Sire"];
$horses->Dam= $f["Dam"];
$horses->ResidentialFoal= $f["ResidentialFoal"];
$horses->YOF= $f["YOF"];
$horses->Gait= $f["Gait"];
$horses->Sex= $f["Sex"];
$horses->_1YO= $f["_1YO"];
$horses->sup1= $f["sup1"];
$horses->_2YOfeb_SS= $f["_2YOfeb_SS"];
$horses->_2YOfeb_EX= $f["_2YOfeb_EX"];
$horses->_2YOfeb_CF= $f["_2YOfeb_CF"];
$horses->sup2= $f["sup2"];
$horses->_2YOapr_SS= $f["_2YOapr_SS"];
$horses->_2YOapr_EX= $f["_2YOapr_EX"];
$horses->_2YOapr_CF= $f["_2YOapr_CF"];
$horses->sup3= $f["sup3"];
$horses->_3YOfeb_SS= $f["_3YOfeb_SS"];
$horses->_3YOfeb_EX= $f["_3YOfeb_EX"];
$horses->_3YOfeb_CF= $f["_3YOfeb_CF"];
$horses->_3YOapr_SS= $f["_3YOapr_SS"];
$horses->_3YOapr_EX= $f["_3YOapr_EX"];
$horses->_3YOapr_CF= $f["_3YOapr_CF"];
$horses->FarmAddress= $f["FarmAddress"];
$horses->FarmPhone= $f["FarmPhone"];
$horses->BredFirst= $f["BredFirst"];
$horses->BredLast= $f["BredLast"];
$horses->ShipSemenFirst= $f["ShipSemenFirst"];
$horses->ShipSemenLast= $f["ShipSemenLast"];
$horses->ResidencyArrival= $f["ResidencyArrival"];
$horses->ResidencyDeparture= $f["ResidencyDeparture"];
$horses->InspectionDate= $f["InspectionDate"];
$horses->ts= $f["ts"];
$horses->BredTo= $f["BredTo"];
$horses->EligOverrideSS= $f["EligOverrideSS"];
$horses->EligOverrideEX= $f["EligOverrideEX"];
$horses->EligOverrideCF= $f["EligOverrideCF"];
$horses->StkServ= $f["StkServ"];
$horses->IsEligSS= $f["IsEligSS"];
$horses->IsEligEX= $f["IsEligEX"];
$horses->IsEligCF= $f["IsEligCF"];
array_push($q->Records,$horses);
}


return $q;
}


static public function GetFormhorses(){
$horses = new horses();
$horses->id= $_REQUEST["id"];
$horses->HorseID= $_REQUEST["HorseID"];
$horses->Horse= $_REQUEST["Horse"];
$horses->Sire= $_REQUEST["Sire"];
$horses->Dam= $_REQUEST["Dam"];
$horses->ResidentialFoal= $_REQUEST["ResidentialFoal"];
$horses->YOF= $_REQUEST["YOF"];
$horses->Gait= $_REQUEST["Gait"];
$horses->Sex= $_REQUEST["Sex"];
$horses->_1YO= $_REQUEST["_1YO"];
$horses->sup1= $_REQUEST["sup1"];
$horses->_2YOfeb_SS= $_REQUEST["_2YOfeb_SS"];
$horses->_2YOfeb_EX= $_REQUEST["_2YOfeb_EX"];
$horses->_2YOfeb_CF= $_REQUEST["_2YOfeb_CF"];
$horses->sup2= $_REQUEST["sup2"];
$horses->_2YOapr_SS= $_REQUEST["_2YOapr_SS"];
$horses->_2YOapr_EX= $_REQUEST["_2YOapr_EX"];
$horses->_2YOapr_CF= $_REQUEST["_2YOapr_CF"];
$horses->sup3= $_REQUEST["sup3"];
$horses->_3YOfeb_SS= $_REQUEST["_3YOfeb_SS"];
$horses->_3YOfeb_EX= $_REQUEST["_3YOfeb_EX"];
$horses->_3YOfeb_CF= $_REQUEST["_3YOfeb_CF"];
$horses->_3YOapr_SS= $_REQUEST["_3YOapr_SS"];
$horses->_3YOapr_EX= $_REQUEST["_3YOapr_EX"];
$horses->_3YOapr_CF= $_REQUEST["_3YOapr_CF"];
$horses->FarmAddress= $_REQUEST["FarmAddress"];
$horses->FarmPhone= $_REQUEST["FarmPhone"];
$horses->BredFirst= $_REQUEST["BredFirst"];
$horses->BredLast= $_REQUEST["BredLast"];
$horses->ShipSemenFirst= $_REQUEST["ShipSemenFirst"];
$horses->ShipSemenLast= $_REQUEST["ShipSemenLast"];
$horses->ResidencyArrival= $_REQUEST["ResidencyArrival"];
$horses->ResidencyDeparture= $_REQUEST["ResidencyDeparture"];
$horses->InspectionDate= $_REQUEST["InspectionDate"];
$horses->ts= $_REQUEST["ts"];
$horses->BredTo= $_REQUEST["BredTo"];
$horses->EligOverrideSS= $_REQUEST["EligOverrideSS"];
$horses->EligOverrideEX= $_REQUEST["EligOverrideEX"];
$horses->EligOverrideCF= $_REQUEST["EligOverrideCF"];
$horses->StkServ= $_REQUEST["StkServ"];
$horses->IsEligSS= $_REQUEST["IsEligSS"];
$horses->IsEligEX= $_REQUEST["IsEligEX"];
$horses->IsEligCF= $_REQUEST["IsEligCF"];
return $horses;
}


}



?>