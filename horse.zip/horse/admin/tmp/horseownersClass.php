<?

#Created: Monday 19th of May 2014 11:58:22 AM
class horseowners
{
	public $id;
	public $hid;
	public $oid;
	public $isprimary;
}


class horseownersQueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class horseowners_manager
{
static public function Add($horseowners){
$sql_statement = sprintf("insert into horseowners(hid
,oid
,isprimary
)
values('%d'
,'%d'
,'%d'
)",
Utilities::mscrub($horseowners->hid)
,Utilities::mscrub($horseowners->oid)
,Utilities::mscrub($horseowners->isprimary)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from horseowners where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($horseowners){
$sql_statement = sprintf("update horseowners set
hid='%d'
,oid='%d'
,isprimary='%d'
 where id='%d';
",
Utilities::mscrub($horseowners->hid)
,Utilities::mscrub($horseowners->oid)
,Utilities::mscrub($horseowners->isprimary)
,Utilities::mscrub($horseowners->id)
);
DoSQL($sql_statement);
}


static public function Gethorseowners($id){
$horseowners = new horseowners();
$sql_statement = sprintf("select * from horseowners where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$horseowners->id= $f["id"];
$horseowners->hid= $f["hid"];
$horseowners->oid= $f["oid"];
$horseowners->isprimary= $f["isprimary"];
return $horseowners;
}


static public function GetBy_hid_horseowners($hid,$orderby = ''){
$q = new horseownersQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from horseowners where  hid = '%s'  %s ",Utilities::mscrub($hid)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horseowners = new horseowners();
$horseowners->id= $f["id"];
$horseowners->hid= $f["hid"];
$horseowners->oid= $f["oid"];
$horseowners->isprimary= $f["isprimary"];
array_push($q->Records,$horseowners);
}
return $q;
}


static public function GetBy_oid_horseowners($oid,$orderby = ''){
$q = new horseownersQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from horseowners where  oid = '%s'  %s ",Utilities::mscrub($oid)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horseowners = new horseowners();
$horseowners->id= $f["id"];
$horseowners->hid= $f["hid"];
$horseowners->oid= $f["oid"];
$horseowners->isprimary= $f["isprimary"];
array_push($q->Records,$horseowners);
}
return $q;
}


static public function DeleteBy_hid_horseowners($hid){
$sql_statement = sprintf("delete from horseowners where  hid = '%s'  ",Utilities::mscrub($hid)
);
DoSQL($sql_statement);
}


static public function DeleteBy_oid_horseowners($oid){
$sql_statement = sprintf("delete from horseowners where  oid = '%s'  ",Utilities::mscrub($oid)
);
DoSQL($sql_statement);
}


static public function SaveBy_hid_horseowners($hid){
$sql_statement = sprintf("update horseowners set
hid='%d'
,oid='%d'
,isprimary='%d'
 where  hid = '%s' ",
Utilities::mscrub($horseowners->hid)
,Utilities::mscrub($horseowners->oid)
,Utilities::mscrub($horseowners->isprimary)
,Utilities::mscrub($hid)
);
DoSQL($sql_statement);
}


static public function SaveBy_oid_horseowners($oid){
$sql_statement = sprintf("update horseowners set
hid='%d'
,oid='%d'
,isprimary='%d'
 where  oid = '%s' ",
Utilities::mscrub($horseowners->hid)
,Utilities::mscrub($horseowners->oid)
,Utilities::mscrub($horseowners->isprimary)
,Utilities::mscrub($oid)
);
DoSQL($sql_statement);
}


static public function Search($order,$limit,$offset,$query)
{
($query->id)&&($q[] = sprintf("horseowners.id='%d'",Utilities::mscrub($query->id)));
($query->hid)&&($q[] = sprintf("horseowners.hid='%d'",Utilities::mscrub($query->hid)));
($query->oid)&&($q[] = sprintf("horseowners.oid='%d'",Utilities::mscrub($query->oid)));
($query->isprimary)&&($q[] = sprintf("horseowners.isprimary='%d'",Utilities::mscrub($query->isprimary)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new horseownersQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from horseowners %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from horseowners %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horseowners = new horseowners();
$horseowners->id= $f["id"];
$horseowners->hid= $f["hid"];
$horseowners->oid= $f["oid"];
$horseowners->isprimary= $f["isprimary"];
array_push($q->Records,$horseowners);
}


return $q;
}


static public function GetFormhorseowners(){
$horseowners = new horseowners();
$horseowners->id= $_REQUEST["id"];
$horseowners->hid= $_REQUEST["hid"];
$horseowners->oid= $_REQUEST["oid"];
$horseowners->isprimary= $_REQUEST["isprimary"];
return $horseowners;
}


}



?>