<?

#Created: Monday 19th of May 2014 11:58:22 AM
class BreederStatistics
{
	public $HorseID;
	public $SumOfEarnings;
	public $SumOfPoints;
	public $Starts;
	public $Pos1;
	public $Pos2;
	public $Pos3;
	public $Pos4;
	public $Pos5;
	public $Breeders;
}


class BreederStatisticsQueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class BreederStatistics_manager
{
static public function Add($BreederStatistics){
$sql_statement = sprintf("insert into BreederStatistics(HorseID
,SumOfEarnings
,SumOfPoints
,Starts
,Pos1
,Pos2
,Pos3
,Pos4
,Pos5
,Breeders
)
values('%d'
,'%.2f'
,'%s'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%s'
)",
Utilities::mscrub($BreederStatistics->HorseID)
,Utilities::mscrub($BreederStatistics->SumOfEarnings)
,Utilities::mscrub($BreederStatistics->SumOfPoints)
,Utilities::mscrub($BreederStatistics->Starts)
,Utilities::mscrub($BreederStatistics->Pos1)
,Utilities::mscrub($BreederStatistics->Pos2)
,Utilities::mscrub($BreederStatistics->Pos3)
,Utilities::mscrub($BreederStatistics->Pos4)
,Utilities::mscrub($BreederStatistics->Pos5)
,Utilities::mscrub($BreederStatistics->Breeders)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from BreederStatistics where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($BreederStatistics){
$sql_statement = sprintf("update BreederStatistics set
HorseID='%d'
,SumOfEarnings='%.2f'
,SumOfPoints='%s'
,Starts='%d'
,Pos1='%d'
,Pos2='%d'
,Pos3='%d'
,Pos4='%d'
,Pos5='%d'
,Breeders='%s'
 where id='%d';
",
Utilities::mscrub($BreederStatistics->HorseID)
,Utilities::mscrub($BreederStatistics->SumOfEarnings)
,Utilities::mscrub($BreederStatistics->SumOfPoints)
,Utilities::mscrub($BreederStatistics->Starts)
,Utilities::mscrub($BreederStatistics->Pos1)
,Utilities::mscrub($BreederStatistics->Pos2)
,Utilities::mscrub($BreederStatistics->Pos3)
,Utilities::mscrub($BreederStatistics->Pos4)
,Utilities::mscrub($BreederStatistics->Pos5)
,Utilities::mscrub($BreederStatistics->Breeders)
,Utilities::mscrub($BreederStatistics->id)
);
DoSQL($sql_statement);
}


static public function GetBreederStatistics($id){
$BreederStatistics = new BreederStatistics();
$sql_statement = sprintf("select * from BreederStatistics where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$BreederStatistics->HorseID= $f["HorseID"];
$BreederStatistics->SumOfEarnings= $f["SumOfEarnings"];
$BreederStatistics->SumOfPoints= $f["SumOfPoints"];
$BreederStatistics->Starts= $f["Starts"];
$BreederStatistics->Pos1= $f["Pos1"];
$BreederStatistics->Pos2= $f["Pos2"];
$BreederStatistics->Pos3= $f["Pos3"];
$BreederStatistics->Pos4= $f["Pos4"];
$BreederStatistics->Pos5= $f["Pos5"];
$BreederStatistics->Breeders= $f["Breeders"];
return $BreederStatistics;
}


static public function Search($order,$limit,$offset,$query)
{
($query->HorseID)&&($q[] = sprintf("BreederStatistics.HorseID='%d'",Utilities::mscrub($query->HorseID)));
($query->SumOfEarnings)&&($q[] = sprintf("BreederStatistics.SumOfEarnings='%.2f'",Utilities::mscrub($query->SumOfEarnings)));
($query->SumOfPoints)&&($q[] = sprintf("BreederStatistics.SumOfPoints='%s'",Utilities::mscrub($query->SumOfPoints)));
($query->Starts)&&($q[] = sprintf("BreederStatistics.Starts='%d'",Utilities::mscrub($query->Starts)));
($query->Pos1)&&($q[] = sprintf("BreederStatistics.Pos1='%d'",Utilities::mscrub($query->Pos1)));
($query->Pos2)&&($q[] = sprintf("BreederStatistics.Pos2='%d'",Utilities::mscrub($query->Pos2)));
($query->Pos3)&&($q[] = sprintf("BreederStatistics.Pos3='%d'",Utilities::mscrub($query->Pos3)));
($query->Pos4)&&($q[] = sprintf("BreederStatistics.Pos4='%d'",Utilities::mscrub($query->Pos4)));
($query->Pos5)&&($q[] = sprintf("BreederStatistics.Pos5='%d'",Utilities::mscrub($query->Pos5)));
($query->Breeders)&&($q[] = sprintf("BreederStatistics.Breeders='%s'",Utilities::mscrub($query->Breeders)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new BreederStatisticsQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from BreederStatistics %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from BreederStatistics %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$BreederStatistics = new BreederStatistics();
$BreederStatistics->HorseID= $f["HorseID"];
$BreederStatistics->SumOfEarnings= $f["SumOfEarnings"];
$BreederStatistics->SumOfPoints= $f["SumOfPoints"];
$BreederStatistics->Starts= $f["Starts"];
$BreederStatistics->Pos1= $f["Pos1"];
$BreederStatistics->Pos2= $f["Pos2"];
$BreederStatistics->Pos3= $f["Pos3"];
$BreederStatistics->Pos4= $f["Pos4"];
$BreederStatistics->Pos5= $f["Pos5"];
$BreederStatistics->Breeders= $f["Breeders"];
array_push($q->Records,$BreederStatistics);
}


return $q;
}


static public function GetFormBreederStatistics(){
$BreederStatistics = new BreederStatistics();
$BreederStatistics->HorseID= $_REQUEST["HorseID"];
$BreederStatistics->SumOfEarnings= $_REQUEST["SumOfEarnings"];
$BreederStatistics->SumOfPoints= $_REQUEST["SumOfPoints"];
$BreederStatistics->Starts= $_REQUEST["Starts"];
$BreederStatistics->Pos1= $_REQUEST["Pos1"];
$BreederStatistics->Pos2= $_REQUEST["Pos2"];
$BreederStatistics->Pos3= $_REQUEST["Pos3"];
$BreederStatistics->Pos4= $_REQUEST["Pos4"];
$BreederStatistics->Pos5= $_REQUEST["Pos5"];
$BreederStatistics->Breeders= $_REQUEST["Breeders"];
return $BreederStatistics;
}


}



?>