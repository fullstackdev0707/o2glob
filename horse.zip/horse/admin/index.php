<?

include("../includes/setup.php");
include("../includes/db.php");
include("../includes/Utilities.php");

class eligdata{
	public $id;
	public $ss;
	public $ex;
	public $cf;
	}
	
$UserName = $_REQUEST["UserName"];
$PassWord = $_REQUEST["PassWord"];

$action = $_REQUEST["action"];
$message='';

if($action == 'logout'){
	session_start();
	$_SESSION['UserName'] = "";
	$_SESSION['PassWord'] = "";	
	session_destroy();
	}
	
if($action == 'login'){
#print "($username == $UserName)&&($password == $PassWord)<br>";
	if(($username == $UserName)&&($password == $PassWord)){
		RefreshElig();
		session_start();
		$_SESSION['UserName'] = $UserName;
		$_SESSION['PassWord'] = $PassWord;
		print "<script language=javascript>\n";
		print "window.location='admin.php?action=manage';\n";
		print "</script>\n";
		exit();
	}
	else{
		$message="<br><font class=errmsg><b>Invalid username or password</b></font>";
		}
	}

if($action == 'updateelig'){
	RefreshElig();
	print "Done";
	exit();
	}

function RefreshElig(){

$urls = array('eligibility.php?a=1&eligdata=1','eligibility.php?a=2&eligdata=1','eligibility.php?a=3&eligdata=1');
SelectDB();
foreach($urls as $url){
	$ch = curl_init('http://nysspoints.com/'.$url);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch);
	curl_close($ch);
	
	$eligdatas = unserialize($result);
	
	foreach($eligdatas as $eligdata){
		$sql_statement = sprintf("update horses set IsEligSS='%d',IsEligEX='%d',IsEligCF='%d' where id='%s'",Utilities::mscrub($eligdata->ss),Utilities::mscrub($eligdata->ex),Utilities::mscrub($eligdata->cf),Utilities::mscrub($eligdata->id));		
		//print "S: $sql_statement<br>";
		DoSQL($sql_statement);
		}
		

	}
	
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Admin Panel</title>
<style>
.errmsg{
color: red;
}
</style>
</head>

<body>

<form action="index.php" method=POST>
<input type=hidden name=action value="login">
<table align="center" bgcolor="#000000" border="0" cellpadding="1" cellspacing="0"><tr><td><table bgcolor="#ffffff" border="0" cellpadding="1" cellspacing="0"><tr><td><table border="0" cellpadding="4" cellspacing="1" width="450">
<tr>
<td colspan="2" align="center" bgcolor="000000"><font face="Arial, sans-serif" color="#FFFFFF"><strong>A D M I N &nbsp; L O G I N<?=$message?></strong></font></td>
</tr>
<tr>
<td bgcolor="#eeeeee" align="right" width="90"><font face="Arial, sans-serif" size="-1">Username</font></td>
<td><input type="text" name="UserName" size="50" maxlength="100"></td>
</tr>
<tr>
<td bgcolor="#eeeeee" align="right" width="90"><font face="Arial, sans-serif" size="-1">Password</font></td>
<td><input type="password" name="PassWord" size="50" maxlength="100"></td>
</tr>
<tr>
<td bgcolor="#666666" colspan="2" align="center"><input type="submit" value="login"></td>
</tr>
</table></td></tr></table></td></tr></table></p>
</form>

</body>
</html>
