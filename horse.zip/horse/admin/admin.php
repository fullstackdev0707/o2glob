<?
ini_set('memory_limit','256M');
include_once("../includes/setup.php");
include_once("../includes/db.php");
include_once("../includes/json.php");
SelectDB();
include_once("../includes/Utilities.php");
include_once("../includes/sec.php");
include_once("../includes/peopleClass.php");
include_once("../includes/horsesClass.php");
include_once("../includes/tracksClass.php");
include_once("../includes/racesClass.php");
include_once("../includes/raceresultsClass.php");

include_once("horses_manager_custom.php");
$numperpage=100;

class HorseOwners{
	public $hid;
	public $oid;
	public $FirstName;
	public $LastName;
	public $isprimary;
	}

class HorseBreeders{
	public $hid;
	public $bid;
	public $FirstName;
	public $LastName;
	public $isprimary;
	}

class OwnersJSON{
	public $OwnerName;
	public $Owners;
	}

class BreedersJSON{
	public $BreederName;
	public $Breeders;
	}

class BreederInfo{
	public $success;
	public $Sire;
	public $SireName;
	public $ResidentialFoal;
	public $Breeder;
	}

$action = $_REQUEST["action"];
($action=='')&&(Manage());
($action=='manage')&&(Manage());
($action=='managepeople')&&(ManagePeople());
($action=='showaddperson')&&(ShowAddPerson());
($action=='showeditperson')&&(ShowEditPerson());
($action=='deleteperson')&&(DeletePerson());
($action=='savepeople')&&(SavePeople());
//($action=='searchpeople')&&(SearchPeople());
($action=='exportpeople')&&(ExportPeople());


($action=='managehorses')&&(ManageHorses());
($action=='showaddhorse')&&(ShowAddHorse());
($action=='showedithorse')&&(ShowEditHorse());
($action=='deletehorse')&&(DeleteHorse());
($action=='savehorse')&&(SaveHorse());
($action=='searchhorse')&&(SearchHorse());
($action=='exporthorse')&&(ExportHorse());


($action=='manageraces')&&(ManageRaces());
($action=='showaddrace')&&(ShowAddRace());
($action=='showeditrace')&&(ShowEditRace());
($action=='deleterace')&&(DeleteRace());
($action=='saverace')&&(SaveRace());
($action=='searchrace')&&(SearchRace());
($action=='exportrace')&&(ExportRace());
($action=='showbreeders')&&(ShowBreeders());
($action=='showowners')&&(ShowOwners());
($action=='removeowner')&&(RemoveOwner());
($action=='addowner')&&(AddOwner());
($action=='saveowners')&&(SaveOwners());
($action=='removebreeder')&&(RemoveBreeder());
($action=='addbreeder')&&(AddBreeder());
($action=='savebreeders')&&(SaveBreeders());

($action=='getsires')&&(GetHorses('S'));
($action=='getdams')&&(GetHorses('D'));
($action=='gethorses')&&(GetHorsesForRace());
($action=='getdrivers')&&(GetPeople('D'));
($action=='gettrainers')&&(GetPeople('T'));

($action=='deleteselectedhorses')&&(DeleteSelectedHorses());
($action=='deleteselectedpeople')&&(DeleteSelectedPeople());

($action=='activateselectedpeople')&&(ActivateSelectedPeople('0'));
($action=='deactivateselectedpeople')&&(ActivateSelectedPeople('1'));


($action=='showtracks')&&(ShowTracks());
($action=='addtrack')&&(AddTrack());
($action=='deletetrack')&&(DeleteTrack());
($action=='gettracks')&&(GetTracks());

($action=='showaddhorserace')&&(ShowAddHorseRace());
($action=='saveracehorse')&&(SaveRaceHorse());
($action=='deletehorserace')&&(DeleteRaceHorse());
($action=='showedithorserace')&&(ShowEditHorseRace());

($action=='getbreedinginfo')&&(GetBreederInfo());

($action=='seteligibless')&&(SetEligible('SS'));
($action=='seteligibleex')&&(SetEligible('EX'));
($action=='seteligiblecf')&&(SetEligible('CF'));

($action=='showinvoiceconfig')&&(ShowInvoiceConfig());
($action=='saveinvoiceconfig')&&(SaveInvoiceConfig());

($action=='doinvoice')&&(DoInvoice());
($action=='dolabel')&&(DoLabel());

($action=='getbreedersac')&&(GetBreedersAC());
($action=='getownersac')&&(GetOwnersAC());


function DoLabel(){

$header = array('LastName','FirstName','Address1','Address2','City','State','ZIP','Country');

$row = str_putcsv( $header, ',','"')."\n";

$query = $_SESSION['lasthorsequery'];
	
if($_REQUEST['type'] == 'Owner'){
$sql_statement = sprintf("select distinct
owners.FirstName,owners.LastName,owners.Address1,owners.Address2,owners.City,owners.State,owners.ZIP,owners.Country,owners.Phone,owners.Email
from horses
left join horseowners on horseowners.hid=horses.id and horseowners.isprimary=1
left join people as owners on owners.id = horseowners.oid
left join horsebreeders on horsebreeders.hid=horses.id and horsebreeders.isprimary=1
left join people as breeders on breeders.id = horsebreeders.bid
left join horses as Sire on Sire.id = horses.Sire
left join horses as Dam on Dam.id = horses.Dam
where 1 %s order by owners.LastName,owners.FirstName,horses.Horse",$query,$order);
}
else{
$sql_statement = sprintf("select distinct
breeders.FirstName,breeders.LastName,breeders.Address1,breeders.Address2,breeders.City,breeders.State,breeders.ZIP,breeders.Country,breeders.Phone,breeders.Email
from horses
left join horseowners on horseowners.hid=horses.id and horseowners.isprimary=1
left join people as owners on owners.id = horseowners.oid
left join horsebreeders on horsebreeders.hid=horses.id and horsebreeders.isprimary=1
left join people as breeders on breeders.id = horsebreeders.bid
left join horses as Sire on Sire.id = horses.Sire
left join horses as Dam on Dam.id = horses.Dam
where 1 %s order by breeders.LastName,breeders.FirstName,horses.Horse",$query,$order);
}
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$i = array();
$FirstName = $f['FirstName'];
$LastName = $f['LastName'];
$Address1 = $f['Address1'];
$Address2 = $f['Address2'];
$City = $f['City'];
$State = $f['State'];
$ZIP = $f['ZIP'];
$Country = $f['Country'];

if((!$FirstName)&&(!$LastName)){
	continue;
	}

$i[] = $LastName;	
$i[] = $FirstName;
$i[] = $Address1;
$i[] = $Address2;
$i[] = $City;
$i[] = $State;
$i[] = $ZIP;
$i[] = $Country;

$row .= str_putcsv( $i, ',','"')."\n";
}



$mylen = strlen($row);
header("Content-type: application/msexcel");
header("Content-disposition: attachment; filename=\"export.csv\"");
header("Content-length: $mylen");
print $row;
exit();
}

function str_putcsv($input, $delimiter = ',', $enclosure = '"')
    {
        // Open a memory "file" for read/write...
        $fp = fopen('php://temp', 'r+');
        // ... write the $input array to the "file" using fputcsv()...
        fputcsv($fp, $input, $delimiter, $enclosure);
        // ... rewind the "file" so we can read what we just wrote...
        rewind($fp);
        // ... read the entire line into a variable...
        $data = fread($fp, 1048576);
        // ... close the "file"...
        fclose($fp);
        // ... and return the $data to the caller, with the trailing newline from fgets() removed.
        return rtrim($data, "\n");
    }
	
function DoInvoice(){
$config = array();

$sql_statement = "select * from config";
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
	$config[$f['mkey']] = $f['mvalue'];
	}
	
if($_REQUEST['invp'] == 'Apr'){
	$DueDate = $config['Date2'];
	$c1start="<font face=\"Arial,Helvetica,sans-serif\" size=\"2\" color=\"#999999\">";
	$c1end="</font>";
	}
else{
	$DueDate = $config['Date1'];
	}

$query = $_SESSION['lasthorsequery'];
	
if($_REQUEST['type'] == 'Owner'){
$sql_statement = sprintf("select horses.*,Sire.Horse as SireName,Dam.Horse as DamName,
owners.FirstName,owners.LastName,owners.Address1,owners.Address2,owners.City,owners.State,owners.ZIP,owners.Country,owners.Phone,owners.Email,
(year(now()) - horses.YOF) as HowOld
from horses
left join horseowners on horseowners.hid=horses.id and horseowners.isprimary=1
left join people as owners on owners.id = horseowners.oid
left join horsebreeders on horsebreeders.hid=horses.id and horsebreeders.isprimary=1
left join people as breeders on breeders.id = horsebreeders.bid
left join horses as Sire on Sire.id = horses.Sire
left join horses as Dam on Dam.id = horses.Dam
where 1 %s order by owners.LastName,owners.FirstName,horses.Horse",$query,$order);
}
else{
$sql_statement = sprintf("select horses.*,Sire.Horse as SireName,Dam.Horse as DamName,
breeders.FirstName,breeders.LastName,breeders.Address1,breeders.Address2,breeders.City,breeders.State,breeders.ZIP,breeders.Country,breeders.Phone,breeders.Email,
(year(now()) - horses.YOF) as HowOld
from horses
left join horseowners on horseowners.hid=horses.id and horseowners.isprimary=1
left join people as owners on owners.id = horseowners.oid
left join horsebreeders on horsebreeders.hid=horses.id and horsebreeders.isprimary=1
left join people as breeders on breeders.id = horsebreeders.bid
left join horses as Sire on Sire.id = horses.Sire
left join horses as Dam on Dam.id = horses.Dam
where 1 %s order by breeders.LastName,breeders.FirstName,horses.Horse",$query,$order);
}

$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){

$Horse = $f['Horse'];
$Tattoo = $f['HorseID'];
$YOF = $f['YOF'];
$Gait = $f['Gait'];
$Sex = $f['Sex'];
$FirstName = $f['FirstName'];
$LastName = $f['LastName'];
$Address1 = $f['Address1'];
$Address2 = $f['Address2'];
$City = $f['City'];
$State = $f['State'];
$ZIP = $f['ZIP'];
$Country = $f['Country'];

$HowOld = $f['HowOld'];
$made2yopmt = 0;
($f['_2YOfeb_SS'] == 'Y')&&($made2yopmt=1);
($f['_2YOfeb_EX'] == 'Y')&&($made2yopmt=1);
($f['_2YOfeb_CF'] == 'Y')&&($made2yopmt=1);
$made3yopmt = 0;
($f['_3YOfeb_SS'] == 'Y')&&($made3yopmt=1);
($f['_3YOfeb_EX'] == 'Y')&&($made3yopmt=1);
($f['_3YOfeb_CF'] == 'Y')&&($made3yopmt=1);

if($_REQUEST['opf'] != 'Y'){
if(($_REQUEST['invp'] == 'Apr')&&($HowOld==2)&&(!$made2yopmt)){
	continue;
	}

if(($_REQUEST['invp'] == 'Apr')&&($HowOld==3)&&(!$made3yopmt)){
	continue;
	}
}
	
if($_REQUEST['oss'] != 'Y'){	
if($f['StkServ']==1){
	continue;
	}
}

if((!$FirstName)&&(!$LastName)){
	continue;
	}
	
$Name = $FirstName . ' ' . $LastName;

if($Address2){
	$Address1 .= "<br><strong>$Address2</strong>";
	}

if($Name2){
	$Name .= "<br><strong>$Name2</strong>";
	}
	
ob_flush();
ob_start();
if($_REQUEST['type'] == 'Owner'){
	include("t_invoice_owner.html");
}
else{
	$config['Inv_Message'] = file_get_contents("inv_message.html");
	include("t_invoice_breeder.html");
	}
$invoices .= ob_get_contents();
ob_end_clean();

}



//print $invoices;

$temp = tempnam("/tmp", "pdf");

file_put_contents($temp,$invoices);

ob_end_clean();


//$_ENV["HTMLDOC_NOCGI"] = 1;
putenv("HTMLDOC_NOCGI=1");

header("Content-Type: application/pdf");

#ob_end_flush();

passthru("/usr/bin/htmldoc -t pdf --quiet --fontsize 10 --no-numbered --no-title --footer ... --header ... --webpage $temp 2>&1");

//unlink($temp);

exit();
}

function SaveInvoiceConfig(){

if($_REQUEST['t'] == 'O'){
	$configs = array('Date1','Date2','Date3','Year1','Number1','Number2','Number3');

	foreach($configs as $config){
		$sql_statement = sprintf("delete from config where mkey='%s'",Utilities::mscrub($config));
		DoSQL($sql_statement);
		$sql_statement = sprintf("insert into config(mkey,mvalue) values('%s','%s')",Utilities::mscrub($config),Utilities::mscrub($_REQUEST[$config]));
		DoSQL($sql_statement);
		}
}

if($_REQUEST['t'] == 'B'){
	file_put_contents("inv_message.html",$_REQUEST['Inv_Message']);
	}

print "
		<script language=javascript>
		var rndURL = (1000*Math.random());
		alert(\"Invoice Template Saved\");
		window.location = \"admin.php?action=managehorses&rnd=\"+rndURL;
		</script>
		";
exit();
}

function ShowInvoiceConfig(){
$config = array();

$sql_statement = "select * from config";
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
	$config[$f['mkey']] = $f['mvalue'];
	}

if($_REQUEST['t']=='O'){
	include("t_template_owner.html");
	}
if($_REQUEST['t']=='B'){
	$config['Inv_Message'] = file_get_contents("inv_message.html");
	include("t_template_breeder.html");
	}
}

function GetBreederInfo(){
$breederinfo = new BreederInfo();

$id = $_REQUEST['id'];
$dam = horses_manager::Gethorses($id);
if($dam->BredTo > 0){
	$breederinfo->success=true;
	$sire = horses_manager::Gethorses($dam->BredTo);
	$breederinfo->ResidentialFoal=$dam->ResidentialFoal;
	$breederinfo->Sire=$dam->BredTo;
	$breederinfo->SireName=$sire->Horse;
	$breederinfo->Breeder = GetOwnerName($id);
	$_SESSION['breeders'] = serialize(LoadOwners($id));
}
else{
	$breederinfo->success=false;
	}

print json_encode($breederinfo);
flush();
exit();
}


function SaveRaceHorse(){
$raceresults = raceresults_manager::GetFormraceresults();
$raceresults->ts=date('Y-m-d H:i');

$raceresults->Position = preg_replace("/[^\d\.]/","",$raceresults->Position);
$raceresults->Points = preg_replace("/[^\d\.]/","",$raceresults->Points);
$raceresults->Earnings = preg_replace("/[^\d\.]/","",$raceresults->Earnings);

(!$raceresults->HorseID)&&($errors[] = "please select a horse");
(!$raceresults->DriverID)&&($errors[] = "please select a driver");
(!$raceresults->TrainerID)&&($errors[] = "please select a trainer");

if($errors){
	$allerrors = join("<br>",$errors);
	Utilities::PError($allerrors);
	exit();
	}
else{
	if(!$raceresults->id){
		$raceresults->id = raceresults_manager::Add($raceresults);
		$message = 'Result Added';
		}
	else{
		raceresults_manager::Save($raceresults);
		$message = 'Result Saved';
		}

	print "
		<script language=javascript>
		var rndURL = (1000*Math.random());
		alert(\"$message\");
		window.location = \"admin.php?action=showeditrace&id=".$raceresults->RaceID."&rnd=\"+rndURL;
		</script>
		";
		exit();
	}
}


function ShowEditHorseRace(){

$rid = Utilities::scrub($_REQUEST['rid']);
$id = Utilities::scrub($_REQUEST['id']);
$race = races_manager::Getraces($rid);
$race->racedate = fixdate($race->racedate);

$raceResult = raceresults_manager::Getraceresults($id);
$horse = horses_manager::Gethorses($raceResult->HorseID);
$driver = people_manager::Getpeople($raceResult->DriverID);
$trainer = people_manager::Getpeople($raceResult->TrainerID);


$raceResult->Horse = $horse->Horse;
$raceResult->Driver = $driver->FirstName . ' ' . $driver->LastName;
$raceResult->Trainer = $trainer->FirstName . ' ' . $trainer->LastName;

include("t_add-races-horse.html");
}

function ShowAddHorseRace(){

$rid = Utilities::scrub($_REQUEST['id']);
$race = races_manager::Getraces($rid);
$race->racedate = fixdate($race->racedate);

$raceResult->RaceID=$rid;
include("t_add-races-horse.html");
}


function GetTracks(){

$opt_tracks="<option value=''>select track --></option>";
$type = $_REQUEST['type'];
$tracktype = 'SSEX';
if($type == 'County Fair'){
	$tracktype='CF';
	}

$tracks = tracks_manager::GetBy_racetype_tracks($tracktype,'track');
foreach($tracks->Records as $track){
$opt_tracks .= sprintf("<option value='%s'>%s</option>",$track->id,$track->track);
}



print $opt_tracks;
exit();
}

function DeleteTrack(){
tracks_manager::Delete($_REQUEST['id']);
ShowTracks();
}

function AddTrack(){
$track = tracks_manager::GetFormtracks();
tracks_manager::Add($track);
ShowTracks();
}

function ShowTracks(){

$ssex_tracks='';
$cf_tracks='';

$tracks = tracks_manager::GetBy_racetype_tracks('SSEX','track');
foreach($tracks->Records as $track){
$ssex_tracks .= sprintf("<option value='%s'>%s</option>",$track->id,$track->track);
}
(!$ssex_tracks)&&($ssex_tracks .= "<option value=''>No Tracks Entered</option>");

$tracks = tracks_manager::GetBy_racetype_tracks('CF','track');
foreach($tracks->Records as $track){
$cf_tracks .= sprintf("<option value='%s'>%s</option>",$track->id,$track->track);
}
(!$cf_tracks)&&($cf_tracks .= "<option value=''>No Tracks Entered</option>");

include("t_tracks.html");
}

function ActivateSelectedPeople($inactive){
	if(is_array($_REQUEST['cb'])){
	foreach($_REQUEST['cb'] as $id){
		$sql_statement = sprintf("update people set inactive='$inactive' where id='%s'",Utilities::mscrub($id));
		DoSQL($sql_statement);
		}
	}
ManagePeople();
}


function DeleteSelectedPeople(){
	if(is_array($_REQUEST['cb'])){
	foreach($_REQUEST['cb'] as $id){
		//print "Deleting $id<br>";
		people_manager::Delete($id);
		}
	}
ManagePeople();
}

function DeleteSelectedHorses(){
	if(is_array($_REQUEST['cb'])){
	foreach($_REQUEST['cb'] as $id){
		//print "Deleting $id<br>";
		horses_manager::Delete($id);
		}
	}
ManageHorses();
}


function SetEligible($idx){
	$allhorseids = preg_split("/,/",$_REQUEST['allhorseids']);
	
	if($allhorseids){
	foreach($allhorseids as $id){
	//$_REQUEST['cbsae'] as $id
		//print "Deleting $id<br>";
		if($_REQUEST['cbsae'.$idx]){
			(in_array($id,$_REQUEST['cbsae'.$idx]))?($showaselig=1):($showaselig=0);
			}
		else{
			$showaselig=0;
			}
		$sql_statement = sprintf("update horses set EligOverride${idx}=%d where id='%d'",$showaselig,Utilities::scrub($id));
		//print "S:$sql_statement<br>";
		DoSQL($sql_statement);
		}
	}
ManageHorses();
}


function GetPeople($type){

$person = new people();
if($type == 'D'){
	$person->Driver = '1';
	}
if($type == 'T'){
	$person->Trainer = '1';
	}

$people = people_manager::Search('LastName,FirstName','','',$person);

$data = array();
$term = Utilities::scrub($_REQUEST['term']);

foreach($people->Records as $p){
$name = trim($p->FirstName.' '.$p->LastName);

if(!startsWith(strtoupper($name), strtoupper($term))){
	continue;
	}

$data[] = array(
			'label' => $name ,
			'value' => $p->id
		);
}


print json_encode($data);
flush();
exit();
}

function GetHorsesForRace(){

$rid = Utilities::scrub($_REQUEST['rid']);
$race = races_manager::Getraces($rid);
$race->racedate = fixdate($race->racedate);

$horse = new Horses();

if($race->DivisionAge=='2YO'){
$horse->YOF = date('Y')-2;
}

if($race->DivisionAge=='3YO'){
$horse->YOF = date('Y')-3;
}

if($race->DivisionGait=='Trotting'){
	$horse->Gait='T';
	}

if($race->DivisionGait=='Pacing'){
	$horse->Gait='P';
	}

if($race->DivisionSex=='Colts'){
	$horse->Sex='C';
	}

if($race->DivisionSex=='Fillies'){
	$horse->Sex='F';
	}

$horses = horses_manager::Search('Horse','','',$horse);

$data = array();

foreach($horses->Records as $horse){

if(!startsWith(strtoupper($horse->Horse), strtoupper(Utilities::scrub($_REQUEST['term'])))){
	continue;
	}

$data[] = array(
			'label' => $horse->Horse ,
			'value' => $horse->id
		);
}

print json_encode($data);
flush();
exit();
}

function GetHorses($type){

$horse = new Horses();
if($type == 'S'){
	$horse->Sex = 'S';
	}
if($type == 'D'){
	$horse->Sex = 'B';
	}

$horses = horses_manager::Search('Horse','','',$horse);

$data = array();

foreach($horses->Records as $horse){

if(!startsWith(strtoupper($horse->Horse), strtoupper(Utilities::scrub($_REQUEST['term'])))){
	continue;
	}

$data[] = array(
			'label' => $horse->Horse ,
			'value' => $horse->id
		);
}


print json_encode($data);
flush();
exit();
}

function startsWith($haystack, $needle)
{
    return !strncmp($haystack, $needle, strlen($needle));
}

function SaveOwners(){
$primaryowner = Utilities::mscrub($_REQUEST['PrimaryOwner']);
$owners=array();
if($_SESSION['owners']){
	$owners = unserialize($_SESSION['owners']);
	}


$oj = new OwnersJSON();
foreach($owners as &$owner){
	if($owner->oid == $primaryowner){
		$oj->OwnerName = $owner->FirstName.' '.$owner->LastName;
		$owner->isprimary=1;
		}
	else{
		$owner->isprimary=0;
		}
	}

$oj->Owners = serialize($owners);
$_SESSION['owners'] = serialize($owners);

ob_flush();
header("Content-type: application/json");
print json_encode($oj);
exit();
}

function SaveBreeders(){
$primarybreeder = Utilities::mscrub($_REQUEST['PrimaryBreeder']);
$breeders=array();
if($_SESSION['breeders']){
	$breeders = unserialize($_SESSION['breeders']);
	}


$bj = new BreedersJSON();
foreach($breeders as &$breeder){
	if($breeder->bid == $primarybreeder){
		$bj->BreederName = $breeder->FirstName.' '.$breeder->LastName;
		$breeder->isprimary=1;
		}
	else{
		$breeder->isprimary=0;
		}
	}

$bj->Breeders = serialize($breeders);
$_SESSION['breeders'] = serialize($breeders);

ob_flush();
header("Content-type: application/json");
print json_encode($bj);
exit();
}

function AddOwner(){
$hid = Utilities::mscrub($_REQUEST['hid']);
$oid = Utilities::mscrub($_REQUEST['oid']);
$ip = Utilities::mscrub($_REQUEST['ip']);
$owners=array();
$owners = unserialize($_SESSION['owners']);

$haveowner=array();
foreach ($owners as $o){
	$haveowner[$o->oid]=1;
	}

$owner = people_manager::Getpeople($oid);
$horseowner = new HorseOwners();
$horseowner->hid = $hid;
$horseowner->oid = $owner->id;
$horseowner->FirstName = $owner->FirstName;
$horseowner->LastName = $owner->LastName;
$horseowner->isprimary = $ip;
if(!$haveowner[$horseowner->oid]){
	array_push($owners,$horseowner);
	}

$_SESSION['owners'] = serialize($owners);
ShowOwners();
}

function AddBreeder(){
$hid = Utilities::mscrub($_REQUEST['hid']);
$bid = Utilities::mscrub($_REQUEST['bid']);
$ip = Utilities::mscrub($_REQUEST['ip']);
$breeders=array();
$breeders = unserialize($_SESSION['breeders']);

$havebredder=array();
foreach ($breeders as $b){
	$havebredder[$b->bid]=1;
	}

$breeder = people_manager::Getpeople($bid);
$horsebreeder = new HorseOwners();
$horsebreeder->hid = $hid;
$horsebreeder->bid = $breeder->id;
$horsebreeder->FirstName = $breeder->FirstName;
$horsebreeder->LastName = $breeder->LastName;
$horsebreeder->isprimary = $ip;
if(!$havebredder[$horsebreeder->bid]){
	array_push($breeders,$horsebreeder);
	}

$_SESSION['breeders'] = serialize($breeders);
ShowBreeders();
}

function RemoveOwner(){
$oid = Utilities::mscrub($_REQUEST['oid']);

$owners=array();
$newowners=array();
if($_SESSION['owners']){
	$owners = unserialize($_SESSION['owners']);
	}

foreach($owners as $owner){
	($owner->oid != $oid)&&(array_push($newowners,$owner));
	}

$_SESSION['owners'] = serialize($newowners);
ShowOwners();
}

function RemoveBreeder(){
$bid = Utilities::mscrub($_REQUEST['bid']);

$breeders=array();
$newbreeders=array();
if($_SESSION['breeders']){
	$breeders = unserialize($_SESSION['breeders']);
	}

foreach($breeders as $breeder){
	($breeder->bid != $bid)&&(array_push($newbreeders,$breeder));
	}

$_SESSION['breeders'] = serialize($newbreeders);
ShowBreeders();
}

function SaveOwnerChanges($hid){

$sql_statement = "delete from horseowners where hid='$hid'";
DoSQL($sql_statement);

$owners=array();
if($_REQUEST['owners']){
	$owners = unserialize(stripslashes($_REQUEST['owners']));
	}
elseif($_SESSION['owners']){
	$owners = unserialize(stripslashes($_SESSION['owners']));
	}

foreach ($owners as $owner){
	$sql_statement = sprintf("insert into horseowners(hid,oid,isprimary) values('%d','%d','%d')",Utilities::mscrub($hid),Utilities::mscrub($owner->oid),Utilities::mscrub($owner->isprimary));
	DoSQL($sql_statement);
	}

}


function SaveBreederChanges($hid){

$sql_statement = "delete from horsebreeders where hid='$hid'";
DoSQL($sql_statement);

$breeders=array();
if($_REQUEST['breeders']){
	$breeders = unserialize(stripslashes($_REQUEST['breeders']));
	}
elseif($_SESSION['breeders']){
	$breeders = unserialize(stripslashes($_SESSION['breeders']));
	}

foreach ($breeders as $breeder){
	$sql_statement = sprintf("insert into horsebreeders(hid,bid,isprimary) values('%d','%d','%d')",Utilities::mscrub($hid),Utilities::mscrub($breeder->bid),Utilities::mscrub($breeder->isprimary));
	DoSQL($sql_statement);
	}

}


function LoadBreeders($hid){
$breeders = array();
$sql_statement = "select people.*,horsebreeders.isprimary,horsebreeders.hid,horsebreeders.bid from horsebreeders
inner join people on people.id=horsebreeders.bid where horsebreeders.hid='$hid' order by LastName,FirstName";
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horsebreeder = new HorseBreeders();
$horsebreeder->hid = $f['hid'];
$horsebreeder->bid = $f['bid'];
$horsebreeder->FirstName = $f['FirstName'];
$horsebreeder->LastName = $f['LastName'];
$horsebreeder->isprimary = $f['isprimary'];
array_push($breeders,$horsebreeder);
}

return $breeders;
}


function LoadOwners($hid){
$owners = array();
$sql_statement = "select people.*,horseowners.isprimary,horseowners.hid,horseowners.oid from horseowners
inner join people on people.id=horseowners.oid where horseowners.hid='$hid' order by LastName,FirstName";
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horseowner = new HorseOwners();
$horseowner->hid = $f['hid'];
$horseowner->oid = $f['oid'];
$horseowner->FirstName = $f['FirstName'];
$horseowner->LastName = $f['LastName'];
$horseowner->isprimary = $f['isprimary'];
array_push($owners,$horseowner);
}

return $owners;
}

function ShowOwners(){
$hid = Utilities::mscrub($_REQUEST['hid']);

$owners=array();
if($_SESSION['owners']){
	$owners = unserialize($_SESSION['owners']);
	}


foreach($owners as $owner){
($owner->isprimary)?($isprimary='checked'):($isprimary='');
$name = $owner->FirstName. ' ' .$owner->LastName;
$row .= "<tr>
<td bgcolor=\"#DDDDDD\" width=\"200\" align=\"right\"><input type=\"radio\" name=\"PrimaryOwner\" id=\"PrimaryOwner\" value=\"".$owner->oid."\" $isprimary ></td>
<td width=\"300\" align=\"left\">$name <input style=\"font-size: 6pt;padding:1px\"type=button value=\"X\" onclick=\"RemoveOwner('".$owner->oid."');\"><input type=hidden name=\"Owners[]\" value=\"".$owner->oid."\"></td>
</tr>";
}

//$sql_statement = "select * from people where Owner=1 order by LastName,FirstName";
//$result = DoSQL($sql_statement);
//while($f = mysql_fetch_array($result)){
//$name = $f['FirstName']. ' ' .$f['LastName'];
//$owner_sel .= sprintf("<option value=\"%d\">%s</option>\n",$f['id'],$name);
//}

(!$row)&&($newchecked = 'checked');
$row .= "<tr>
<td bgcolor=\"#DDDDDD\" width=\"200\" align=\"right\"><input type=\"radio\" name=\"PrimaryOwner\"  id=\"PrimaryOwnerNew\" value=\"New\" $newchecked></td>
<td width=\"300\" align=\"left\">
<input type=text name=\"NewOwner_Name\" id=\"NewOwner_Name\" > <input type=button value=\"Add\" onclick=\"AddOwner()\">
<input type=hidden name=\"NewOwner\" id=\"NewOwner\" >
</td>
</tr>";

if(!$row){
	$row="<tr><td colspan=2>No owners selected</td></tr>";
	//$isdisabled = 'disabled';
	}

$_SESSION['owners'] = serialize($owners);
include("t_owners.html");
}

function GetBreedersAC(){
$data=array();

$sql_statement = "select * from people where Breeder=1 order by LastName,FirstName";
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$name = $f['FirstName']. ' ' .$f['LastName'];

if(!startsWith(strtoupper($f['LastName']), strtoupper(Utilities::scrub($_REQUEST['term'])))){
	continue;
	}
	
$data[] = array(
			'label' => $name ,
			'value' => $f['id']
		);
		
}

print json_encode($data);
flush();
exit();
}

function GetOwnersAC(){
$data=array();

$sql_statement = "select * from people where Owner=1 order by LastName,FirstName";
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$name = $f['FirstName']. ' ' .$f['LastName'];


if(!startsWith(strtoupper($f['LastName']), strtoupper(Utilities::scrub($_REQUEST['term'])))){
	continue;
	}
	
$data[] = array(
			'label' => $name ,
			'value' => $f['id']
		);
		
}

print json_encode($data);
flush();
exit();
}

function ShowBreeders(){
$hid = Utilities::mscrub($_REQUEST['hid']);

$breeders=array();
if($_SESSION['breeders']){
	$breeders = unserialize($_SESSION['breeders']);
	}


foreach($breeders as $breeder){
($breeder->isprimary)?($isprimary='checked'):($isprimary='');
$name = $breeder->FirstName. ' ' .$breeder->LastName;
$row .= "<tr>
<td bgcolor=\"#DDDDDD\" width=\"200\" align=\"right\"><input type=\"radio\" name=\"PrimaryBreeder\" id=\"PrimaryBreeder\" value=\"".$breeder->bid."\" $isprimary ></td>
<td width=\"300\" align=\"left\">$name <input style=\"font-size: 6pt;padding:1px\"type=button value=\"X\" onclick=\"RemoveBreeder('".$breeder->bid."');\"><input type=hidden name=\"Breeders[]\" value=\"".$breeder->bid."\"></td>
</tr>";
}

//$sql_statement = "select * from people where Breeder=1 order by LastName,FirstName";
//$result = DoSQL($sql_statement);
//while($f = mysql_fetch_array($result)){
//$name = $f['FirstName']. ' ' .$f['LastName'];
//$breeder_sel .= sprintf("<option value=\"%d\">%s</option>\n",$f['id'],$name);
//}

(!$row)&&($newchecked = 'checked');
$row .= "<tr>
<td bgcolor=\"#DDDDDD\" width=\"200\" align=\"right\"><input type=\"radio\" name=\"PrimaryBreeder\"  id=\"PrimaryBreederNew\" value=\"New\" $newchecked></td>
<td width=\"300\" align=\"left\">
<input type=text name=\"NewBreeder_Name\" id=\"NewBreeder_Name\" > <input type=button value=\"Add\" onclick=\"AddBreeder()\">
<input type=hidden name=\"NewBreeder\" id=\"NewBreeder\" >
</td>
</tr>";

if(!$row){
	$row="<tr><td colspan=2>No breeders selected</td></tr>";
	//$isdisabled = 'disabled';
	}

$_SESSION['breeders'] = serialize($breeders);
include("t_breeders.html");
}

function ExportPeople(){

$sql_statement = $_SESSION['equery'];

$q = new peopleQueryResults();
$q->Records = array();

$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
	$people = new people();
	$people->id= $f["id"];
	$people->Breeder= $f["Breeder"];
	$people->Owner= $f["Owner"];
	$people->Trainer= $f["Trainer"];
	$people->Driver= $f["Driver"];
	$people->PersonID= $f["PersonID"];
	$people->FirstName= $f["FirstName"];
	$people->LastName= $f["LastName"];
	$people->Address1= $f["Address1"];
	$people->Address2= $f["Address2"];
	$people->City= $f["City"];
	$people->State= $f["State"];
	$people->ZIP= $f["ZIP"];
	$people->Country= $f["Country"];
	$people->Phone= $f["Phone"];
	$people->Email= $f["Email"];
	$people->PersonNotes= $f["PersonNotes"];
	$people->ts= $f["ts"];
	$people->W9Received= $f["W9Received"];
	array_push($q->Records,$people);
	}


$row = "\"ID\",\"FirstName\",\"LastName\",\"Address1\",\"Address2\",\"City\",\"State\",\"ZIP\",\"Country\",\"Phone\",\"Email\",\"Breeder\",\"Owner\",\"Trainer\",\"Driver\",\"W9Rcvd\"\n";

foreach($q->Records as $person){

	($person->Breeder)?($person->Breeder='X'):($person->Breeder='');
	($person->Owner)?($person->Owner='X'):($person->Owner='');
	($person->Trainer)?($person->Trainer='X'):($person->Trainer='');
	($person->Driver)?($person->Driver='X'):($person->Driver='');
	($person->W9Received != 'Y')&&($person->W9Received='N');
	$row .= "\"".$person->id."\",\"".$person->FirstName."\",\"".$person->LastName."\",\"".$person->Address1."\",\"".$person->Address2."\",\"".$person->City."\",\"".$person->State."\",\"".$person->ZIP."\",\"".$person->Country."\",\"".$person->Phone."\",\"".$person->Email."\",\"".$person->Breeder."\",\"".$person->Owner."\",\"".$person->Trainer."\",\"".$person->Driver."\",\"".$person->W9Received."\"\n";
	}

//print $row;

$mylen = strlen($row);
header("Content-type: application/msexcel");
header("Content-disposition: attachment; filename=\"export.csv\"");
header("Content-length: $mylen");
print $row;

exit();
}


function ExportPeopleOLD(){

$people = unserialize($_SESSION['exportresults']);

$row = "\"ID\",\"FirstName\",\"LastName\",\"Phone\",\"Email\",\"Address1\",\"Breeder\",\"Owner\",\"Trainer\",\"Driver\"\n";

foreach($people->Records as $person){

	($person->Breeder)?($person->Breeder='X'):($person->Breeder='');
	($person->Owner)?($person->Owner='X'):($person->Owner='');
	($person->Trainer)?($person->Trainer='X'):($person->Trainer='');
	($person->Driver)?($person->Driver='X'):($person->Driver='');

	$row .= "\"".$person->id."\",\"".$person->FirstName."\",\"".$person->LastName."\",\"".$person->Phone."\",\"".$person->Email."\",\"".$person->Address1."\",\"".$person->Breeder."\",\"".$person->Owner."\",\"".$person->Trainer."\",\"".$person->Driver."\"\n";
	}

//print $row;

$mylen = strlen($row);
header("Content-type: application/msexcel");
header("Content-disposition: attachment; filename=\"export.csv\"");
header("Content-length: $mylen");
print $row;

exit();
}


function ExportHorse(){

$_REQUEST = unserialize($_SESSION['filtervariables']);
$horses = horses_manager_custom::Search('Horse',$numperpage,$start,'');


$row = "\"Tattoo\",\"Horse\",\"Sire\",\"Dam\",\"YOF\",\"Sex\",\"Gait\",\"Breeder\",\"Owner\",\"SS\",\"EX\",\"CF\"\n";


foreach($horses->Records as $horse){

($horse->IsEligSS==0)&&($ss='N');
($horse->IsEligSS==1)&&($ss='Y');
($horse->IsEligSS==2)&&($ss='M');

($horse->IsEligEX==0)&&($ex='N');
($horse->IsEligEX==1)&&($ex='Y');
($horse->IsEligEX==2)&&($ex='M');

($horse->IsEligCF==0)&&($cf='N');
($horse->IsEligCF==1)&&($cf='Y');
($horse->IsEligCF==2)&&($cf='M');




	$row .= "\"".$horse->HorseID."\",\"".$horse->Horse."\",\"".$horse->SireName."\",\"".$horse->DamName."\",\"".$horse->YOF."\",\"".$horse->Sex."\",\"".$horse->Gait."\",\"".$horse->breedername."\",\"".$horse->ownername."\",\"$ss\",\"$ex\",\"$cf\"\n";
	}



$mylen = strlen($row);
header("Content-type: application/msexcel");
header("Content-disposition: attachment; filename=\"export.csv\"");
header("Content-length: $mylen");
print $row;

exit();
}

function DeleteRaceHorse(){
	$id = Utilities::scrub($_REQUEST['id']);
	$rid = Utilities::scrub($_REQUEST['rid']);
	raceresults_manager::Delete($id);

	print "
		<script language=javascript>
		var rndURL = (1000*Math.random());
		alert(\"Record Deleted.\");
		window.location = \"admin.php?action=showeditrace&id=$rid&rnd=\"+rndURL;
		</script>
		";
		exit();

}

function DeletePerson(){
	people_manager::Delete($_REQUEST['id']);

	print "
		<script language=javascript>
		var rndURL = (1000*Math.random());
		alert(\"Record Deleted.\");
		window.location = \"admin.php?action=managepeople&rnd=\"+rndURL;
		</script>
		";
		exit();
}

function DeleteHorse(){
	horses_manager::Delete($_REQUEST['id']);

	print "
		<script language=javascript>
		var rndURL = (1000*Math.random());
		alert(\"Record Deleted.\");
		window.location = \"admin.php?action=managehorses&rnd=\"+rndURL;
		</script>
		";
		exit();
}

function DeleteRace(){
	races_manager::Delete($_REQUEST['id']);

	print "
		<script language=javascript>
		var rndURL = (1000*Math.random());
		alert(\"Record Deleted.\");
		window.location = \"admin.php?action=manageraces&rnd=\"+rndURL;
		</script>
		";
		exit();
}

function SavePeople(){
$people = people_manager::GetFormpeople();

//(!$people->FirstName)&&($errors[] = "please enter a first name");
(!$people->LastName)&&($errors[] = "please enter a last name");

$people->ts=date('Y-m-d H:i');

if($errors){
	$allerrors = join("<br>",$errors);
	Utilities::PError($allerrors);
	exit();
	}
else{
	if(!$people->id){
		people_manager::Add($people);
		$message = 'Person Added';
		}
	else{
		people_manager::Save($people);
		$message = 'Person Saved';
		}

	print "
		<script language=javascript>
		var rndURL = (1000*Math.random());
		alert(\"$message\");
		window.location = \"admin.php?action=managepeople&rnd=\"+rndURL;
		</script>
		";
		exit();
	}
}

function SaveHorse(){
$horse = horses_manager::GetFormhorses();

	$horse->BredFirst=fixdatein($horse->BredFirst);
	$horse->BredLast=fixdatein($horse->BredLast);
	$horse->ShipSemenFirst=fixdatein($horse->ShipSemenFirst);
	$horse->ShipSemenLast=fixdatein($horse->ShipSemenLast);
	$horse->ResidencyArrival=fixdatein($horse->ResidencyArrival);
	$horse->ResidencyDeparture=fixdatein($horse->ResidencyDeparture);
	$horse->InspectionDate=fixdatein($horse->InspectionDate);

$horse->ts=date('Y-m-d H:i');

(!$horse->Horse)&&($errors[] = "please enter a horse name");

if(!$_REQUEST['BredToName']){
	$horse->BredTo=0;
	}

if($errors){
	$allerrors = join("<br>",$errors);
	Utilities::PError($allerrors);
	exit();
	}
else{
	if(!$horse->id){
		$hid = horses_manager::Add($horse);
		SaveOwnerChanges($hid);
		SaveBreederChanges($hid);
		$message = 'Horse Added';
		}
	else{
		horses_manager::Save($horse);
		SaveOwnerChanges($horse->id);
		SaveBreederChanges($horse->id);
		$message = 'Horse Saved';
		}

	print "
		<script language=javascript>
		var rndURL = (1000*Math.random());
		alert(\"$message\");
		window.location = \"admin.php?action=managehorses&rnd=\"+rndURL;
		</script>
		";
		exit();
	}
}

function fixdatein($date){

if($date){
	$date = date('Y-m-d',strtotime($date));
	}

return $date;
}

function SaveRace(){
$race = races_manager::GetFormraces();
$race->racedate=fixdatein($race->racedate);
$race->ts=date('Y-m-d H:i');

(!$race->RaceName)&&($errors[] = "please enter a name");
(!$race->Track)&&($errors[] = "please select a track");

if($errors){
	$allerrors = join("<br>",$errors);
	Utilities::PError($allerrors);
	exit();
	}
else{
	if(!$race->id){
		$race->id = races_manager::Add($race);
		$message = 'Race Added';
		}
	else{
		races_manager::Save($race);
		$message = 'Race Saved';
		}

	print "
		<script language=javascript>
		var rndURL = (1000*Math.random());
		alert(\"$message\");
		window.location = \"admin.php?action=showeditrace&id=".$race->id."&rnd=\"+rndURL;
		</script>
		";
		exit();
	}
}

function ShowEditPerson(){
	$id = $_REQUEST['id'];
	$person = people_manager::Getpeople($id);
	include("t_add-people.html");
	}

function ShowEditHorse(){
	$id = $_REQUEST['id'];
	$horse = horses_manager::Gethorses($id);

	$horse->BredFirst=fixdate($horse->BredFirst);
	$horse->BredLast=fixdate($horse->BredLast);
	$horse->ShipSemenFirst=fixdate($horse->ShipSemenFirst);
	$horse->ShipSemenLast=fixdate($horse->ShipSemenLast);
	$horse->ResidencyArrival=fixdate($horse->ResidencyArrival);
	$horse->ResidencyDeparture=fixdate($horse->ResidencyDeparture);
	$horse->InspectionDate=fixdate($horse->InspectionDate);

	$ownername = GetOwnerName($id);
	$breedername = GetBreederName($id);

	if($horse->Sire > 0){
		$Sire = horses_manager::Gethorses($horse->Sire);
		}

	if($horse->Dam > 0){
		$Dam = horses_manager::Gethorses($horse->Dam);
		}

	if($horse->BredTo > 0){
		$BredTo = horses_manager::Gethorses($horse->BredTo);
		}

	$_SESSION['owners'] = serialize(LoadOwners($id));
	$_SESSION['breeders'] = serialize(LoadBreeders($id));

	include("t_add-horses.html");
	}

	function GetBreederName($id){
	$sql_statement = "select people.*,horsebreeders.isprimary,horsebreeders.hid,horsebreeders.bid from horsebreeders
	inner join people on people.id=horsebreeders.bid where horsebreeders.hid='$id' and horsebreeders.isprimary=1";
	$result = DoSQL($sql_statement);
	$f = mysql_fetch_array($result);
	$breedername = $f['FirstName'].' '.$f['LastName'];
	return $breedername;
	}

	function GetOwnerName($id){
	$sql_statement = "select people.*,horseowners.isprimary,horseowners.hid,horseowners.oid from horseowners
	inner join people on people.id=horseowners.oid where horseowners.hid='$id' and horseowners.isprimary=1";
	$result = DoSQL($sql_statement);
	$f = mysql_fetch_array($result);
	$ownername = $f['FirstName'].' '.$f['LastName'];
	return $ownername;
	}

function fixdate($date){
if($date=='0000-00-00'){
	$date='';
	}
else{
	$date = date('m/d/Y',strtotime($date));
	}

return $date;
}

function ShowEditRace(){
	$id = $_REQUEST['id'];
	$race = races_manager::Getraces($id);
	$race->racedate = fixdate($race->racedate);

	$track_opts="";
	$tracktype = 'SSEX';
	if($race->DivisionType == 'County Fair'){
		$tracktype='CF';
		}

	$tracks = tracks_manager::GetBy_racetype_tracks($tracktype,'track');

	foreach($tracks->Records as $track){
		($race->Track == $track->id)?($sel='selected'):($sel='');
		$track_opts .= sprintf("<option value=\"%s\" $sel>%s</option>\n",$track->id,$track->track);
		}

	$addhorsbtn="<input type=\"button\" value=\"add horse\" onclick=\"AddRaceHorse();\">";

	$query = new raceresults();
	$query->RaceID=$id;
	$raceresults = horses_manager_custom::SearchResults('position','','',$query);
	foreach($raceresults->Records as $raceresult){
	$scnt++;
	($scnt %2==0)?($rclass='oddrow'):($rclass='evenrow');


	($raceresult->DeadHeat == 1)?($raceresult->DeadHeat='X'):($raceresult->DeadHeat='');
	($raceresult->Position == '0')&&($raceresult->Position='DNF');
	$row .= "<tr>
	<td class=\"$rclass\" align=\"center\" nowrap>".$raceresult->HorseID."</td>
<td class=\"$rclass\" align=\"center\" nowrap>".$raceresult->Horse."</td>
<td class=\"$rclass\" align=\"center\" nowrap>".$raceresult->Position."</td>
<td class=\"$rclass\" align=\"center\" nowrap>".$raceresult->Points."</td>
<td class=\"$rclass\" align=\"center\" nowrap>\$".number_format ($raceresult->Earnings,2)."</td>
<td class=\"$rclass\" align=\"center\" nowrap>".$raceresult->DeadHeat."</td>
<td class=\"$rclass\" align=\"center\" nowrap>".$raceresult->Driver."</td>
<td class=\"$rclass\" align=\"center\" nowrap>".$raceresult->Trainer."</td>
<td class=\"$rclass\" align=\"center\" nowrap>".$raceresult->Owner."</td>
	<td class=\"$rclass\" align=\"center\" nowrap>
	<a class=\"managelink\" href=\"javascript:ShowEdit('".$raceresult->id."');\">edit</a> | <a class=\"managelink\" href=\"javascript:Delete('".$raceresult->id."');\">delete</a></td>
	</tr>";
	}

	if(!$row){
		$row="<tr><td colspan=10>no horses entered.</td></tr>";
		}

	if($_REQUEST['r']==1){
		print $row;
		}
	else{
		include("t_add-races.html");
		}


	}


function ShowAddPerson(){
	include("t_add-people.html");
	}

function ShowAddHorse(){
	unset($_SESSION['owners']);
	unset($_SESSION['breeders']);

	$horse->_1YO='N';
	$horse->_2YOfeb_SS='N';
	$horse->_2YOfeb_EX='N';
	$horse->_2YOfeb_CF='N';
	$horse->_2YOapr_SS='N';
	$horse->_2YOapr_EX='N';
	$horse->_2YOapr_CF='N';
	$horse->_3YOfeb_SS='N';
	$horse->_3YOfeb_EX='N';
	$horse->_3YOfeb_CF='N';
	$horse->_3YOapr_SS='N';
	$horse->_3YOapr_EX='N';
	$horse->_3YOapr_CF='N';


	include("t_add-horses.html");
	}

function ShowAddRace(){
	include("t_add-races.html");
	}


function ManageRaces(){
	global $numperpage;
	$page = $_REQUEST['page'];
	(!$page)&&($page = 1);
	$start = ($page*$numperpage)-$numperpage;
	$end = $start + $numperpage;
	$count=0;

if(!$_REQUEST['raceyear']){
	$raceyear = date('Y');
	}
else{
	$raceyear = Utilities::mscrub($_REQUEST['raceyear']);
	}

$races = horses_manager_custom::SearchRaces('racedate desc',$numperpage,$start,'',$raceyear);


	foreach($races->Records as $race){
	$scnt++;
	($scnt %2==0)?($rclass='oddrow'):($rclass='evenrow');

	$row .= "<tr>
	<td class=\"$rclass\" align=\"left\">".$race->id."</td>
	<td class=\"$rclass\" align=\"left\">".fixdate($race->racedate)."</td>
	<td class=\"$rclass\" align=\"left\">".$race->RaceName."</td>
	<td class=\"$rclass\" align=\"left\">".$race->track."</td>
	<td class=\"$rclass\" align=\"center\" nowrap><a class=\"managelink\" href=\"javascript:ShowEdit('".$race->id."');\">edit</a> | <a class=\"managelink\" href=\"javascript:Delete('".$race->id."');\">delete</a></td>
	</tr>";
	}

	if(!$row){
		$row="<tr><td colspan=5>no records found.</td></tr>";
		}
	else{

		$pageline = 'Page: '.horses_manager_custom::GetNlinksMan($races->TotalRecs,$numperpage);
		$row = "<tr><td colspan=5 align=center><div id=pagination>$pageline</div></td></tr>$row<tr><td colspan=5 align=center><div id=pagination>$pageline</div></td></tr>";
		}


$sql_statement = "SELECT distinct year(racedate) as ry from `races` WHERE year(racedate) < year(now()) order by year(racedate) desc";
$result = DoSQL($sql_statement);
$raceoptions = "<option value=\"".date('Y')."\">".date('Y')."</option>";
while($f = mysql_fetch_array($result)){
	$raceoptions .= "<option value=\"".$f['ry']."\">".$f['ry']."</option>\n";
	}



$_SESSION['exportresults'] = serialize($races);
	if($_REQUEST['r']==1){
		print $row;
		}
	else{
		include("t_all-races.html");
		}
}

function ManagePeople(){
	global $numperpage;

	if($_REQUEST['inactive']==1){
		$_SESSION['inactive']=1;
		}

	if($_REQUEST['inactive']==2){
		$_SESSION['inactive']=2;
		}

	$page = $_REQUEST['page'];
	(!$page)&&($page = 1);
	$start = ($page*$numperpage)-$numperpage;
	$end = $start + $numperpage;
	$count=0;

	$people = horses_manager_custom::SearchPeople('LastName,FirstName',$numperpage,$start,'');


	foreach($people->Records as $person){
	$scnt++;
	($scnt %2==0)?($rclass='oddrow'):($rclass='evenrow');
	($person->Breeder)?($person->Breeder='X'):($person->Breeder='');
	($person->Owner)?($person->Owner='X'):($person->Owner='');
	($person->Trainer)?($person->Trainer='X'):($person->Trainer='');
	($person->Driver)?($person->Driver='X'):($person->Driver='');

	$row .= "<tr>
	<td class=\"$rclass\" align=\"left\"><input class=\"sacb\" name=\"cb[]\" type=checkbox value=\"".$person->id."\"></td>
	<td class=\"$rclass\" align=\"left\">".$person->id."</td>
	<td class=\"$rclass\" align=\"left\">".$person->FirstName."</td>
	<td class=\"$rclass\" align=\"left\">".$person->LastName."</td>
	<td class=\"$rclass\" align=\"left\">".$person->Phone."</td>
	<td class=\"$rclass\" align=\"left\">".$person->Email."</td>
	<td class=\"$rclass\" align=\"left\">".$person->Address1."</td>
	<td class=\"$rclass\" align=\"left\">".$person->Breeder."</td>
	<td class=\"$rclass\" align=\"left\">".$person->Owner."</td>
	<td class=\"$rclass\" align=\"left\">".$person->Trainer."</td>
	<td class=\"$rclass\" align=\"left\">".$person->Driver."</td>
	<td class=\"$rclass\" align=\"center\" nowrap><a class=\"managelink\" href=\"javascript:ShowEdit('".$person->id."');\">edit</a> | <a class=\"managelink\" href=\"javascript:Delete('".$person->id."');\">delete</a></td>
	</tr>";
	}



	if(!$row){
		$row="<tr><td colspan=12>no records found.</td></tr>";
		}
	else{

		$pageline = 'Page: '.horses_manager_custom::GetNlinksMan($people->TotalRecs,$numperpage);
		$row = "<tr><td colspan=12 align=center><div id=pagination>$pageline</div></td></tr>$row<tr><td colspan=12 align=center><div id=pagination>$pageline</div></td></tr>";
		}

	if($_SESSION['inactive']==1){
		$onbutton="<input type=\"button\" value=\"active people\"  onClick=\"ShowActive('2');\"> <input type=\"button\" value=\"activate selected\"  onClick=\"ActivateSelected();\">";
		}
	else{
		$onbutton="<input type=\"button\" value=\"inactive people\"  onClick=\"ShowActive('1');\"> <input type=\"button\" value=\"deactivate selected\"  onClick=\"DeactivateSelected();\">";
		}

	$_SESSION['exportresults'] = serialize($people);
	if($_REQUEST['r']==1){
		print $row;
		}
	else{

		include("t_all-people.html");
		}
	}



function ManageHorses(){

	global $numperpage;

	if($_REQUEST['oh']==1){
		$_SESSION['oh']=1;
		}

	if($_REQUEST['oh']==2){
		$_SESSION['oh']=2;
		}

	$page = $_REQUEST['page'];
	(!$page)&&($page = 1);
	$start = ($page*$numperpage)-$numperpage;
	$end = $start + $numperpage;
	$count=0;

	$horses = horses_manager_custom::Search('Horse',$numperpage,$start,'');

	$allhids = array();
	
	foreach($horses->Records as $horse){
	$scnt++;
	($scnt %2==0)?($rclass='evenrow'):($rclass='oddrow');
	
	($horse->EligOverrideSS)?($eligibleSS='checked'):($eligibleSS='');
	($horse->EligOverrideEX)?($eligibleEX='checked'):($eligibleEX='');
	($horse->EligOverrideCF)?($eligibleCF='checked'):($eligibleCF='');
	
	array_push($allhids,$horse->id);
	
	$row .= "<tr>
	<td class=\"$rclass\" align=\"left\"><input class=\"sacb\" name=\"cb[]\" type=checkbox value=\"".$horse->id."\"></td>
	<td class=\"$rclass\" align=\"left\" nowrap>
	<!--
	<input class=\"saeSS\" name=\"cbsaeSS[]\" type=checkbox value=\"".$horse->id."\" $eligibleSS onClick=\"SetShowAsEligSS();\">
	<input class=\"saeEX\" name=\"cbsaeEX[]\" type=checkbox value=\"".$horse->id."\" $eligibleEX onClick=\"SetShowAsEligEX();\">
	<input class=\"saeCF\" name=\"cbsaeCF[]\" type=checkbox value=\"".$horse->id."\" $eligibleCF onClick=\"SetShowAsEligCF();\">
	-->
	</td>
	<td class=\"$rclass\" align=\"left\">".$horse->HorseID."</td>
	<td class=\"$rclass\" align=\"left\">".$horse->Horse."</td>
	<td class=\"$rclass\" align=\"left\">".$horse->SireName."</td>
	<td class=\"$rclass\" align=\"left\">".$horse->DamName."</td>
	<td class=\"$rclass\" align=\"left\">".$horse->YOF."</td>
	<td class=\"$rclass\" align=\"left\">".$horse->Sex."</td>
	<td class=\"$rclass\" align=\"left\">".$horse->Gait."</td>
	<td class=\"$rclass\" align=\"left\">".$horse->breedername."</td>
	<td class=\"$rclass\" align=\"left\">".$horse->ownername."</td>
	<td class=\"$rclass\" align=\"center\" nowrap><a class=\"managelink\" href=\"javascript:ShowEdit('".$horse->id."');\">edit</a> | <a class=\"managelink\" href=\"javascript:Delete('".$horse->id."');\">delete</a></td>
	</tr>";
	}


	if($_SESSION['oh']==1){
		$onbutton="<input type=\"button\" value=\"newer horses\"  onClick=\"ShowOlder('2');\">";
		}
	else{
		$onbutton="<input type=\"button\" value=\"older horses\"  onClick=\"ShowOlder('1');\">";
		}

	if(!$row){
		$row="<tr><td colspan=12>no records found.</td></tr>";
		}
	else{
		$pageline = 'Page: '.horses_manager_custom::GetNlinksMan($horses->TotalRecs,$numperpage);
		$row ="<tr><td colspan=12 align=center>
		<input type=hidden name=allhorseids value='".join(',',$allhids)."'>
		<div id=pagination>$pageline</div></td></tr>\n$row\n<tr><td colspan=12 align=center><div id=pagination>$pageline</div></td></tr>";
		}

	$_SESSION['exportresults'] = serialize($horses);
	$_SESSION['filtervariables'] = serialize($_REQUEST);
	if($_REQUEST['r']==1){
		print $row;
		}
	else{
		include("t_all-horses.html");
		}
	}

function Manage(){
	include("t_main.html");
	}

?>
