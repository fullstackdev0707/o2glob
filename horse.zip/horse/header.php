<html>
<head>
<title><?php echo $title?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<body bgcolor="#eeeeee" topmargin="10" bottommargin="10" leftmargin="0" rightmargin="0" marginheight="10" marginwidth="0" onLoad="check();">

<table bgcolor="#ffffff" align="center" width="780" border="0" cellpadding="10" cellspacing="0"><tr><td>
<p><a href="/points"><img src="logo.gif" alt="" width="780" height="120" border="0"></a></p>