<?
class horses_manager_custom
{

static public function GetNlinksMan($count,$numberPer){
	global $cgiurl;
	$action = $_REQUEST["action"];
	$query = urlencode($_REQUEST["query"]);
	$page='';$lpage='';$link='';
	$page = intval($_REQUEST["page"]);
	$lpage = intval($_REQUEST["lpage"]);
	(!$page)&&($page=1);
	((!$page)||($lpage < 0))&&($lpage = 1);

	$npages = intval($count/$numberPer);
	
	(!$lpage)&&($lpage=1);
	$nstart = ($lpage+10)-10;
	$nend = $nstart + 10;

	(($count/$numberPer) > $npages)&&($npages++);

	//print "P: $npages ($lpage) - ".$nstart." - ".$nend." <br>";
	
	for($i = 1; $i <= $npages; $i++){
		if(($i >= $nstart) && ($i < $nend)){
    			($i == $page)?($link .= " <b>$i</b> "):($link .= " <a href=\"javascript:DoFilter('$i','$lpage');\" onmouseover=\"window.status='Next Page';return true;\" onmouseout=\"window.status='';return true;\">$i</a> ");
    			}
  	}
	$pend = $nend - 20;
	$search = preg_replace("/\s/","%20",$search);

	($npages > $nend)&&($link .= " <a href=\"javascript:DoFilter('$nend','$nend');\" onmouseover=\"window.status='Next Page';return true;\" onmouseout=\"window.status='';return true;\">[ Next 10 ]</a> ");
	($nend > 11)&&($link = " <a class=\"\" href=\"javascript:DoFilter('$pend','$pend');\" onmouseover=\"window.status='Next Page';return true;\" onmouseout=\"window.status='';return true;\">[ Previous 10 ]</a> " . $link);
	(!$link)&&($link='0');
	return ($link);
}

static public function SearchResults($order,$limit,$offset,$query)
{

$norder = Utilities::scrub($_REQUEST['norder']);
$desc = Utilities::scrub($_REQUEST['desc']);
if($norder){
if($norder == 'HorseID'){
	$order = 'horses.HorseID';
	}

if($norder == 'Horse'){
	$order = 'horses.Horse';
	}

if($norder == 'Position'){
	$order = 'raceresults.Position';
	}

if($norder == 'Points'){
	$order = 'raceresults.Points';
	}

if($norder == 'Earnings'){
	$order = 'raceresults.Earnings';
	}

if($norder == 'DeadHeat'){
	$order = "raceresults.DeadHeat='1'";
	}

$xd='';
if($desc == 1){
	$xd='desc';
	}

if($norder == 'Owner'){
	//$order = "concat(Owner.FirstName, ' ',Owner.LastName)";
	$order = "Owner.LastName $xd,Owner.FirstName";
	}

if($norder == 'Trainer'){
	//$order = "concat(Trainer.FirstName, ' ',Trainer.LastName)";
	$order = "Trainer.LastName $xd,Trainer.FirstName";
	}

if($norder == 'Driver'){
	//$order = "concat(Driver.FirstName, ' ',Driver.LastName)";
	$order = "Driver.LastName $xd,Driver.FirstName";
	}

if($desc == 1){
	$order .= ' desc ';
	}

}

($query->id)&&($q[] = sprintf("raceresults.id='%d'",Utilities::mscrub($query->id)));
($query->RaceID)&&($q[] = sprintf("raceresults.RaceID='%d'",Utilities::mscrub($query->RaceID)));
($query->HorseID)&&($q[] = sprintf("raceresults.HorseID='%d'",Utilities::mscrub($query->HorseID)));
($query->Position)&&($q[] = sprintf("raceresults.Position='%d'",Utilities::mscrub($query->Position)));
($query->Points)&&($q[] = sprintf("raceresults.Points='%d'",Utilities::mscrub($query->Points)));
($query->Earnings)&&($q[] = sprintf("raceresults.Earnings='%.2f'",Utilities::mscrub($query->Earnings)));
($query->DeadHeat)&&($q[] = sprintf("raceresults.DeadHeat='%d'",Utilities::mscrub($query->DeadHeat)));
($query->DriverID)&&($q[] = sprintf("raceresults.DriverID='%d'",Utilities::mscrub($query->DriverID)));
($query->TrainerID)&&($q[] = sprintf("raceresults.TrainerID='%d'",Utilities::mscrub($query->TrainerID)));
($query->Notes)&&($q[] = sprintf("raceresults.Notes='%s'",Utilities::mscrub($query->Notes)));
($query->ts)&&($q[] = sprintf("raceresults.ts='%s'",Utilities::mscrub($query->ts)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new raceresultsQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from raceresults %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select raceresults.*,horses.Horse,horses.HorseID,
concat(Driver.FirstName, ' ',Driver.LastName) as Driver,
concat(Trainer.FirstName, ' ',Trainer.LastName) as Trainer,
concat(Owner.FirstName, ' ',Owner.LastName) as Owner
from raceresults
inner join horses on horses.id = raceresults.HorseID
left join people as Driver on Driver.id = raceresults.DriverID
left join people as Trainer on Trainer.id = raceresults.TrainerID
left join horseowners on horseowners.hid = horses.id and isprimary=1
left join people as Owner on Owner.id = horseowners.oid
 %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$raceresults = new raceresults();
$raceresults->id= $f["id"];
$raceresults->RaceID= $f["RaceID"];
$raceresults->HorseID= $f["HorseID"];
$raceresults->Horse= $f["Horse"];
$raceresults->Position= $f["Position"];
$raceresults->Points= $f["Points"];
$raceresults->Earnings= $f["Earnings"];
$raceresults->DeadHeat= $f["DeadHeat"];
$raceresults->DriverID= $f["DriverID"];
$raceresults->Driver= $f["Driver"];
$raceresults->TrainerID= $f["TrainerID"];
$raceresults->Trainer= $f["Trainer"];
$raceresults->Notes= $f["Notes"];
$raceresults->ts= $f["ts"];
$raceresults->Owner= $f["Owner"];
array_push($q->Records,$raceresults);
}


return $q;
}

static public function SearchRaces($order,$limit,$offset,$query,$raceyear='')
{

($query->id)&&($q[] = sprintf("races.id='%d'",Utilities::mscrub($query->id)));
($query->RaceName)&&($q[] = sprintf("races.RaceName='%s'",Utilities::mscrub($query->RaceName)));
($query->Track)&&($q[] = sprintf("races.Track='%d'",Utilities::mscrub($query->Track)));
($query->racedate)&&($q[] = sprintf("races.racedate='%s'",Utilities::mscrub($query->racedate)));
($query->ts)&&($q[] = sprintf("races.ts='%s'",Utilities::mscrub($query->ts)));
($query->DivisionAge)&&($q[] = sprintf("races.DivisionAge='%s'",Utilities::mscrub($query->DivisionAge)));
($query->DivisionGait)&&($q[] = sprintf("races.DivisionGait='%s'",Utilities::mscrub($query->DivisionGait)));
($query->DivisionSex)&&($q[] = sprintf("races.DivisionSex='%s'",Utilities::mscrub($query->DivisionSex)));
($query->DivisionType)&&($q[] = sprintf("races.DivisionType='%s'",Utilities::mscrub($query->DivisionType)));

$q2=array();
$q3=array();
$q4=array();
$q5=array();
$types = $_REQUEST['Type'];
if(is_array($types)){
foreach($types as $type){
($type == '2YO')&&($q2[] = " DivisionAge = '2YO' ");
($type == '3YO')&&($q2[] = " DivisionAge = '3YO' ");

($type == 'Trotters')&&($q3[] = " DivisionGait = 'Trotting' ");
($type == 'Pacers')&&($q3[] = " DivisionGait = 'Pacing' ");

($type == 'Colts')&&($q4[] = " DivisionSex = 'Colts' ");
($type == 'Fillies')&&($q4[] = " DivisionSex = 'Fillies' ");

($type == 'SS')&&($q5[] = " DivisionType = 'Sire Stakes' ");
($type == 'EX')&&($q5[] = " DivisionType = 'Excelsior' ");
($type == 'CF')&&($q5[] = " DivisionType = 'County Fair' ");

}
}

if(sizeof($q2) > 0){
	$q[] = '('.join(" or ",$q2).')';
	}

if(sizeof($q3) > 0){
	$q[] = '('.join(" or ",$q3).')';
	}

if(sizeof($q4) > 0){
	$q[] = '('.join(" or ",$q4).')';
	}

if(sizeof($q5) > 0){
	$q[] = '('.join(" or ",$q5).')';
	}

if($raceyear){
	$q[] = "year(racedate) = '$raceyear' ";
	}

if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new racesQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from races %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select races.*,tracks.track as track from races left join tracks on tracks.id=races.Track %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$races = new races();
$races->id= $f["id"];
$races->RaceName= $f["RaceName"];
$races->track= $f["track"];
$races->racedate= $f["racedate"];
$races->ts= $f["ts"];
$races->DivisionAge= $f["DivisionAge"];
$races->DivisionGait= $f["DivisionGait"];
$races->DivisionSex= $f["DivisionSex"];
$races->DivisionType= $f["DivisionType"];
array_push($q->Records,$races);
}


return $q;
}


static public function SearchPeople($order,$limit,$offset,$query)
{

$norder = Utilities::scrub($_REQUEST['norder']);
$desc = Utilities::scrub($_REQUEST['desc']);
if($norder){
if($norder == 'id'){
	$order = 'people.id';
	}

if($norder == 'FirstName'){
	$order = 'people.FirstName';
	}

if($norder == 'LastName'){
	$order = 'people.LastName';
	}

if($norder == 'Phone'){
	$order = 'people.Phone';
	}

if($norder == 'Email'){
	$order = 'people.Email';
	}

if($norder == 'Address'){
	$order = 'people.Address1';
	}

if($norder == 'Breeder'){
	$order = 'people.Breeder';
	}

if($norder == 'Owner'){
	$order = 'people.Owner';
	}

if($norder == 'Trainer'){
	$order = 'people.Trainer';
	}

if($norder == 'Driver'){
	$order = 'people.Driver';
	}

if($desc == 1){
	$order .= ' desc ';
	}

}

$query = array();
($_REQUEST['Breeder'])&&($query[] = "people.Breeder='1'");
($_REQUEST['Owner'])&&($query[] = "people.Owner='1'");
($_REQUEST['Trainer'])&&($query[] = "people.Trainer='1'");
($_REQUEST['Driver'])&&($query[] = "people.Driver='1'");


$allquery='';
if($query){
	$allquery = ' where ('.join(" or ",$query).')';
	}
if($_REQUEST['search']){
if(!$allquery){
	$allquery = ' where ';
	}
else{
	$allquery .= ' and ';
	}

$allquery .= sprintf(" (people.LastName like '%%%s%%' or people.FirstName like '%%%s%%') ",Utilities::mscrub($_REQUEST['search']),Utilities::mscrub($_REQUEST['search']));
}

if(!$allquery){
	$allquery = ' where ';
	}
else{
	$allquery .= ' and ';
	}

if($_SESSION['inactive']==1){
	$allquery .= " people.inactive='1' ";
	}
else{
	$allquery .= " people.inactive='0' ";
	}

$queryW9=array();
($_REQUEST['W9ReceivedY'])&&($queryW9[] = "people.W9Received='Y'");
($_REQUEST['W9ReceivedN'])&&($queryW9[] = "people.W9Received <> 'Y'");
if(sizeof($queryW9) > 0){
	if(!$allquery){
		$allquery = ' where ('.join(" or ",$queryW9).')';
		}
	else{
		$allquery .= ' and ('.join(" or ",$queryW9).')';
		}	
	}
	


$q = new peopleQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from people %s",$allquery);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from people %s order by %s %s %s",$allquery,$order,$limit,$offset);
$_SESSION['equery'] = sprintf("select * from people %s order by %s",$allquery,$order);

$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$people = new people();
$people->id= $f["id"];
$people->Breeder= $f["Breeder"];
$people->Owner= $f["Owner"];
$people->Trainer= $f["Trainer"];
$people->Driver= $f["Driver"];
$people->PersonID= $f["PersonID"];
$people->FirstName= $f["FirstName"];
$people->LastName= $f["LastName"];
$people->Address1= $f["Address1"];
$people->Address2= $f["Address2"];
$people->City= $f["City"];
$people->State= $f["State"];
$people->ZIP= $f["ZIP"];
$people->Country= $f["Country"];
$people->Phone= $f["Phone"];
$people->Email= $f["Email"];
$people->PersonNotes= $f["PersonNotes"];
$people->ts= $f["ts"];
array_push($q->Records,$people);
}


return $q;
}

static public function Search($order,$limit,$offset,$query)
{

$norder = Utilities::scrub($_REQUEST['norder']);
$desc = Utilities::scrub($_REQUEST['desc']);
if($norder){
if($norder == 'id'){
	$order = 'horses.id';
	}

if($norder == 'Horse'){
	$order = 'horses.Horse';
	}

if($norder == 'Sire'){
	$order = 'Sire.Horse';
	}

if($norder == 'Dam'){
	$order = 'Dam.Horse';
	}

if($norder == 'YOF'){
	$order = 'horses.YOF';
	}

if($norder == 'Gender'){
	$order = 'horses.SEX';
	}

if($norder == 'Gait'){
	$order = 'horses.Gait';
	}

if($norder == 'Breeder'){
	if($desc == 1){
		$order = 'breeders.LastName desc,breeders.FirstName';
		}
	else{
		$order = 'breeders.LastName,breeders.FirstName';
		}
	}

if($norder == 'Owner'){
	if($desc == 1){
		$order = 'owners.LastName desc,owners.FirstName';
		}
	else{
		$order = 'owners.LastName,owners.FirstName';
		}
	}


if($desc == 1){
	$order .= ' desc ';
	}

}

$q4=array();
if(is_array($_REQUEST['Type'])){
	foreach($_REQUEST['Type'] as $type){
		if($type == '1YO'){
			$q1[] = "year(now()) - horses.YOF = 1";
			}
		if($type == '2YO'){
			$q1[] = "year(now()) - horses.YOF = 2";
			}
		if($type == '3YO'){
			$q1[] = "year(now()) - horses.YOF = 3";
			}
		if($type == 'Colts'){
			$q2[] = "horses.Sex = 'C'";
			}
		if($type == 'Fillies'){
			$q2[] = "horses.Sex = 'F'";
			}
		if($type == 'Stallions'){
			$q2[] = "horses.Sex = 'S'";
			}
		if($type == 'Broodmares'){
			$q2[] = "horses.Sex = 'B'";
			}
		if($type == 'Trotting'){
			$q3[] = "horses.Gait = 'T'";
			}
		if($type == 'Pacing'){
			$q3[] = "horses.Gait = 'P'";
			}
			
		if($type == 'SS'){
			$q4[] = "(horses.IsEligSS = '1' or horses.IsEligSS = '2')";
			}
		if($type == 'EX'){
			$q4[] = "(horses.IsEligEX = '1' or horses.IsEligEX = '2' )";
			}		
		if($type == 'CF'){
			$q4[] = "(horses.IsEligCF = '1' or horses.IsEligCF = '2')";
			}			
	}
}

if(sizeof($q1) > 0){
	$q[] = '(' . join(" or ",$q1).') ';
	}

if(sizeof($q2) > 0){
	$q[] = '(' . join(" or ",$q2).') ';
	}

if(sizeof($q3) > 0){
	$q[] = '(' . join(" or ",$q3).') ';
	}

if(sizeof($q4) > 0){
	$q[] = '(' . join(" or ",$q4).') ';
	}
	
$ohfilter='';
//if($_REQUEST['oh']==1){
//	$_SESSION['oh']=1;
//	}
//if($_REQUEST['oh']==2){
//	unset($_SESSION['oh']);
//	}

if($_SESSION['oh']==1){
	$ohfilter = " and ((year(now()) - horses.YOF > 3) and (horses.Sex <> 'B' and horses.Sex <> 'S')) ";
	}
else{
	$ohfilter = " and (((year(now()) - horses.YOF <= 3) or (horses.Sex = 'B' or horses.Sex = 'S'))) ";
	}

($query->id)&&($q[] = sprintf("horses.id='%d'",Utilities::mscrub($query->id)));
($query->HorseID)&&($q[] = sprintf("horses.HorseID='%s'",Utilities::mscrub($query->HorseID)));
($query->Horse)&&($q[] = sprintf("horses.Horse='%s'",Utilities::mscrub($query->Horse)));
($query->Sire)&&($q[] = sprintf("horses.Sire='%s'",Utilities::mscrub($query->Sire)));
($query->Dam)&&($q[] = sprintf("horses.Dam='%s'",Utilities::mscrub($query->Dam)));
($query->ResidentialFoal)&&($q[] = sprintf("horses.ResidentialFoal='%s'",Utilities::mscrub($query->ResidentialFoal)));
($query->YOF)&&($q[] = sprintf("horses.YOF='%d'",Utilities::mscrub($query->YOF)));
($query->Gait)&&($q[] = sprintf("horses.Gait='%s'",Utilities::mscrub($query->Gait)));
($query->Sex)&&($q[] = sprintf("horses.Sex='%s'",Utilities::mscrub($query->Sex)));
($query->_1YO)&&($q[] = sprintf("horses._1YO='%s'",Utilities::mscrub($query->_1YO)));
($query->sup1)&&($q[] = sprintf("horses.sup1='%.2f'",Utilities::mscrub($query->sup1)));
($query->_2YOfeb_SS)&&($q[] = sprintf("horses._2YOfeb_SS='%s'",Utilities::mscrub($query->_2YOfeb_SS)));
($query->_2YOfeb_EX)&&($q[] = sprintf("horses._2YOfeb_EX='%s'",Utilities::mscrub($query->_2YOfeb_EX)));
($query->_2YOfeb_CF)&&($q[] = sprintf("horses._2YOfeb_CF='%s'",Utilities::mscrub($query->_2YOfeb_CF)));
($query->sup2)&&($q[] = sprintf("horses.sup2='%.2f'",Utilities::mscrub($query->sup2)));
($query->_2YOapr_SS)&&($q[] = sprintf("horses._2YOapr_SS='%s'",Utilities::mscrub($query->_2YOapr_SS)));
($query->_2YOapr_EX)&&($q[] = sprintf("horses._2YOapr_EX='%s'",Utilities::mscrub($query->_2YOapr_EX)));
($query->_2YOapr_CF)&&($q[] = sprintf("horses._2YOapr_CF='%s'",Utilities::mscrub($query->_2YOapr_CF)));
($query->sup3)&&($q[] = sprintf("horses.sup3='%.2f'",Utilities::mscrub($query->sup3)));
($query->_3YOfeb_SS)&&($q[] = sprintf("horses._3YOfeb_SS='%s'",Utilities::mscrub($query->_3YOfeb_SS)));
($query->_3YOfeb_EX)&&($q[] = sprintf("horses._3YOfeb_EX='%s'",Utilities::mscrub($query->_3YOfeb_EX)));
($query->_3YOfeb_CF)&&($q[] = sprintf("horses._3YOfeb_CF='%s'",Utilities::mscrub($query->_3YOfeb_CF)));
($query->_3YOapr_SS)&&($q[] = sprintf("horses._3YOapr_SS='%s'",Utilities::mscrub($query->_3YOapr_SS)));
($query->_3YOapr_EX)&&($q[] = sprintf("horses._3YOapr_EX='%s'",Utilities::mscrub($query->_3YOapr_EX)));
($query->_3YOapr_CF)&&($q[] = sprintf("horses._3YOapr_CF='%s'",Utilities::mscrub($query->_3YOapr_CF)));
($query->FarmAddress)&&($q[] = sprintf("horses.FarmAddress='%s'",Utilities::mscrub($query->FarmAddress)));
($query->FarmPhone)&&($q[] = sprintf("horses.FarmPhone='%s'",Utilities::mscrub($query->FarmPhone)));
($query->BredFirst)&&($q[] = sprintf("horses.BredFirst='%s'",Utilities::mscrub($query->BredFirst)));
($query->BredLast)&&($q[] = sprintf("horses.BredLast='%s'",Utilities::mscrub($query->BredLast)));
($query->ShipSemenFirst)&&($q[] = sprintf("horses.ShipSemenFirst='%s'",Utilities::mscrub($query->ShipSemenFirst)));
($query->ShipSemenLast)&&($q[] = sprintf("horses.ShipSemenLast='%s'",Utilities::mscrub($query->ShipSemenLast)));
($query->ResidencyArrival)&&($q[] = sprintf("horses.ResidencyArrival='%s'",Utilities::mscrub($query->ResidencyArrival)));
($query->ResidencyDeparture)&&($q[] = sprintf("horses.ResidencyDeparture='%s'",Utilities::mscrub($query->ResidencyDeparture)));
($query->InspectionDate)&&($q[] = sprintf("horses.InspectionDate='%s'",Utilities::mscrub($query->InspectionDate)));

if(sizeof($q) > 0){
$query = 'and (' . join(" and ",$q).') ';
}
else{
$query='';
}

$query .= $ohfilter;

if($_REQUEST['search']){
if(!$query){
	$query = ' where ';
	}
else{
	$query .= ' and ';
	}

$query .= sprintf(" (horses.Horse like '%%%s%%') ",Utilities::mscrub($_REQUEST['search']));
}

$queryRE=array();
($_REQUEST['ResidentEligibleY'])&&($queryRE[] = "horses.ResidentialFoal='Y'");
($_REQUEST['ResidentEligibleN'])&&($queryRE[] = "horses.ResidentialFoal <> 'Y'");
if(sizeof($queryRE) > 0){
	if(!$query){
		$query = ' where ('.join(" or ",$queryRE).')';
		}
	else{
		$query .= ' and ('.join(" or ",$queryRE).')';
		}	
	}
	
$q = new horsesQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from horses where 1 %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select horses.*,Sire.Horse as SireName,Dam.Horse as DamName,concat(owners.FirstName,' ',owners.LastName) as ownername,concat(breeders.FirstName,' ',breeders.LastName) as breedername from horses
left join horseowners on horseowners.hid=horses.id and horseowners.isprimary=1
left join people as owners on owners.id = horseowners.oid
left join horsebreeders on horsebreeders.hid=horses.id and horsebreeders.isprimary=1
left join people as breeders on breeders.id = horsebreeders.bid
left join horses as Sire on Sire.id = horses.Sire
left join horses as Dam on Dam.id = horses.Dam
where 1 %s order by %s %s %s",$query,$order,$limit,$offset);
//print "S: $sql_statement<br>";
///for invoice
$_SESSION['lasthorsequery'] = $query;
///
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$horses = new horses();
$horses->id= $f["id"];

$horses->ownername= $f["ownername"];
$horses->breedername= $f["breedername"];

$horses->HorseID= $f["HorseID"];
$horses->Horse= $f["Horse"];
$horses->Sire= $f["Sire"];
$horses->SireName= $f["SireName"];
$horses->Dam= $f["Dam"];
$horses->DamName= $f["DamName"];
$horses->ResidentialFoal= $f["ResidentialFoal"];
$horses->YOF= $f["YOF"];
$horses->Gait= $f["Gait"];
$horses->Sex= $f["Sex"];
$horses->_1YO= $f["_1YO"];
$horses->sup1= $f["sup1"];
$horses->_2YOfeb_SS= $f["_2YOfeb_SS"];
$horses->_2YOfeb_EX= $f["_2YOfeb_EX"];
$horses->_2YOfeb_CF= $f["_2YOfeb_CF"];
$horses->sup2= $f["sup2"];
$horses->_2YOapr_SS= $f["_2YOapr_SS"];
$horses->_2YOapr_EX= $f["_2YOapr_EX"];
$horses->_2YOapr_CF= $f["_2YOapr_CF"];
$horses->sup3= $f["sup3"];
$horses->_3YOfeb_SS= $f["_3YOfeb_SS"];
$horses->_3YOfeb_EX= $f["_3YOfeb_EX"];
$horses->_3YOfeb_CF= $f["_3YOfeb_CF"];
$horses->_3YOapr_SS= $f["_3YOapr_SS"];
$horses->_3YOapr_EX= $f["_3YOapr_EX"];
$horses->_3YOapr_CF= $f["_3YOapr_CF"];
$horses->FarmAddress= $f["FarmAddress"];
$horses->FarmPhone= $f["FarmPhone"];
$horses->BredFirst= $f["BredFirst"];
$horses->BredLast= $f["BredLast"];
$horses->ShipSemenFirst= $f["ShipSemenFirst"];
$horses->ShipSemenLast= $f["ShipSemenLast"];
$horses->ResidencyArrival= $f["ResidencyArrival"];
$horses->ResidencyDeparture= $f["ResidencyDeparture"];
$horses->InspectionDate= $f["InspectionDate"];
$horses->EligOverrideSS= $f["EligOverrideSS"];
$horses->EligOverrideEX= $f["EligOverrideEX"];
$horses->EligOverrideCF= $f["EligOverrideCF"];

$horses->IsEligSS=$f['IsEligSS'];
$horses->IsEligEX=$f['IsEligEX'];
$horses->IsEligCF=$f['IsEligCF'];



array_push($q->Records,$horses);
}


return $q;
}

}
?>
