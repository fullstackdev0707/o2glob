<?

#Created: Monday 19th of May 2014 11:58:22 AM
class tracks
{
	public $id;
	public $track;
	public $racetype;
}


class tracksQueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class tracks_manager
{
static public function Add($tracks){
$sql_statement = sprintf("insert into tracks(track
,racetype
)
values('%s'
,'%s'
)",
Utilities::mscrub($tracks->track)
,Utilities::mscrub($tracks->racetype)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from tracks where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($tracks){
$sql_statement = sprintf("update tracks set
track='%s'
,racetype='%s'
 where id='%d';
",
Utilities::mscrub($tracks->track)
,Utilities::mscrub($tracks->racetype)
,Utilities::mscrub($tracks->id)
);
DoSQL($sql_statement);
}


static public function Gettracks($id){
$tracks = new tracks();
$sql_statement = sprintf("select * from tracks where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$tracks->id= $f["id"];
$tracks->track= $f["track"];
$tracks->racetype= $f["racetype"];
return $tracks;
}


static public function GetBy_racetype_tracks($racetype,$orderby = ''){
$q = new tracksQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from tracks where  racetype = '%s'  %s ",Utilities::mscrub($racetype)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$tracks = new tracks();
$tracks->id= $f["id"];
$tracks->track= $f["track"];
$tracks->racetype= $f["racetype"];
array_push($q->Records,$tracks);
}
return $q;
}


static public function DeleteBy_racetype_tracks($racetype){
$sql_statement = sprintf("delete from tracks where  racetype = '%s'  ",Utilities::mscrub($racetype)
);
DoSQL($sql_statement);
}


static public function SaveBy_racetype_tracks($racetype){
$sql_statement = sprintf("update tracks set
track='%s'
,racetype='%s'
 where  racetype = '%s' ",
Utilities::mscrub($tracks->track)
,Utilities::mscrub($tracks->racetype)
,Utilities::mscrub($racetype)
);
DoSQL($sql_statement);
}


static public function Search($order,$limit,$offset,$query)
{
($query->id)&&($q[] = sprintf("tracks.id='%d'",Utilities::mscrub($query->id)));
($query->track)&&($q[] = sprintf("tracks.track='%s'",Utilities::mscrub($query->track)));
($query->racetype)&&($q[] = sprintf("tracks.racetype='%s'",Utilities::mscrub($query->racetype)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new tracksQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from tracks %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from tracks %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$tracks = new tracks();
$tracks->id= $f["id"];
$tracks->track= $f["track"];
$tracks->racetype= $f["racetype"];
array_push($q->Records,$tracks);
}


return $q;
}


static public function GetFormtracks(){
$tracks = new tracks();
$tracks->id= $_REQUEST["id"];
$tracks->track= $_REQUEST["track"];
$tracks->racetype= $_REQUEST["racetype"];
return $tracks;
}


}



?>