<?

#Created: Monday 19th of May 2014 11:58:22 AM
class OwnerStatistics2
{
	public $HorseID;
	public $RaceID;
	public $DivisionType;
	public $Earnings;
	public $Points;
	public $Pos1;
	public $Pos2;
	public $Pos3;
	public $Pos4;
	public $Pos5;
	public $Owners;
}


class OwnerStatistics2QueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class OwnerStatistics2_manager
{
static public function Add($OwnerStatistics2){
$sql_statement = sprintf("insert into OwnerStatistics2(HorseID
,RaceID
,DivisionType
,Earnings
,Points
,Pos1
,Pos2
,Pos3
,Pos4
,Pos5
,Owners
)
values('%d'
,'%d'
,'%s'
,'%.2f'
,'%s'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%s'
)",
Utilities::mscrub($OwnerStatistics2->HorseID)
,Utilities::mscrub($OwnerStatistics2->RaceID)
,Utilities::mscrub($OwnerStatistics2->DivisionType)
,Utilities::mscrub($OwnerStatistics2->Earnings)
,Utilities::mscrub($OwnerStatistics2->Points)
,Utilities::mscrub($OwnerStatistics2->Pos1)
,Utilities::mscrub($OwnerStatistics2->Pos2)
,Utilities::mscrub($OwnerStatistics2->Pos3)
,Utilities::mscrub($OwnerStatistics2->Pos4)
,Utilities::mscrub($OwnerStatistics2->Pos5)
,Utilities::mscrub($OwnerStatistics2->Owners)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from OwnerStatistics2 where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($OwnerStatistics2){
$sql_statement = sprintf("update OwnerStatistics2 set
HorseID='%d'
,RaceID='%d'
,DivisionType='%s'
,Earnings='%.2f'
,Points='%s'
,Pos1='%d'
,Pos2='%d'
,Pos3='%d'
,Pos4='%d'
,Pos5='%d'
,Owners='%s'
 where id='%d';
",
Utilities::mscrub($OwnerStatistics2->HorseID)
,Utilities::mscrub($OwnerStatistics2->RaceID)
,Utilities::mscrub($OwnerStatistics2->DivisionType)
,Utilities::mscrub($OwnerStatistics2->Earnings)
,Utilities::mscrub($OwnerStatistics2->Points)
,Utilities::mscrub($OwnerStatistics2->Pos1)
,Utilities::mscrub($OwnerStatistics2->Pos2)
,Utilities::mscrub($OwnerStatistics2->Pos3)
,Utilities::mscrub($OwnerStatistics2->Pos4)
,Utilities::mscrub($OwnerStatistics2->Pos5)
,Utilities::mscrub($OwnerStatistics2->Owners)
,Utilities::mscrub($OwnerStatistics2->id)
);
DoSQL($sql_statement);
}


static public function GetOwnerStatistics2($id){
$OwnerStatistics2 = new OwnerStatistics2();
$sql_statement = sprintf("select * from OwnerStatistics2 where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$OwnerStatistics2->HorseID= $f["HorseID"];
$OwnerStatistics2->RaceID= $f["RaceID"];
$OwnerStatistics2->DivisionType= $f["DivisionType"];
$OwnerStatistics2->Earnings= $f["Earnings"];
$OwnerStatistics2->Points= $f["Points"];
$OwnerStatistics2->Pos1= $f["Pos1"];
$OwnerStatistics2->Pos2= $f["Pos2"];
$OwnerStatistics2->Pos3= $f["Pos3"];
$OwnerStatistics2->Pos4= $f["Pos4"];
$OwnerStatistics2->Pos5= $f["Pos5"];
$OwnerStatistics2->Owners= $f["Owners"];
return $OwnerStatistics2;
}


static public function Search($order,$limit,$offset,$query)
{
($query->HorseID)&&($q[] = sprintf("OwnerStatistics2.HorseID='%d'",Utilities::mscrub($query->HorseID)));
($query->RaceID)&&($q[] = sprintf("OwnerStatistics2.RaceID='%d'",Utilities::mscrub($query->RaceID)));
($query->DivisionType)&&($q[] = sprintf("OwnerStatistics2.DivisionType='%s'",Utilities::mscrub($query->DivisionType)));
($query->Earnings)&&($q[] = sprintf("OwnerStatistics2.Earnings='%.2f'",Utilities::mscrub($query->Earnings)));
($query->Points)&&($q[] = sprintf("OwnerStatistics2.Points='%s'",Utilities::mscrub($query->Points)));
($query->Pos1)&&($q[] = sprintf("OwnerStatistics2.Pos1='%d'",Utilities::mscrub($query->Pos1)));
($query->Pos2)&&($q[] = sprintf("OwnerStatistics2.Pos2='%d'",Utilities::mscrub($query->Pos2)));
($query->Pos3)&&($q[] = sprintf("OwnerStatistics2.Pos3='%d'",Utilities::mscrub($query->Pos3)));
($query->Pos4)&&($q[] = sprintf("OwnerStatistics2.Pos4='%d'",Utilities::mscrub($query->Pos4)));
($query->Pos5)&&($q[] = sprintf("OwnerStatistics2.Pos5='%d'",Utilities::mscrub($query->Pos5)));
($query->Owners)&&($q[] = sprintf("OwnerStatistics2.Owners='%s'",Utilities::mscrub($query->Owners)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new OwnerStatistics2QueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from OwnerStatistics2 %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from OwnerStatistics2 %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$OwnerStatistics2 = new OwnerStatistics2();
$OwnerStatistics2->HorseID= $f["HorseID"];
$OwnerStatistics2->RaceID= $f["RaceID"];
$OwnerStatistics2->DivisionType= $f["DivisionType"];
$OwnerStatistics2->Earnings= $f["Earnings"];
$OwnerStatistics2->Points= $f["Points"];
$OwnerStatistics2->Pos1= $f["Pos1"];
$OwnerStatistics2->Pos2= $f["Pos2"];
$OwnerStatistics2->Pos3= $f["Pos3"];
$OwnerStatistics2->Pos4= $f["Pos4"];
$OwnerStatistics2->Pos5= $f["Pos5"];
$OwnerStatistics2->Owners= $f["Owners"];
array_push($q->Records,$OwnerStatistics2);
}


return $q;
}


static public function GetFormOwnerStatistics2(){
$OwnerStatistics2 = new OwnerStatistics2();
$OwnerStatistics2->HorseID= $_REQUEST["HorseID"];
$OwnerStatistics2->RaceID= $_REQUEST["RaceID"];
$OwnerStatistics2->DivisionType= $_REQUEST["DivisionType"];
$OwnerStatistics2->Earnings= $_REQUEST["Earnings"];
$OwnerStatistics2->Points= $_REQUEST["Points"];
$OwnerStatistics2->Pos1= $_REQUEST["Pos1"];
$OwnerStatistics2->Pos2= $_REQUEST["Pos2"];
$OwnerStatistics2->Pos3= $_REQUEST["Pos3"];
$OwnerStatistics2->Pos4= $_REQUEST["Pos4"];
$OwnerStatistics2->Pos5= $_REQUEST["Pos5"];
$OwnerStatistics2->Owners= $_REQUEST["Owners"];
return $OwnerStatistics2;
}


}



?>