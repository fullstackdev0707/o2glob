<?

#Created: Monday 19th of May 2014 11:58:22 AM
class OwnerStatistics
{
	public $HorseID;
	public $SumOfEarnings;
	public $SumOfPoints;
	public $Starts;
	public $Pos1;
	public $Pos2;
	public $Pos3;
	public $Pos4;
	public $Pos5;
	public $Owners;
}


class OwnerStatisticsQueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class OwnerStatistics_manager
{
static public function Add($OwnerStatistics){
$sql_statement = sprintf("insert into OwnerStatistics(HorseID
,SumOfEarnings
,SumOfPoints
,Starts
,Pos1
,Pos2
,Pos3
,Pos4
,Pos5
,Owners
)
values('%d'
,'%.2f'
,'%s'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%s'
)",
Utilities::mscrub($OwnerStatistics->HorseID)
,Utilities::mscrub($OwnerStatistics->SumOfEarnings)
,Utilities::mscrub($OwnerStatistics->SumOfPoints)
,Utilities::mscrub($OwnerStatistics->Starts)
,Utilities::mscrub($OwnerStatistics->Pos1)
,Utilities::mscrub($OwnerStatistics->Pos2)
,Utilities::mscrub($OwnerStatistics->Pos3)
,Utilities::mscrub($OwnerStatistics->Pos4)
,Utilities::mscrub($OwnerStatistics->Pos5)
,Utilities::mscrub($OwnerStatistics->Owners)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from OwnerStatistics where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($OwnerStatistics){
$sql_statement = sprintf("update OwnerStatistics set
HorseID='%d'
,SumOfEarnings='%.2f'
,SumOfPoints='%s'
,Starts='%d'
,Pos1='%d'
,Pos2='%d'
,Pos3='%d'
,Pos4='%d'
,Pos5='%d'
,Owners='%s'
 where id='%d';
",
Utilities::mscrub($OwnerStatistics->HorseID)
,Utilities::mscrub($OwnerStatistics->SumOfEarnings)
,Utilities::mscrub($OwnerStatistics->SumOfPoints)
,Utilities::mscrub($OwnerStatistics->Starts)
,Utilities::mscrub($OwnerStatistics->Pos1)
,Utilities::mscrub($OwnerStatistics->Pos2)
,Utilities::mscrub($OwnerStatistics->Pos3)
,Utilities::mscrub($OwnerStatistics->Pos4)
,Utilities::mscrub($OwnerStatistics->Pos5)
,Utilities::mscrub($OwnerStatistics->Owners)
,Utilities::mscrub($OwnerStatistics->id)
);
DoSQL($sql_statement);
}


static public function GetOwnerStatistics($id){
$OwnerStatistics = new OwnerStatistics();
$sql_statement = sprintf("select * from OwnerStatistics where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$OwnerStatistics->HorseID= $f["HorseID"];
$OwnerStatistics->SumOfEarnings= $f["SumOfEarnings"];
$OwnerStatistics->SumOfPoints= $f["SumOfPoints"];
$OwnerStatistics->Starts= $f["Starts"];
$OwnerStatistics->Pos1= $f["Pos1"];
$OwnerStatistics->Pos2= $f["Pos2"];
$OwnerStatistics->Pos3= $f["Pos3"];
$OwnerStatistics->Pos4= $f["Pos4"];
$OwnerStatistics->Pos5= $f["Pos5"];
$OwnerStatistics->Owners= $f["Owners"];
return $OwnerStatistics;
}


static public function Search($order,$limit,$offset,$query)
{
($query->HorseID)&&($q[] = sprintf("OwnerStatistics.HorseID='%d'",Utilities::mscrub($query->HorseID)));
($query->SumOfEarnings)&&($q[] = sprintf("OwnerStatistics.SumOfEarnings='%.2f'",Utilities::mscrub($query->SumOfEarnings)));
($query->SumOfPoints)&&($q[] = sprintf("OwnerStatistics.SumOfPoints='%s'",Utilities::mscrub($query->SumOfPoints)));
($query->Starts)&&($q[] = sprintf("OwnerStatistics.Starts='%d'",Utilities::mscrub($query->Starts)));
($query->Pos1)&&($q[] = sprintf("OwnerStatistics.Pos1='%d'",Utilities::mscrub($query->Pos1)));
($query->Pos2)&&($q[] = sprintf("OwnerStatistics.Pos2='%d'",Utilities::mscrub($query->Pos2)));
($query->Pos3)&&($q[] = sprintf("OwnerStatistics.Pos3='%d'",Utilities::mscrub($query->Pos3)));
($query->Pos4)&&($q[] = sprintf("OwnerStatistics.Pos4='%d'",Utilities::mscrub($query->Pos4)));
($query->Pos5)&&($q[] = sprintf("OwnerStatistics.Pos5='%d'",Utilities::mscrub($query->Pos5)));
($query->Owners)&&($q[] = sprintf("OwnerStatistics.Owners='%s'",Utilities::mscrub($query->Owners)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new OwnerStatisticsQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from OwnerStatistics %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from OwnerStatistics %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$OwnerStatistics = new OwnerStatistics();
$OwnerStatistics->HorseID= $f["HorseID"];
$OwnerStatistics->SumOfEarnings= $f["SumOfEarnings"];
$OwnerStatistics->SumOfPoints= $f["SumOfPoints"];
$OwnerStatistics->Starts= $f["Starts"];
$OwnerStatistics->Pos1= $f["Pos1"];
$OwnerStatistics->Pos2= $f["Pos2"];
$OwnerStatistics->Pos3= $f["Pos3"];
$OwnerStatistics->Pos4= $f["Pos4"];
$OwnerStatistics->Pos5= $f["Pos5"];
$OwnerStatistics->Owners= $f["Owners"];
array_push($q->Records,$OwnerStatistics);
}


return $q;
}


static public function GetFormOwnerStatistics(){
$OwnerStatistics = new OwnerStatistics();
$OwnerStatistics->HorseID= $_REQUEST["HorseID"];
$OwnerStatistics->SumOfEarnings= $_REQUEST["SumOfEarnings"];
$OwnerStatistics->SumOfPoints= $_REQUEST["SumOfPoints"];
$OwnerStatistics->Starts= $_REQUEST["Starts"];
$OwnerStatistics->Pos1= $_REQUEST["Pos1"];
$OwnerStatistics->Pos2= $_REQUEST["Pos2"];
$OwnerStatistics->Pos3= $_REQUEST["Pos3"];
$OwnerStatistics->Pos4= $_REQUEST["Pos4"];
$OwnerStatistics->Pos5= $_REQUEST["Pos5"];
$OwnerStatistics->Owners= $_REQUEST["Owners"];
return $OwnerStatistics;
}


}



?>