<?

#Created: Monday 19th of May 2014 11:58:22 AM
class BreederStatistics2
{
	public $HorseID;
	public $DivisionType;
	public $SumOfEarnings;
	public $SumOfPoints;
	public $Starts;
	public $Pos1;
	public $Pos2;
	public $Pos3;
	public $Pos4;
	public $Pos5;
	public $Breeders;
}


class BreederStatistics2QueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class BreederStatistics2_manager
{
static public function Add($BreederStatistics2){
$sql_statement = sprintf("insert into BreederStatistics2(HorseID
,DivisionType
,SumOfEarnings
,SumOfPoints
,Starts
,Pos1
,Pos2
,Pos3
,Pos4
,Pos5
,Breeders
)
values('%d'
,'%s'
,'%.2f'
,'%s'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%s'
)",
Utilities::mscrub($BreederStatistics2->HorseID)
,Utilities::mscrub($BreederStatistics2->DivisionType)
,Utilities::mscrub($BreederStatistics2->SumOfEarnings)
,Utilities::mscrub($BreederStatistics2->SumOfPoints)
,Utilities::mscrub($BreederStatistics2->Starts)
,Utilities::mscrub($BreederStatistics2->Pos1)
,Utilities::mscrub($BreederStatistics2->Pos2)
,Utilities::mscrub($BreederStatistics2->Pos3)
,Utilities::mscrub($BreederStatistics2->Pos4)
,Utilities::mscrub($BreederStatistics2->Pos5)
,Utilities::mscrub($BreederStatistics2->Breeders)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from BreederStatistics2 where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($BreederStatistics2){
$sql_statement = sprintf("update BreederStatistics2 set
HorseID='%d'
,DivisionType='%s'
,SumOfEarnings='%.2f'
,SumOfPoints='%s'
,Starts='%d'
,Pos1='%d'
,Pos2='%d'
,Pos3='%d'
,Pos4='%d'
,Pos5='%d'
,Breeders='%s'
 where id='%d';
",
Utilities::mscrub($BreederStatistics2->HorseID)
,Utilities::mscrub($BreederStatistics2->DivisionType)
,Utilities::mscrub($BreederStatistics2->SumOfEarnings)
,Utilities::mscrub($BreederStatistics2->SumOfPoints)
,Utilities::mscrub($BreederStatistics2->Starts)
,Utilities::mscrub($BreederStatistics2->Pos1)
,Utilities::mscrub($BreederStatistics2->Pos2)
,Utilities::mscrub($BreederStatistics2->Pos3)
,Utilities::mscrub($BreederStatistics2->Pos4)
,Utilities::mscrub($BreederStatistics2->Pos5)
,Utilities::mscrub($BreederStatistics2->Breeders)
,Utilities::mscrub($BreederStatistics2->id)
);
DoSQL($sql_statement);
}


static public function GetBreederStatistics2($id){
$BreederStatistics2 = new BreederStatistics2();
$sql_statement = sprintf("select * from BreederStatistics2 where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$BreederStatistics2->HorseID= $f["HorseID"];
$BreederStatistics2->DivisionType= $f["DivisionType"];
$BreederStatistics2->SumOfEarnings= $f["SumOfEarnings"];
$BreederStatistics2->SumOfPoints= $f["SumOfPoints"];
$BreederStatistics2->Starts= $f["Starts"];
$BreederStatistics2->Pos1= $f["Pos1"];
$BreederStatistics2->Pos2= $f["Pos2"];
$BreederStatistics2->Pos3= $f["Pos3"];
$BreederStatistics2->Pos4= $f["Pos4"];
$BreederStatistics2->Pos5= $f["Pos5"];
$BreederStatistics2->Breeders= $f["Breeders"];
return $BreederStatistics2;
}


static public function Search($order,$limit,$offset,$query)
{
($query->HorseID)&&($q[] = sprintf("BreederStatistics2.HorseID='%d'",Utilities::mscrub($query->HorseID)));
($query->DivisionType)&&($q[] = sprintf("BreederStatistics2.DivisionType='%s'",Utilities::mscrub($query->DivisionType)));
($query->SumOfEarnings)&&($q[] = sprintf("BreederStatistics2.SumOfEarnings='%.2f'",Utilities::mscrub($query->SumOfEarnings)));
($query->SumOfPoints)&&($q[] = sprintf("BreederStatistics2.SumOfPoints='%s'",Utilities::mscrub($query->SumOfPoints)));
($query->Starts)&&($q[] = sprintf("BreederStatistics2.Starts='%d'",Utilities::mscrub($query->Starts)));
($query->Pos1)&&($q[] = sprintf("BreederStatistics2.Pos1='%d'",Utilities::mscrub($query->Pos1)));
($query->Pos2)&&($q[] = sprintf("BreederStatistics2.Pos2='%d'",Utilities::mscrub($query->Pos2)));
($query->Pos3)&&($q[] = sprintf("BreederStatistics2.Pos3='%d'",Utilities::mscrub($query->Pos3)));
($query->Pos4)&&($q[] = sprintf("BreederStatistics2.Pos4='%d'",Utilities::mscrub($query->Pos4)));
($query->Pos5)&&($q[] = sprintf("BreederStatistics2.Pos5='%d'",Utilities::mscrub($query->Pos5)));
($query->Breeders)&&($q[] = sprintf("BreederStatistics2.Breeders='%s'",Utilities::mscrub($query->Breeders)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new BreederStatistics2QueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from BreederStatistics2 %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from BreederStatistics2 %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$BreederStatistics2 = new BreederStatistics2();
$BreederStatistics2->HorseID= $f["HorseID"];
$BreederStatistics2->DivisionType= $f["DivisionType"];
$BreederStatistics2->SumOfEarnings= $f["SumOfEarnings"];
$BreederStatistics2->SumOfPoints= $f["SumOfPoints"];
$BreederStatistics2->Starts= $f["Starts"];
$BreederStatistics2->Pos1= $f["Pos1"];
$BreederStatistics2->Pos2= $f["Pos2"];
$BreederStatistics2->Pos3= $f["Pos3"];
$BreederStatistics2->Pos4= $f["Pos4"];
$BreederStatistics2->Pos5= $f["Pos5"];
$BreederStatistics2->Breeders= $f["Breeders"];
array_push($q->Records,$BreederStatistics2);
}


return $q;
}


static public function GetFormBreederStatistics2(){
$BreederStatistics2 = new BreederStatistics2();
$BreederStatistics2->HorseID= $_REQUEST["HorseID"];
$BreederStatistics2->DivisionType= $_REQUEST["DivisionType"];
$BreederStatistics2->SumOfEarnings= $_REQUEST["SumOfEarnings"];
$BreederStatistics2->SumOfPoints= $_REQUEST["SumOfPoints"];
$BreederStatistics2->Starts= $_REQUEST["Starts"];
$BreederStatistics2->Pos1= $_REQUEST["Pos1"];
$BreederStatistics2->Pos2= $_REQUEST["Pos2"];
$BreederStatistics2->Pos3= $_REQUEST["Pos3"];
$BreederStatistics2->Pos4= $_REQUEST["Pos4"];
$BreederStatistics2->Pos5= $_REQUEST["Pos5"];
$BreederStatistics2->Breeders= $_REQUEST["Breeders"];
return $BreederStatistics2;
}


}



?>