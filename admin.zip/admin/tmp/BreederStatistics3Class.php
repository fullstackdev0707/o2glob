<?

#Created: Monday 19th of May 2014 11:58:22 AM
class BreederStatistics3
{
	public $HorseID;
	public $RaceID;
	public $DivisionType;
	public $Earnings;
	public $Points;
	public $Pos1;
	public $Pos2;
	public $Pos3;
	public $Pos4;
	public $Pos5;
	public $Breeders;
}


class BreederStatistics3QueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class BreederStatistics3_manager
{
static public function Add($BreederStatistics3){
$sql_statement = sprintf("insert into BreederStatistics3(HorseID
,RaceID
,DivisionType
,Earnings
,Points
,Pos1
,Pos2
,Pos3
,Pos4
,Pos5
,Breeders
)
values('%d'
,'%d'
,'%s'
,'%.2f'
,'%s'
,'%d'
,'%d'
,'%d'
,'%d'
,'%d'
,'%s'
)",
Utilities::mscrub($BreederStatistics3->HorseID)
,Utilities::mscrub($BreederStatistics3->RaceID)
,Utilities::mscrub($BreederStatistics3->DivisionType)
,Utilities::mscrub($BreederStatistics3->Earnings)
,Utilities::mscrub($BreederStatistics3->Points)
,Utilities::mscrub($BreederStatistics3->Pos1)
,Utilities::mscrub($BreederStatistics3->Pos2)
,Utilities::mscrub($BreederStatistics3->Pos3)
,Utilities::mscrub($BreederStatistics3->Pos4)
,Utilities::mscrub($BreederStatistics3->Pos5)
,Utilities::mscrub($BreederStatistics3->Breeders)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from BreederStatistics3 where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($BreederStatistics3){
$sql_statement = sprintf("update BreederStatistics3 set
HorseID='%d'
,RaceID='%d'
,DivisionType='%s'
,Earnings='%.2f'
,Points='%s'
,Pos1='%d'
,Pos2='%d'
,Pos3='%d'
,Pos4='%d'
,Pos5='%d'
,Breeders='%s'
 where id='%d';
",
Utilities::mscrub($BreederStatistics3->HorseID)
,Utilities::mscrub($BreederStatistics3->RaceID)
,Utilities::mscrub($BreederStatistics3->DivisionType)
,Utilities::mscrub($BreederStatistics3->Earnings)
,Utilities::mscrub($BreederStatistics3->Points)
,Utilities::mscrub($BreederStatistics3->Pos1)
,Utilities::mscrub($BreederStatistics3->Pos2)
,Utilities::mscrub($BreederStatistics3->Pos3)
,Utilities::mscrub($BreederStatistics3->Pos4)
,Utilities::mscrub($BreederStatistics3->Pos5)
,Utilities::mscrub($BreederStatistics3->Breeders)
,Utilities::mscrub($BreederStatistics3->id)
);
DoSQL($sql_statement);
}


static public function GetBreederStatistics3($id){
$BreederStatistics3 = new BreederStatistics3();
$sql_statement = sprintf("select * from BreederStatistics3 where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$BreederStatistics3->HorseID= $f["HorseID"];
$BreederStatistics3->RaceID= $f["RaceID"];
$BreederStatistics3->DivisionType= $f["DivisionType"];
$BreederStatistics3->Earnings= $f["Earnings"];
$BreederStatistics3->Points= $f["Points"];
$BreederStatistics3->Pos1= $f["Pos1"];
$BreederStatistics3->Pos2= $f["Pos2"];
$BreederStatistics3->Pos3= $f["Pos3"];
$BreederStatistics3->Pos4= $f["Pos4"];
$BreederStatistics3->Pos5= $f["Pos5"];
$BreederStatistics3->Breeders= $f["Breeders"];
return $BreederStatistics3;
}


static public function Search($order,$limit,$offset,$query)
{
($query->HorseID)&&($q[] = sprintf("BreederStatistics3.HorseID='%d'",Utilities::mscrub($query->HorseID)));
($query->RaceID)&&($q[] = sprintf("BreederStatistics3.RaceID='%d'",Utilities::mscrub($query->RaceID)));
($query->DivisionType)&&($q[] = sprintf("BreederStatistics3.DivisionType='%s'",Utilities::mscrub($query->DivisionType)));
($query->Earnings)&&($q[] = sprintf("BreederStatistics3.Earnings='%.2f'",Utilities::mscrub($query->Earnings)));
($query->Points)&&($q[] = sprintf("BreederStatistics3.Points='%s'",Utilities::mscrub($query->Points)));
($query->Pos1)&&($q[] = sprintf("BreederStatistics3.Pos1='%d'",Utilities::mscrub($query->Pos1)));
($query->Pos2)&&($q[] = sprintf("BreederStatistics3.Pos2='%d'",Utilities::mscrub($query->Pos2)));
($query->Pos3)&&($q[] = sprintf("BreederStatistics3.Pos3='%d'",Utilities::mscrub($query->Pos3)));
($query->Pos4)&&($q[] = sprintf("BreederStatistics3.Pos4='%d'",Utilities::mscrub($query->Pos4)));
($query->Pos5)&&($q[] = sprintf("BreederStatistics3.Pos5='%d'",Utilities::mscrub($query->Pos5)));
($query->Breeders)&&($q[] = sprintf("BreederStatistics3.Breeders='%s'",Utilities::mscrub($query->Breeders)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new BreederStatistics3QueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from BreederStatistics3 %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from BreederStatistics3 %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$BreederStatistics3 = new BreederStatistics3();
$BreederStatistics3->HorseID= $f["HorseID"];
$BreederStatistics3->RaceID= $f["RaceID"];
$BreederStatistics3->DivisionType= $f["DivisionType"];
$BreederStatistics3->Earnings= $f["Earnings"];
$BreederStatistics3->Points= $f["Points"];
$BreederStatistics3->Pos1= $f["Pos1"];
$BreederStatistics3->Pos2= $f["Pos2"];
$BreederStatistics3->Pos3= $f["Pos3"];
$BreederStatistics3->Pos4= $f["Pos4"];
$BreederStatistics3->Pos5= $f["Pos5"];
$BreederStatistics3->Breeders= $f["Breeders"];
array_push($q->Records,$BreederStatistics3);
}


return $q;
}


static public function GetFormBreederStatistics3(){
$BreederStatistics3 = new BreederStatistics3();
$BreederStatistics3->HorseID= $_REQUEST["HorseID"];
$BreederStatistics3->RaceID= $_REQUEST["RaceID"];
$BreederStatistics3->DivisionType= $_REQUEST["DivisionType"];
$BreederStatistics3->Earnings= $_REQUEST["Earnings"];
$BreederStatistics3->Points= $_REQUEST["Points"];
$BreederStatistics3->Pos1= $_REQUEST["Pos1"];
$BreederStatistics3->Pos2= $_REQUEST["Pos2"];
$BreederStatistics3->Pos3= $_REQUEST["Pos3"];
$BreederStatistics3->Pos4= $_REQUEST["Pos4"];
$BreederStatistics3->Pos5= $_REQUEST["Pos5"];
$BreederStatistics3->Breeders= $_REQUEST["Breeders"];
return $BreederStatistics3;
}


}



?>