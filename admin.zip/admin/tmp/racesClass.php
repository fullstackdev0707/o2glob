<?

#Created: Monday 3rd of March 2014 11:34:28 AM
class races
{
	public $id;
	public $RaceName;
	public $Track;
	public $racedate;
	public $ts;
	public $DivisionAge;
	public $DivisionGait;
	public $DivisionSex;
	public $DivisionType;
}


class racesQueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class races_manager
{
static public function Add($races){
$sql_statement = sprintf("insert into races(RaceName
,Track
,racedate
,ts
,DivisionAge
,DivisionGait
,DivisionSex
,DivisionType
)
values('%s'
,'%d'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
)",
Utilities::mscrub($races->RaceName)
,Utilities::mscrub($races->Track)
,Utilities::mscrub($races->racedate)
,Utilities::mscrub($races->ts)
,Utilities::mscrub($races->DivisionAge)
,Utilities::mscrub($races->DivisionGait)
,Utilities::mscrub($races->DivisionSex)
,Utilities::mscrub($races->DivisionType)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from races where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($races){
$sql_statement = sprintf("update races set
RaceName='%s'
,Track='%d'
,racedate='%s'
,ts='%s'
,DivisionAge='%s'
,DivisionGait='%s'
,DivisionSex='%s'
,DivisionType='%s'
 where id='%d';
",
Utilities::mscrub($races->RaceName)
,Utilities::mscrub($races->Track)
,Utilities::mscrub($races->racedate)
,Utilities::mscrub($races->ts)
,Utilities::mscrub($races->DivisionAge)
,Utilities::mscrub($races->DivisionGait)
,Utilities::mscrub($races->DivisionSex)
,Utilities::mscrub($races->DivisionType)
,Utilities::mscrub($races->id)
);
DoSQL($sql_statement);
}


static public function Getraces($id){
$races = new races();
$sql_statement = sprintf("select * from races where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$races->id= $f["id"];
$races->RaceName= $f["RaceName"];
$races->Track= $f["Track"];
$races->racedate= $f["racedate"];
$races->ts= $f["ts"];
$races->DivisionAge= $f["DivisionAge"];
$races->DivisionGait= $f["DivisionGait"];
$races->DivisionSex= $f["DivisionSex"];
$races->DivisionType= $f["DivisionType"];
return $races;
}


static public function GetBy_RTID_races($Track,$orderby = ''){
$q = new racesQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from races where  Track = '%s'  %s ",Utilities::mscrub($Track)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$races = new races();
$races->id= $f["id"];
$races->RaceName= $f["RaceName"];
$races->Track= $f["Track"];
$races->racedate= $f["racedate"];
$races->ts= $f["ts"];
$races->DivisionAge= $f["DivisionAge"];
$races->DivisionGait= $f["DivisionGait"];
$races->DivisionSex= $f["DivisionSex"];
$races->DivisionType= $f["DivisionType"];
array_push($q->Records,$races);
}
return $q;
}


static public function GetBy_racedate_races($racedate,$orderby = ''){
$q = new racesQueryResults();
$q->Records = array();
if($orderby){
$orderby = ' order by ' . $orderby;
}
$sql_statement = sprintf("select * from races where  racedate = '%s'  %s ",Utilities::mscrub($racedate)
,Utilities::mscrub($orderby)
);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$races = new races();
$races->id= $f["id"];
$races->RaceName= $f["RaceName"];
$races->Track= $f["Track"];
$races->racedate= $f["racedate"];
$races->ts= $f["ts"];
$races->DivisionAge= $f["DivisionAge"];
$races->DivisionGait= $f["DivisionGait"];
$races->DivisionSex= $f["DivisionSex"];
$races->DivisionType= $f["DivisionType"];
array_push($q->Records,$races);
}
return $q;
}


static public function DeleteBy_RTID_races($Track){
$sql_statement = sprintf("delete from races where  Track = '%s'  ",Utilities::mscrub($Track)
);
DoSQL($sql_statement);
}


static public function DeleteBy_racedate_races($racedate){
$sql_statement = sprintf("delete from races where  racedate = '%s'  ",Utilities::mscrub($racedate)
);
DoSQL($sql_statement);
}


static public function SaveBy_RTID_races($Track){
$sql_statement = sprintf("update races set
RaceName='%s'
,Track='%d'
,racedate='%s'
,ts='%s'
,DivisionAge='%s'
,DivisionGait='%s'
,DivisionSex='%s'
,DivisionType='%s'
 where  Track = '%s' ",
Utilities::mscrub($races->RaceName)
,Utilities::mscrub($races->Track)
,Utilities::mscrub($races->racedate)
,Utilities::mscrub($races->ts)
,Utilities::mscrub($races->DivisionAge)
,Utilities::mscrub($races->DivisionGait)
,Utilities::mscrub($races->DivisionSex)
,Utilities::mscrub($races->DivisionType)
,Utilities::mscrub($Track)
);
DoSQL($sql_statement);
}


static public function SaveBy_racedate_races($racedate){
$sql_statement = sprintf("update races set
RaceName='%s'
,Track='%d'
,racedate='%s'
,ts='%s'
,DivisionAge='%s'
,DivisionGait='%s'
,DivisionSex='%s'
,DivisionType='%s'
 where  racedate = '%s' ",
Utilities::mscrub($races->RaceName)
,Utilities::mscrub($races->Track)
,Utilities::mscrub($races->racedate)
,Utilities::mscrub($races->ts)
,Utilities::mscrub($races->DivisionAge)
,Utilities::mscrub($races->DivisionGait)
,Utilities::mscrub($races->DivisionSex)
,Utilities::mscrub($races->DivisionType)
,Utilities::mscrub($racedate)
);
DoSQL($sql_statement);
}


static public function Search($order,$limit,$offset,$query)
{
($query->id)&&($q[] = sprintf("races.id='%d'",Utilities::mscrub($query->id)));
($query->RaceName)&&($q[] = sprintf("races.RaceName='%s'",Utilities::mscrub($query->RaceName)));
($query->Track)&&($q[] = sprintf("races.Track='%d'",Utilities::mscrub($query->Track)));
($query->racedate)&&($q[] = sprintf("races.racedate='%s'",Utilities::mscrub($query->racedate)));
($query->ts)&&($q[] = sprintf("races.ts='%s'",Utilities::mscrub($query->ts)));
($query->DivisionAge)&&($q[] = sprintf("races.DivisionAge='%s'",Utilities::mscrub($query->DivisionAge)));
($query->DivisionGait)&&($q[] = sprintf("races.DivisionGait='%s'",Utilities::mscrub($query->DivisionGait)));
($query->DivisionSex)&&($q[] = sprintf("races.DivisionSex='%s'",Utilities::mscrub($query->DivisionSex)));
($query->DivisionType)&&($q[] = sprintf("races.DivisionType='%s'",Utilities::mscrub($query->DivisionType)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new racesQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from races %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from races %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$races = new races();
$races->id= $f["id"];
$races->RaceName= $f["RaceName"];
$races->Track= $f["Track"];
$races->racedate= $f["racedate"];
$races->ts= $f["ts"];
$races->DivisionAge= $f["DivisionAge"];
$races->DivisionGait= $f["DivisionGait"];
$races->DivisionSex= $f["DivisionSex"];
$races->DivisionType= $f["DivisionType"];
array_push($q->Records,$races);
}


return $q;
}


static public function GetFormraces(){
$races = new races();
$races->id= $_REQUEST["id"];
$races->RaceName= $_REQUEST["RaceName"];
$races->Track= $_REQUEST["Track"];
$races->racedate= $_REQUEST["racedate"];
$races->ts= $_REQUEST["ts"];
$races->DivisionAge= $_REQUEST["DivisionAge"];
$races->DivisionGait= $_REQUEST["DivisionGait"];
$races->DivisionSex= $_REQUEST["DivisionSex"];
$races->DivisionType= $_REQUEST["DivisionType"];
return $races;
}


}



?>