<?

#Created: Monday 19th of May 2014 11:58:22 AM
class people
{
	public $id;
	public $Breeder;
	public $Owner;
	public $Trainer;
	public $Driver;
	public $PersonID;
	public $FirstName;
	public $LastName;
	public $Address1;
	public $Address2;
	public $City;
	public $State;
	public $ZIP;
	public $Country;
	public $Phone;
	public $Email;
	public $PersonNotes;
	public $ts;
	public $inactive;
	public $W9Received;
}


class peopleQueryResults
{
	public $TotalRecs=0;
	public $Records;
}


class people_manager
{
static public function Add($people){
$sql_statement = sprintf("insert into people(Breeder
,Owner
,Trainer
,Driver
,PersonID
,FirstName
,LastName
,Address1
,Address2
,City
,State
,ZIP
,Country
,Phone
,Email
,PersonNotes
,ts
,inactive
,W9Received
)
values('%d'
,'%d'
,'%d'
,'%d'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%s'
,'%d'
,'%s'
)",
Utilities::mscrub($people->Breeder)
,Utilities::mscrub($people->Owner)
,Utilities::mscrub($people->Trainer)
,Utilities::mscrub($people->Driver)
,Utilities::mscrub($people->PersonID)
,Utilities::mscrub($people->FirstName)
,Utilities::mscrub($people->LastName)
,Utilities::mscrub($people->Address1)
,Utilities::mscrub($people->Address2)
,Utilities::mscrub($people->City)
,Utilities::mscrub($people->State)
,Utilities::mscrub($people->ZIP)
,Utilities::mscrub($people->Country)
,Utilities::mscrub($people->Phone)
,Utilities::mscrub($people->Email)
,Utilities::mscrub($people->PersonNotes)
,Utilities::mscrub($people->ts)
,Utilities::mscrub($people->inactive)
,Utilities::mscrub($people->W9Received)
);
DoSQL($sql_statement);
return mysql_insert_id();
}


static public function Delete($id){
$sql_statement = sprintf("delete from people where id='%d'",Utilities::mscrub($id));
DoSQL($sql_statement);
}


static public function Save($people){
$sql_statement = sprintf("update people set
Breeder='%d'
,Owner='%d'
,Trainer='%d'
,Driver='%d'
,PersonID='%s'
,FirstName='%s'
,LastName='%s'
,Address1='%s'
,Address2='%s'
,City='%s'
,State='%s'
,ZIP='%s'
,Country='%s'
,Phone='%s'
,Email='%s'
,PersonNotes='%s'
,ts='%s'
,inactive='%d'
,W9Received='%s'
 where id='%d';
",
Utilities::mscrub($people->Breeder)
,Utilities::mscrub($people->Owner)
,Utilities::mscrub($people->Trainer)
,Utilities::mscrub($people->Driver)
,Utilities::mscrub($people->PersonID)
,Utilities::mscrub($people->FirstName)
,Utilities::mscrub($people->LastName)
,Utilities::mscrub($people->Address1)
,Utilities::mscrub($people->Address2)
,Utilities::mscrub($people->City)
,Utilities::mscrub($people->State)
,Utilities::mscrub($people->ZIP)
,Utilities::mscrub($people->Country)
,Utilities::mscrub($people->Phone)
,Utilities::mscrub($people->Email)
,Utilities::mscrub($people->PersonNotes)
,Utilities::mscrub($people->ts)
,Utilities::mscrub($people->inactive)
,Utilities::mscrub($people->W9Received)
,Utilities::mscrub($people->id)
);
DoSQL($sql_statement);
}


static public function Getpeople($id){
$people = new people();
$sql_statement = sprintf("select * from people where id='%d'",Utilities::mscrub($id));
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$people->id= $f["id"];
$people->Breeder= $f["Breeder"];
$people->Owner= $f["Owner"];
$people->Trainer= $f["Trainer"];
$people->Driver= $f["Driver"];
$people->PersonID= $f["PersonID"];
$people->FirstName= $f["FirstName"];
$people->LastName= $f["LastName"];
$people->Address1= $f["Address1"];
$people->Address2= $f["Address2"];
$people->City= $f["City"];
$people->State= $f["State"];
$people->ZIP= $f["ZIP"];
$people->Country= $f["Country"];
$people->Phone= $f["Phone"];
$people->Email= $f["Email"];
$people->PersonNotes= $f["PersonNotes"];
$people->ts= $f["ts"];
$people->inactive= $f["inactive"];
$people->W9Received= $f["W9Received"];
return $people;
}


static public function Search($order,$limit,$offset,$query)
{
($query->id)&&($q[] = sprintf("people.id='%d'",Utilities::mscrub($query->id)));
($query->Breeder)&&($q[] = sprintf("people.Breeder='%d'",Utilities::mscrub($query->Breeder)));
($query->Owner)&&($q[] = sprintf("people.Owner='%d'",Utilities::mscrub($query->Owner)));
($query->Trainer)&&($q[] = sprintf("people.Trainer='%d'",Utilities::mscrub($query->Trainer)));
($query->Driver)&&($q[] = sprintf("people.Driver='%d'",Utilities::mscrub($query->Driver)));
($query->PersonID)&&($q[] = sprintf("people.PersonID='%s'",Utilities::mscrub($query->PersonID)));
($query->FirstName)&&($q[] = sprintf("people.FirstName='%s'",Utilities::mscrub($query->FirstName)));
($query->LastName)&&($q[] = sprintf("people.LastName='%s'",Utilities::mscrub($query->LastName)));
($query->Address1)&&($q[] = sprintf("people.Address1='%s'",Utilities::mscrub($query->Address1)));
($query->Address2)&&($q[] = sprintf("people.Address2='%s'",Utilities::mscrub($query->Address2)));
($query->City)&&($q[] = sprintf("people.City='%s'",Utilities::mscrub($query->City)));
($query->State)&&($q[] = sprintf("people.State='%s'",Utilities::mscrub($query->State)));
($query->ZIP)&&($q[] = sprintf("people.ZIP='%s'",Utilities::mscrub($query->ZIP)));
($query->Country)&&($q[] = sprintf("people.Country='%s'",Utilities::mscrub($query->Country)));
($query->Phone)&&($q[] = sprintf("people.Phone='%s'",Utilities::mscrub($query->Phone)));
($query->Email)&&($q[] = sprintf("people.Email='%s'",Utilities::mscrub($query->Email)));
($query->PersonNotes)&&($q[] = sprintf("people.PersonNotes='%s'",Utilities::mscrub($query->PersonNotes)));
($query->ts)&&($q[] = sprintf("people.ts='%s'",Utilities::mscrub($query->ts)));
($query->inactive)&&($q[] = sprintf("people.inactive='%d'",Utilities::mscrub($query->inactive)));
($query->W9Received)&&($q[] = sprintf("people.W9Received='%s'",Utilities::mscrub($query->W9Received)));
if(sizeof($q) > 0){
$query = ' where '.join(" and ",$q);
}
else{
$query='';
}

$q = new peopleQueryResults();
$q->Records = array();

if($limit > 0){
	$limit = "LIMIT $limit";
	}
else{
$limit='';
}

if($offset > 0){
	$offset = "OFFSET $offset";
	}
else{
$offset='';
}
$sql_statement = sprintf("select count(*) as cnt from people %s",$query);
$result = DoSQL($sql_statement);
$f = mysql_fetch_array($result);
$q->TotalRecs =  $f["cnt"];
$sql_statement = sprintf("select * from people %s order by %s %s %s",$query,$order,$limit,$offset);
$result = DoSQL($sql_statement);
while($f = mysql_fetch_array($result)){
$people = new people();
$people->id= $f["id"];
$people->Breeder= $f["Breeder"];
$people->Owner= $f["Owner"];
$people->Trainer= $f["Trainer"];
$people->Driver= $f["Driver"];
$people->PersonID= $f["PersonID"];
$people->FirstName= $f["FirstName"];
$people->LastName= $f["LastName"];
$people->Address1= $f["Address1"];
$people->Address2= $f["Address2"];
$people->City= $f["City"];
$people->State= $f["State"];
$people->ZIP= $f["ZIP"];
$people->Country= $f["Country"];
$people->Phone= $f["Phone"];
$people->Email= $f["Email"];
$people->PersonNotes= $f["PersonNotes"];
$people->ts= $f["ts"];
$people->inactive= $f["inactive"];
$people->W9Received= $f["W9Received"];
array_push($q->Records,$people);
}


return $q;
}


static public function GetFormpeople(){
$people = new people();
$people->id= $_REQUEST["id"];
$people->Breeder= $_REQUEST["Breeder"];
$people->Owner= $_REQUEST["Owner"];
$people->Trainer= $_REQUEST["Trainer"];
$people->Driver= $_REQUEST["Driver"];
$people->PersonID= $_REQUEST["PersonID"];
$people->FirstName= $_REQUEST["FirstName"];
$people->LastName= $_REQUEST["LastName"];
$people->Address1= $_REQUEST["Address1"];
$people->Address2= $_REQUEST["Address2"];
$people->City= $_REQUEST["City"];
$people->State= $_REQUEST["State"];
$people->ZIP= $_REQUEST["ZIP"];
$people->Country= $_REQUEST["Country"];
$people->Phone= $_REQUEST["Phone"];
$people->Email= $_REQUEST["Email"];
$people->PersonNotes= $_REQUEST["PersonNotes"];
$people->ts= $_REQUEST["ts"];
$people->inactive= $_REQUEST["inactive"];
$people->W9Received= $_REQUEST["W9Received"];
return $people;
}


}



?>